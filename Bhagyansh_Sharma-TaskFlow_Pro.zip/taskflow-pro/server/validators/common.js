const { param, body } = require('express-validator');
const { isValidISODate } = require('../utils/dates');

const idParam = (name = 'id') => param(name).isInt({ min: 1 }).withMessage(`${name} must be a positive integer`).toInt();

// Optional 'YYYY-MM-DD' date; '' or null clears the value
const optionalDate = (field, label) =>
  body(field)
    .optional({ values: 'null' })
    .custom((v) => v === '' || isValidISODate(v))
    .withMessage(`${label} must be a valid date (YYYY-MM-DD)`);

module.exports = { idParam, optionalDate };
