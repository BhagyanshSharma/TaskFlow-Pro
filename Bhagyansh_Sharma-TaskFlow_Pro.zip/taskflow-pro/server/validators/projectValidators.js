const { body, query } = require('express-validator');
const { PROJECT_STATUSES, PRIORITIES, PROJECT_ROLES } = require('../utils/constants');
const { idParam, optionalDate } = require('./common');

const deadlineAfterStart = body('deadline').custom((deadline, { req }) => {
  if (deadline && req.body.start_date && deadline < req.body.start_date) {
    throw new Error('Deadline cannot be before the start date');
  }
  return true;
});

const createProjectRules = [
  body('name').trim().notEmpty().withMessage('Project name is required').isLength({ min: 3, max: 120 }).withMessage('Project name must be 3-120 characters'),
  body('description').optional({ values: 'null' }).trim().isLength({ max: 5000 }).withMessage('Description is too long'),
  body('status').optional().isIn(PROJECT_STATUSES).withMessage(`Status must be one of: ${PROJECT_STATUSES.join(', ')}`),
  body('priority').optional().isIn(PRIORITIES).withMessage(`Priority must be one of: ${PRIORITIES.join(', ')}`),
  optionalDate('start_date', 'Start date'),
  optionalDate('deadline', 'Deadline'),
  deadlineAfterStart,
  body('member_ids').optional().isArray({ max: 50 }).withMessage('member_ids must be an array'),
  body('member_ids.*').optional().isInt({ min: 1 }).withMessage('member_ids must contain user ids').toInt(),
];

const updateProjectRules = [
  idParam(),
  body('name').optional().trim().isLength({ min: 3, max: 120 }).withMessage('Project name must be 3-120 characters'),
  body('description').optional({ values: 'null' }).trim().isLength({ max: 5000 }).withMessage('Description is too long'),
  body('status').optional().isIn(PROJECT_STATUSES).withMessage(`Status must be one of: ${PROJECT_STATUSES.join(', ')}`),
  body('priority').optional().isIn(PRIORITIES).withMessage(`Priority must be one of: ${PRIORITIES.join(', ')}`),
  optionalDate('start_date', 'Start date'),
  optionalDate('deadline', 'Deadline'),
  deadlineAfterStart,
];

const listProjectRules = [
  query('status').optional().isIn(PROJECT_STATUSES).withMessage('Invalid status filter'),
  query('priority').optional().isIn(PRIORITIES).withMessage('Invalid priority filter'),
  query('sort').optional().isIn(['updated', 'deadline', 'name', 'priority', 'progress', 'created']).withMessage('Invalid sort'),
  query('favourites').optional().isIn(['true', 'false']).withMessage('favourites must be true or false'),
];

const addMemberRules = [
  idParam(),
  body('user_id').optional().isInt({ min: 1 }).withMessage('user_id must be a positive integer').toInt(),
  body('email').optional().trim().isEmail().withMessage('Enter a valid email address').normalizeEmail({ gmail_remove_dots: false }),
  body().custom((b) => {
    if (!b.user_id && !b.email) throw new Error('Provide user_id or email of the member to add');
    return true;
  }),
  body('role').optional().isIn(PROJECT_ROLES.filter((r) => r !== 'owner')).withMessage('Role must be manager or member'),
];

const updateMemberRules = [
  idParam(),
  idParam('userId'),
  body('role').isIn(['manager', 'member']).withMessage('Role must be manager or member'),
];

module.exports = { createProjectRules, updateProjectRules, listProjectRules, addMemberRules, updateMemberRules };
