const { body, query } = require('express-validator');
const { TASK_STATUSES, PRIORITIES } = require('../utils/constants');
const { idParam, optionalDate } = require('./common');

const createTaskRules = [
  body('project_id').notEmpty().withMessage('Project is required').bail().isInt({ min: 1 }).withMessage('project_id must be a positive integer').toInt(),
  body('title').trim().notEmpty().withMessage('Task title is required').isLength({ min: 3, max: 160 }).withMessage('Task title must be 3-160 characters'),
  body('description').optional({ values: 'null' }).trim().isLength({ max: 5000 }).withMessage('Description is too long'),
  body('status').optional().isIn(TASK_STATUSES).withMessage(`Status must be one of: ${TASK_STATUSES.join(', ')}`),
  body('priority').optional().isIn(PRIORITIES).withMessage(`Priority must be one of: ${PRIORITIES.join(', ')}`),
  body('assignee_id').optional({ values: 'falsy' }).isInt({ min: 1 }).withMessage('assignee_id must be a user id').toInt(),
  optionalDate('due_date', 'Due date'),
];

const updateTaskRules = [
  idParam(),
  body('title').optional().trim().isLength({ min: 3, max: 160 }).withMessage('Task title must be 3-160 characters'),
  body('description').optional({ values: 'null' }).trim().isLength({ max: 5000 }).withMessage('Description is too long'),
  body('status').optional().isIn(TASK_STATUSES).withMessage(`Status must be one of: ${TASK_STATUSES.join(', ')}`),
  body('priority').optional().isIn(PRIORITIES).withMessage(`Priority must be one of: ${PRIORITIES.join(', ')}`),
  body('assignee_id').optional({ values: 'null' }).custom((v) => v === '' || (Number.isInteger(Number(v)) && Number(v) > 0)).withMessage('assignee_id must be a user id or null'),
  optionalDate('due_date', 'Due date'),
];

const listTaskRules = [
  query('project_id').optional().isInt({ min: 1 }).withMessage('project_id must be an integer').toInt(),
  query('status').optional().isIn(TASK_STATUSES).withMessage('Invalid status filter'),
  query('priority').optional().isIn(PRIORITIES).withMessage('Invalid priority filter'),
  query('assignee').optional().custom((v) => v === 'me' || v === 'unassigned' || /^\d+$/.test(v)).withMessage('assignee must be me, unassigned or a user id'),
  query('sort').optional().isIn(['due_date', 'priority', 'status', 'created', 'updated', 'title']).withMessage('Invalid sort field'),
  query('order').optional().isIn(['asc', 'desc']).withMessage('order must be asc or desc'),
  query('overdue').optional().isIn(['true', 'false']).withMessage('overdue must be true or false'),
];

const commentRules = [
  idParam(),
  body('body').trim().notEmpty().withMessage('Comment cannot be empty').isLength({ max: 2000 }).withMessage('Comment must be at most 2000 characters'),
];

module.exports = { createTaskRules, updateTaskRules, listTaskRules, commentRules };
