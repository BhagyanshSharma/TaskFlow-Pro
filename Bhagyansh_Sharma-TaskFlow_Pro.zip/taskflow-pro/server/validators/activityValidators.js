const { body, param, query } = require('express-validator');

const mongoIdParam = param('id').isMongoId().withMessage('Invalid activity id');

const createNoteRules = [
  body('project_id').isInt({ min: 1 }).withMessage('project_id is required').toInt(),
  body('task_id').optional({ values: 'falsy' }).isInt({ min: 1 }).withMessage('task_id must be an integer').toInt(),
  body('description').trim().notEmpty().withMessage('Note text is required').isLength({ min: 2, max: 500 }).withMessage('Note must be 2-500 characters'),
];

const updateNoteRules = [
  mongoIdParam,
  body('description').trim().notEmpty().withMessage('Note text is required').isLength({ min: 2, max: 500 }).withMessage('Note must be 2-500 characters'),
];

const listActivityRules = [
  query('project_id').optional().isInt({ min: 1 }).toInt(),
  query('task_id').optional().isInt({ min: 1 }).toInt(),
  query('entity_type').optional().isIn(['user', 'project', 'task', 'comment', 'member', 'note']),
];

module.exports = { mongoIdParam, createNoteRules, updateNoteRules, listActivityRules };
