const { body } = require('express-validator');

const passwordRule = (field = 'password') =>
  body(field)
    .isString().withMessage('Password is required')
    .isLength({ min: 8, max: 72 }).withMessage('Password must be 8-72 characters long')
    .matches(/[A-Za-z]/).withMessage('Password must contain at least one letter')
    .matches(/\d/).withMessage('Password must contain at least one number');

const registerRules = [
  body('name').trim().notEmpty().withMessage('Name is required').isLength({ min: 2, max: 80 }).withMessage('Name must be 2-80 characters'),
  body('email').trim().notEmpty().withMessage('Email is required').isEmail().withMessage('Enter a valid email address').normalizeEmail({ gmail_remove_dots: false }).isLength({ max: 120 }),
  passwordRule(),
];

const loginRules = [
  body('email').trim().notEmpty().withMessage('Email is required').isEmail().withMessage('Enter a valid email address').normalizeEmail({ gmail_remove_dots: false }),
  body('password').isString().notEmpty().withMessage('Password is required'),
];

const profileRules = [
  body('name').optional().trim().isLength({ min: 2, max: 80 }).withMessage('Name must be 2-80 characters'),
  body('job_title').optional({ values: 'null' }).trim().isLength({ max: 80 }).withMessage('Job title must be at most 80 characters'),
  body('bio').optional({ values: 'null' }).trim().isLength({ max: 500 }).withMessage('Bio must be at most 500 characters'),
  body('avatar_color').optional().matches(/^#[0-9a-fA-F]{6}$/).withMessage('Avatar colour must be a hex colour like #5B0888'),
];

const passwordChangeRules = [
  body('currentPassword').isString().notEmpty().withMessage('Current password is required'),
  passwordRule('newPassword'),
];

module.exports = { registerRules, loginRules, profileRules, passwordChangeRules };
