// Many-to-many between users and projects.
// role: owner (creator, full control), manager (edit + manage members/tasks), member (work on tasks, comment).
const mongoose = require('mongoose');
const { PROJECT_ROLES } = require('../utils/constants');

const projectMemberSchema = new mongoose.Schema(
  {
    project_id: { type: Number, required: true },
    user_id: { type: Number, required: true, index: true },
    role: { type: String, enum: PROJECT_ROLES, default: 'member' },
    joined_at: { type: Date, default: Date.now },
  },
  { versionKey: false }
);

projectMemberSchema.index({ project_id: 1, user_id: 1 }, { unique: true });

module.exports = mongoose.models.ProjectMember || mongoose.model('ProjectMember', projectMemberSchema);
