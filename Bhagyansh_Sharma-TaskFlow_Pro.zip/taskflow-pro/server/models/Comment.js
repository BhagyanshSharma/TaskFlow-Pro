// Discussion on a task (replaces the old LocalStorage chatbox)
const mongoose = require('mongoose');

const commentSchema = new mongoose.Schema(
  {
    _id: { type: Number, required: true },
    task_id: { type: Number, required: true },
    user_id: { type: Number, required: true },
    body: { type: String, required: true, maxlength: 2000 },
  },
  { timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' }, versionKey: false }
);

commentSchema.index({ task_id: 1, created_at: 1 });

module.exports = mongoose.models.Comment || mongoose.model('Comment', commentSchema);
