// Tasks. due_date is a 'YYYY-MM-DD' string, completed_at is a real timestamp.
const mongoose = require('mongoose');
const { TASK_STATUSES, PRIORITIES } = require('../utils/constants');

const taskSchema = new mongoose.Schema(
  {
    _id: { type: Number, required: true },
    project_id: { type: Number, required: true },
    title: { type: String, required: true, trim: true, maxlength: 160 },
    description: { type: String, default: null },
    status: { type: String, enum: TASK_STATUSES, default: 'To Do' },
    priority: { type: String, enum: PRIORITIES, default: 'Medium' },
    assignee_id: { type: Number, default: null, index: true },
    created_by: { type: Number, required: true },
    due_date: { type: String, default: null, index: true },
    completed_at: { type: Date, default: null },
  },
  { timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' }, versionKey: false }
);

taskSchema.index({ project_id: 1, status: 1 });

module.exports = mongoose.models.Task || mongoose.model('Task', taskSchema);
