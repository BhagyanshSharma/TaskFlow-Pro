// Auto-increment counters. The app (and the React client) uses simple numeric ids
// like /projects/3, so every collection keeps a running number here.
const mongoose = require('mongoose');

const counterSchema = new mongoose.Schema(
  { _id: { type: String, required: true }, seq: { type: Number, default: 0 } },
  { versionKey: false }
);

const Counter = mongoose.models.Counter || mongoose.model('Counter', counterSchema);

// Returns the next id for a collection, e.g. await nextId('users') -> 101
async function nextId(name) {
  const doc = await Counter.findOneAndUpdate(
    { _id: name },
    { $inc: { seq: 1 } },
    { new: true, upsert: true, setDefaultsOnInsert: true }
  ).lean();
  return doc.seq;
}

module.exports = Counter;
module.exports.nextId = nextId;
