// Projects. Dates are stored as 'YYYY-MM-DD' strings (no time zone shifting).
const mongoose = require('mongoose');
const { PROJECT_STATUSES, PRIORITIES } = require('../utils/constants');

const projectSchema = new mongoose.Schema(
  {
    _id: { type: Number, required: true },
    name: { type: String, required: true, trim: true, maxlength: 120 },
    description: { type: String, default: null },
    status: { type: String, enum: PROJECT_STATUSES, default: 'Planning' },
    priority: { type: String, enum: PRIORITIES, default: 'Medium' },
    start_date: { type: String, default: null },
    deadline: { type: String, default: null },
    owner_id: { type: Number, required: true, index: true },
  },
  { timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' }, versionKey: false }
);

projectSchema.index({ status: 1 });
projectSchema.index({ deadline: 1 });

module.exports = mongoose.models.Project || mongoose.model('Project', projectSchema);
