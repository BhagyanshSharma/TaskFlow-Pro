// All Mongoose models in one place
module.exports = {
  Counter: require('./Counter'),
  User: require('./User'),
  Project: require('./Project'),
  ProjectMember: require('./ProjectMember'),
  Task: require('./Task'),
  Comment: require('./Comment'),
  Favourite: require('./Favourite'),
  TimeLog: require('./TimeLog'),
  ActivityLog: require('./ActivityLog'),
};
module.exports.nextId = require('./Counter').nextId;
