// Start/stop time tracker carried over from the original LocalStorage project.
// ended_at null = timer currently running.
const mongoose = require('mongoose');

const timeLogSchema = new mongoose.Schema(
  {
    _id: { type: Number, required: true },
    task_id: { type: Number, required: true },
    user_id: { type: Number, required: true },
    started_at: { type: Date, required: true },
    ended_at: { type: Date, default: null },
  },
  { versionKey: false }
);

timeLogSchema.index({ task_id: 1, ended_at: 1 });

module.exports = mongoose.models.TimeLog || mongoose.model('TimeLog', timeLogSchema);
