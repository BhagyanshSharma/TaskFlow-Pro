// Registered accounts. Passwords are stored ONLY as bcrypt hashes.
// role = global role. 'admin' can see/manage everything.
const mongoose = require('mongoose');

const userSchema = new mongoose.Schema(
  {
    _id: { type: Number, required: true },
    name: { type: String, required: true, trim: true, maxlength: 80 },
    email: { type: String, required: true, trim: true, lowercase: true, maxlength: 120 },
    password_hash: { type: String, required: true },
    role: { type: String, enum: ['user', 'admin'], default: 'user' },
    job_title: { type: String, default: null, maxlength: 80 },
    bio: { type: String, default: null, maxlength: 500 },
    avatar_color: { type: String, default: '#5B0888' },
  },
  { timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' }, versionKey: false }
);

userSchema.index({ email: 1 }, { unique: true });
userSchema.index({ name: 1 });

module.exports = mongoose.models.User || mongoose.model('User', userSchema);
