// MongoDB model: activity / audit log.
// Every important action in the app (project created, task status changed,
// member added, comment posted ...) is written here by services/activityService.js.
// Users can also post manual "notes" to a project's timeline (action = 'note.created'),
// which is the part of the module that supports full CRUD from the UI.
const mongoose = require('mongoose');

const ACTIONS = [
  'user.registered',
  'user.updated',
  'project.created',
  'project.updated',
  'project.deleted',
  'project.favourited',
  'project.unfavourited',
  'member.added',
  'member.updated',
  'member.removed',
  'task.created',
  'task.updated',
  'task.status_changed',
  'task.assigned',
  'task.deleted',
  'task.timer_started',
  'task.timer_stopped',
  'comment.added',
  'comment.deleted',
  'note.created',
];

const activityLogSchema = new mongoose.Schema(
  {
    actor: {
      id: { type: Number, required: [true, 'Actor id is required'], index: true },
      name: { type: String, required: true, trim: true, maxlength: 80 },
    },
    action: { type: String, required: [true, 'Action is required'], enum: { values: ACTIONS, message: 'Unknown action type' } },
    entityType: { type: String, enum: ['user', 'project', 'task', 'comment', 'member', 'note'], required: true },
    projectId: { type: Number, default: null, index: true },
    taskId: { type: Number, default: null, index: true },
    description: {
      type: String,
      required: [true, 'Description is required'],
      trim: true,
      minlength: [2, 'Description must be at least 2 characters'],
      maxlength: [500, 'Description must be at most 500 characters'],
    },
    metadata: { type: mongoose.Schema.Types.Mixed, default: {} },
    editable: { type: Boolean, default: false }, // only manual notes can be edited/deleted by users
  },
  { timestamps: true, versionKey: false }
);

// Feed queries are always "latest first, filtered by project"
activityLogSchema.index({ projectId: 1, createdAt: -1 });
activityLogSchema.index({ createdAt: -1 });

activityLogSchema.set('toJSON', {
  transform(doc, ret) {
    ret.id = String(ret._id);
    delete ret._id;
    return ret;
  },
});

const ActivityLog = mongoose.models.ActivityLog || mongoose.model('ActivityLog', activityLogSchema);

module.exports = ActivityLog;
module.exports.ACTIONS = ACTIONS;
