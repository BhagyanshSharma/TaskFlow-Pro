// Per-user starred projects
const mongoose = require('mongoose');

const favouriteSchema = new mongoose.Schema(
  {
    user_id: { type: Number, required: true },
    project_id: { type: Number, required: true, index: true },
    created_at: { type: Date, default: Date.now },
  },
  { versionKey: false }
);

favouriteSchema.index({ user_id: 1, project_id: 1 }, { unique: true });

module.exports = mongoose.models.Favourite || mongoose.model('Favourite', favouriteSchema);
