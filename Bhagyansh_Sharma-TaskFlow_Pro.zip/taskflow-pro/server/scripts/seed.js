// Inserts fictional demonstration data into MongoDB.
//
//   npm run db:seed   -> clears all TaskFlow collections and inserts the demo data
//   (the API also runs this automatically on its first start if the database is empty)
//
// Every demo account uses the password:  Demo@1234
// All names and emails are fictional (example.com is a reserved domain).
const bcrypt = require('bcrypt');
const config = require('../config/env');
const { connectMongo, closeMongo } = require('../config/mongo');
const { User, Project, ProjectMember, Task, Comment, Favourite, TimeLog, Counter, ActivityLog } = require('../models');
const { todayISO, addDays } = require('../utils/dates');

const DEMO_PASSWORD = 'Demo@1234';

const users = [
  { id: 1, name: 'Demo Admin', email: 'admin@example.com', role: 'admin', job_title: 'System Administrator', color: '#5B0888' },
  { id: 2, name: 'Riya Kapoor', email: 'riya@example.com', role: 'user', job_title: 'Project Manager', color: '#7C3AED' },
  { id: 3, name: 'Arjun Verma', email: 'arjun@example.com', role: 'user', job_title: 'Frontend Developer', color: '#2563EB' },
  { id: 4, name: 'Neha Singh', email: 'neha@example.com', role: 'user', job_title: 'Backend Developer', color: '#0F766E' },
  { id: 5, name: 'Kabir Malhotra', email: 'kabir@example.com', role: 'user', job_title: 'UI/UX Designer', color: '#B45309' },
];

// start/deadline are offsets in days from today so the demo always has upcoming and overdue items
const projects = [
  { id: 1, name: 'Campus Event Portal', status: 'Active', priority: 'High', start: -21, deadline: 24, owner: 2,
    description: 'Web portal where students can discover, register for and give feedback on campus events.' },
  { id: 2, name: 'Library Management Revamp', status: 'Active', priority: 'Medium', start: -35, deadline: 10, owner: 2,
    description: 'Modernise book issue/return flows and add online reservations for the central library.' },
  { id: 3, name: 'Mobile Attendance App', status: 'Planning', priority: 'Urgent', start: -3, deadline: 45, owner: 3,
    description: 'QR-based attendance marking for lectures with a faculty dashboard.' },
  { id: 4, name: 'Alumni Newsletter', status: 'Completed', priority: 'Low', start: -60, deadline: -12, owner: 4,
    description: 'Quarterly newsletter template and mailing workflow for the alumni cell.' },
  { id: 5, name: 'Placement Cell Dashboard', status: 'On Hold', priority: 'Medium', start: -15, deadline: 30, owner: 5,
    description: 'Track company drives, eligible students and offer statistics in one place.' },
];

const members = [
  [1, 2, 'owner'], [1, 3, 'manager'], [1, 4, 'member'], [1, 5, 'member'],
  [2, 2, 'owner'], [2, 3, 'member'], [2, 5, 'member'],
  [3, 3, 'owner'], [3, 2, 'manager'], [3, 4, 'member'], [3, 5, 'member'],
  [4, 4, 'owner'], [4, 2, 'member'],
  [5, 5, 'owner'], [5, 3, 'member'],
];

// [id, project, title, status, priority, assignee, creator, dueOffset, description]
const tasks = [
  [1, 1, 'Design event listing page', 'Completed', 'High', 5, 2, -10, 'Card layout with filters for date, department and category.'],
  [2, 1, 'Build registration API', 'In Review', 'High', 4, 2, -2, 'POST /events/:id/register with seat-limit checks.'],
  [3, 1, 'Event details page in React', 'In Progress', 'Medium', 3, 2, 3, 'Show agenda, venue map and register button.'],
  [4, 1, 'Email confirmation for registrations', 'To Do', 'Medium', 4, 3, 7, 'Send a confirmation email once a seat is booked.'],
  [5, 1, 'Feedback form after event', 'To Do', 'Low', null, 2, 18, 'Five-star rating plus comments, visible to organisers.'],
  [6, 1, 'Fix mobile navbar overlap', 'To Do', 'Urgent', 3, 3, -1, 'Navbar covers page title on small screens.'],
  [7, 2, 'Migrate book catalogue to the database', 'Completed', 'High', 3, 2, -20, 'Import 12 legacy CSV sheets into normalised tables.'],
  [8, 2, 'Issue/return workflow', 'In Progress', 'High', 3, 2, 2, 'Barcode-driven issue and return with fine calculation.'],
  [9, 2, 'Online reservation queue', 'To Do', 'Medium', 5, 2, 9, 'Students can reserve a book that is currently issued.'],
  [10, 2, 'Overdue fine report', 'To Do', 'Low', null, 2, -4, 'Monthly PDF report of pending fines.'],
  [11, 3, 'Write requirement document', 'Completed', 'Medium', 2, 3, -1, 'Collect requirements from three departments.'],
  [12, 3, 'QR code generation service', 'To Do', 'Urgent', 4, 3, 12, 'Rotating QR every 30 seconds per lecture.'],
  [13, 3, 'Low-fidelity wireframes', 'In Progress', 'High', 5, 3, 5, 'Student scan screen and faculty summary screen.'],
  [14, 3, 'Choose mobile framework', 'In Review', 'Medium', 2, 3, 1, 'Compare React Native and Flutter for the team.'],
  [15, 4, 'Newsletter HTML template', 'Completed', 'Low', 4, 4, -30, 'Responsive email template tested in major clients.'],
  [16, 4, 'Collect alumni stories', 'Completed', 'Medium', 2, 4, -20, 'Five short stories with photos.'],
  [17, 5, 'Company drive tracker table', 'In Progress', 'Medium', 3, 5, -6, 'CRUD screen for company visits and rounds.'],
  [18, 5, 'Offer statistics charts', 'To Do', 'Low', 5, 5, 20, 'Department-wise offers and average package.'],
];

const comments = [
  [2, 2, 'Please add validation for duplicate registrations before review.'],
  [2, 4, 'Added a unique key on (event_id, user_id). Ready for review.'],
  [3, 3, 'Venue map is using a static image for now.'],
  [8, 2, 'Fine calculation should skip public holidays.'],
  [13, 5, 'First draft uploaded to the team drive.'],
  [14, 4, 'React Native lets us reuse our React knowledge.'],
];

const favourites = [[2, 1], [2, 3], [3, 1], [5, 5]];

// [task, user, startOffsetMinutesAgo, durationMinutes]
const timeLogs = [
  [1, 5, 60 * 24 * 12, 150],
  [2, 4, 60 * 24 * 4, 210],
  [3, 3, 60 * 24 * 2, 95],
  [3, 3, 60 * 5, 40],
  [8, 3, 60 * 24, 120],
  [13, 5, 60 * 3, 75],
];

// Builds every document. Dates are relative to today so there are always upcoming and overdue items.
async function buildDocuments() {
  const hash = await bcrypt.hash(DEMO_PASSWORD, 10);
  const today = todayISO();
  const day = (offset) => addDays(today, offset);
  const now = Date.now();
  const minutesAgo = (m) => new Date(now - m * 60000);
  const dayStart = (offset) => new Date(day(offset) + 'T12:00:00');

  return {
    users: users.map((u) => ({
      _id: u.id, name: u.name, email: u.email, password_hash: hash, role: u.role, job_title: u.job_title, avatar_color: u.color,
    })),
    projects: projects.map((p) => ({
      _id: p.id, name: p.name, description: p.description, status: p.status, priority: p.priority,
      start_date: day(p.start), deadline: day(p.deadline), owner_id: p.owner,
    })),
    members: members.map(([project_id, user_id, role]) => ({ project_id, user_id, role })),
    tasks: tasks.map(([id, project_id, title, status, priority, assignee_id, created_by, due, description]) => ({
      _id: id, project_id, title, status, priority, assignee_id, created_by, due_date: day(due), description,
      completed_at: status === 'Completed' ? dayStart(due - 1) : null,
    })),
    comments: comments.map(([task_id, user_id, body], i) => ({ _id: i + 1, task_id, user_id, body })),
    favourites: favourites.map(([user_id, project_id]) => ({ user_id, project_id })),
    timeLogs: timeLogs.map(([task_id, user_id, ago, dur], i) => ({
      _id: i + 1, task_id, user_id, started_at: minutesAgo(ago), ended_at: minutesAgo(ago - dur),
    })),
  };
}

// Deletes everything and inserts the demo data. Requires an open MongoDB connection.
async function seedDatabase() {
  const docs = await buildDocuments();
  const models = [User, Project, ProjectMember, Task, Comment, Favourite, TimeLog, Counter, ActivityLog];
  await Promise.all(models.map((m) => m.deleteMany({})));

  await User.insertMany(docs.users);
  await Project.insertMany(docs.projects);
  await ProjectMember.insertMany(docs.members);
  await Task.insertMany(docs.tasks);
  await Comment.insertMany(docs.comments);
  await Favourite.insertMany(docs.favourites);
  await TimeLog.insertMany(docs.timeLogs);
  // New records continue after the fixed demo ids
  await Counter.insertMany(
    ['users', 'projects', 'tasks', 'comments', 'time_logs'].map((name) => ({ _id: name, seq: 100 }))
  );
  const activities = buildActivities();
  await ActivityLog.insertMany(activities);

  return { ...docs, activities };
}

// Seeds only when there are no users yet (first start of the API)
async function seedIfEmpty() {
  const count = await User.estimatedDocumentCount();
  if (count > 0) return false;
  const docs = await seedDatabase();
  console.log(`[seed] Empty database - inserted demo data (${docs.users.length} users, ${docs.projects.length} projects, ${docs.tasks.length} tasks).`);
  console.log(`[seed] Demo login: riya@example.com / ${DEMO_PASSWORD}`);
  return true;
}

function buildActivities() {
  const byId = Object.fromEntries(users.map((u) => [u.id, u]));
  const now = Date.now();
  const at = (daysAgo, hours = 0) => new Date(now - daysAgo * 86400000 - hours * 3600000);
  const entries = [];
  for (const p of projects) {
    const owner = byId[p.owner];
    entries.push({ actor: { id: owner.id, name: owner.name }, action: 'project.created', entityType: 'project', projectId: p.id,
      description: `${owner.name} created project "${p.name}"`, metadata: { status: p.status, priority: p.priority }, createdAt: at(-p.start, 2) });
  }
  for (const [projectId, userId, role] of members) {
    if (role === 'owner') continue;
    const p = projects.find((x) => x.id === projectId);
    const owner = byId[p.owner];
    entries.push({ actor: { id: owner.id, name: owner.name }, action: 'member.added', entityType: 'member', projectId,
      description: `${owner.name} added ${byId[userId].name} to "${p.name}" as ${role}`, metadata: { userId, role }, createdAt: at(-p.start, 1) });
  }
  for (const [id, projectId, title, status, , assignee, creator, due] of tasks) {
    const c = byId[creator];
    entries.push({ actor: { id: c.id, name: c.name }, action: 'task.created', entityType: 'task', projectId, taskId: id,
      description: `${c.name} created task "${title}"`, metadata: { status: 'To Do' }, createdAt: at(Math.max(1, 8 - due / 4), 3) });
    if (assignee) {
      entries.push({ actor: { id: c.id, name: c.name }, action: 'task.assigned', entityType: 'task', projectId, taskId: id,
        description: `${c.name} assigned "${title}" to ${byId[assignee].name}`, metadata: { assigneeId: assignee }, createdAt: at(Math.max(1, 8 - due / 4), 2) });
    }
    if (status !== 'To Do') {
      const actor = byId[assignee || creator];
      entries.push({ actor: { id: actor.id, name: actor.name }, action: 'task.status_changed', entityType: 'task', projectId, taskId: id,
        description: `${actor.name} moved "${title}" from To Do to ${status}`, metadata: { from: 'To Do', to: status }, createdAt: at(Math.max(0, 2 - due / 10), 1) });
    }
  }
  for (const [taskId, userId, body] of comments) {
    const t = tasks.find((x) => x[0] === taskId);
    entries.push({ actor: { id: userId, name: byId[userId].name }, action: 'comment.added', entityType: 'comment', projectId: t[1], taskId,
      description: `${byId[userId].name} commented on "${t[2]}"`, metadata: { preview: body.slice(0, 80) }, createdAt: at(0, 6 + taskId / 3) });
  }
  entries.push({ actor: { id: 2, name: 'Riya Kapoor' }, action: 'note.created', entityType: 'note', projectId: 1, editable: true,
    description: 'Sprint review moved to Friday 3 PM in the seminar hall.', metadata: { projectName: 'Campus Event Portal' }, createdAt: at(0, 2) });
  return entries;
}

async function main() {
  await connectMongo();
  const docs = await seedDatabase();
  console.log(`[db:seed] MongoDB "${config.mongo.uri.split('/').pop().split('?')[0]}": ${docs.users.length} users, ${docs.projects.length} projects, ${docs.tasks.length} tasks, ${docs.comments.length} comments, ${docs.activities.length} activity entries inserted.`);
  await closeMongo();
  console.log(`[db:seed] Done. Log in with riya@example.com / ${DEMO_PASSWORD}`);
}

if (require.main === module) {
  main().catch(async (err) => {
    console.error('[db:seed] failed:', err.message);
    await closeMongo().catch(() => {});
    process.exit(1);
  });
}

module.exports = { seedDatabase, seedIfEmpty, buildActivities, DEMO_PASSWORD };
