// Runs after express-validator chains and turns failures into a 422 response.
const { validationResult } = require('express-validator');
const ApiError = require('../utils/ApiError');

module.exports = function validate(req, res, next) {
  const result = validationResult(req);
  if (result.isEmpty()) return next();
  const errors = result.array({ onlyFirstError: true }).map((e) => ({ field: e.path, message: e.msg }));
  const err = new ApiError(422, errors[0].message, errors);
  next(err);
};
