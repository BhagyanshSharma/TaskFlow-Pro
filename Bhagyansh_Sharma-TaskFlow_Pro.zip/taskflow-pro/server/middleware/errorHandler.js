// 404 + centralised error handler. Every error leaves the API in the same JSON shape:
// { success: false, message, errors? }
const config = require('../config/env');
const ApiError = require('../utils/ApiError');

function notFound(req, res) {
  res.status(404).json({ success: false, message: `Route not found: ${req.method} ${req.originalUrl}` });
}

// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  let status = err.statusCode || err.status || 500;
  let message = err.message || 'Internal server error';
  let errors = err.errors;

  // Malformed JSON body
  if (err.type === 'entity.parse.failed') {
    status = 400;
    message = 'Request body contains invalid JSON.';
  }

  // MongoDB specific errors
  if (err.code === 11000) {
    status = 409;
    message = 'A record with the same unique value already exists.';
  } else if (['MongoServerSelectionError', 'MongoNetworkError', 'MongoNotConnectedError', 'MongoNetworkTimeoutError'].includes(err.name)) {
    status = 503;
    message = 'Database is unavailable. Please check that MongoDB is running.';
  }

  // Mongoose errors
  if (err.name === 'CastError') {
    status = 400;
    message = 'Invalid identifier.';
  } else if (err.name === 'ValidationError' && err.errors && !Array.isArray(err.errors)) {
    status = 422;
    errors = Object.values(err.errors).map((e) => ({ field: e.path, message: e.message }));
    message = errors[0]?.message || 'Validation failed';
  }

  // ApiError instances are expected failures; anything else is a bug worth logging
  const unexpected = !(err instanceof ApiError) && status >= 500 && status !== 503;
  if (unexpected && !config.isTest) {
    console.error('[error]', err);
  }

  const body = { success: false, message: unexpected && config.isProd ? 'Internal server error' : message };
  if (Array.isArray(errors)) body.errors = errors;
  if (!config.isProd && unexpected && err.stack) body.stack = err.stack.split('\n').slice(0, 5);
  res.status(status).json(body);
}

module.exports = { notFound, errorHandler };
