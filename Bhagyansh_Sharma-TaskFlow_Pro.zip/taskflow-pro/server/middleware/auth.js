// JWT authentication + global role authorisation middleware.
const jwt = require('jsonwebtoken');
const config = require('../config/env');
const { User } = require('../models');
const ApiError = require('../utils/ApiError');

function signToken(user) {
  return jwt.sign({ sub: user.id, role: user.role }, config.jwt.secret, {
    expiresIn: config.jwt.expiresIn,
    issuer: 'taskflow-pro',
  });
}

// Expects:  Authorization: Bearer <token>
async function authenticate(req, res, next) {
  try {
    const header = req.headers.authorization || '';
    const [scheme, token] = header.split(' ');
    if (scheme !== 'Bearer' || !token) {
      throw ApiError.unauthorized('Authentication required. Please log in.');
    }

    let payload;
    try {
      payload = jwt.verify(token, config.jwt.secret, { issuer: 'taskflow-pro' });
    } catch (err) {
      if (err.name === 'TokenExpiredError') {
        throw ApiError.unauthorized('Your session has expired. Please log in again.');
      }
      throw ApiError.unauthorized('Invalid authentication token.');
    }

    // Re-load the user so deleted accounts / changed roles take effect immediately
    const id = Number(payload.sub);
    const user = Number.isInteger(id) ? await User.findById(id).lean() : null;
    if (!user) throw ApiError.unauthorized('Account no longer exists.');

    req.user = {
      id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
      job_title: user.job_title ?? null,
      bio: user.bio ?? null,
      avatar_color: user.avatar_color,
      created_at: user.created_at,
    };
    next();
  } catch (err) {
    next(err);
  }
}

// Global role check, e.g. requireRole('admin')
function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return next(ApiError.forbidden());
    }
    next();
  };
}

module.exports = { signToken, authenticate, requireRole };
