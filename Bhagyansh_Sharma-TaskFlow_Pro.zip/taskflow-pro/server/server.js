// Entry point: connects databases, starts HTTP server, handles graceful shutdown.
const app = require('./app');
const config = require('./config/env');
const { connectMongo, closeMongo } = require('./config/mongo');
const { seedIfEmpty } = require('./scripts/seed');

async function start() {
  try {
    await connectMongo();
  } catch (err) {
    console.error(`[mongo] Cannot connect to ${config.mongo.uri.replace(/\/\/[^@]*@/, '//***@')}`);
    console.error(`[mongo] ${err.message}`);
    console.error('[mongo] Start MongoDB (Windows: Services > MongoDB > Start) or set MONGODB_URI in server/.env');
    process.exit(1);
  }

  // First run on an empty database: add the demo accounts/projects (AUTO_SEED=false turns this off)
  if (config.mongo.autoSeed) await seedIfEmpty();

  const server = app.listen(config.port, () => {
    console.log(`[server] TaskFlow Pro API listening on port ${config.port} (${config.env})`);
  });

  let shuttingDown = false;
  async function shutdown(signal) {
    if (shuttingDown) return;
    shuttingDown = true;
    console.log(`[server] ${signal} received - shutting down gracefully`);
    server.close(async () => {
      await closeMongo().catch(() => {});
      console.log('[server] database connections closed. Bye!');
      process.exit(0);
    });
    // Force exit if connections hang
    setTimeout(() => process.exit(1), 10000).unref();
  }

  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('unhandledRejection', (reason) => console.error('[server] unhandled rejection:', reason));
}

start().catch((err) => {
  console.error('[server] failed to start:', err.message);
  process.exit(1);
});
