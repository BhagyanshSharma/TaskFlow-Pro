// Task counters per project (used by project lists, project detail and favourites).
const { Task, ProjectMember } = require('../models');
const { todayISO } = require('../utils/dates');

function emptyCounts() {
  return { total_tasks: 0, todo: 0, in_progress: 0, in_review: 0, completed: 0, overdue: 0 };
}

const STATUS_KEY = { 'To Do': 'todo', 'In Progress': 'in_progress', 'In Review': 'in_review', Completed: 'completed' };

// projectIds: array of numbers. Returns Map(projectId -> counters)
async function taskStatsFor(projectIds) {
  const stats = new Map(projectIds.map((id) => [id, emptyCounts()]));
  if (!projectIds.length) return stats;
  const today = todayISO();
  const tasks = await Task.find({ project_id: { $in: projectIds } }, { project_id: 1, status: 1, due_date: 1 }).lean();
  for (const t of tasks) {
    const s = stats.get(t.project_id);
    if (!s) continue;
    s.total_tasks += 1;
    s[STATUS_KEY[t.status]] += 1;
    if (t.due_date && t.due_date < today && t.status !== 'Completed') s.overdue += 1;
  }
  return stats;
}

// Returns Map(projectId -> number of members)
async function memberCountsFor(projectIds) {
  const counts = new Map(projectIds.map((id) => [id, 0]));
  if (!projectIds.length) return counts;
  const rows = await ProjectMember.find({ project_id: { $in: projectIds } }, { project_id: 1 }).lean();
  for (const r of rows) counts.set(r.project_id, (counts.get(r.project_id) || 0) + 1);
  return counts;
}

module.exports = { taskStatsFor, memberCountsFor, STATUS_KEY };
