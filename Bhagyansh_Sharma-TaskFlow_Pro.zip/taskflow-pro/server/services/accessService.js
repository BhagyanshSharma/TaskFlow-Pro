// Authorisation rules for projects and tasks.
//
//  Role (per project)  | view | edit project | manage members | create task | edit/delete any task | delete project
//  --------------------+------+--------------+----------------+-------------+----------------------+---------------
//  owner               |  yes |     yes      |      yes       |     yes     |         yes          |      yes
//  manager             |  yes |     yes      |      yes       |     yes     |         yes          |      no
//  member              |  yes |     no       |      no        |     yes     | only own/assigned    |      no
//  admin (global role) |  yes |     yes      |      yes       |     yes     |         yes          |      yes
const { Project, ProjectMember, Task } = require('../models');
const ApiError = require('../utils/ApiError');

const MANAGE_ROLES = ['owner', 'manager', 'admin'];

async function getProjectAccess(user, projectId) {
  const id = Number(projectId);
  const doc = Number.isInteger(id) ? await Project.findById(id).lean() : null;
  if (!doc) throw ApiError.notFound('Project not found.');
  const membership = await ProjectMember.findOne({ project_id: id, user_id: user.id }).lean();
  const project = { id: doc._id, name: doc.name, owner_id: doc.owner_id, member_role: membership ? membership.role : null };
  const role = user.role === 'admin' ? 'admin' : project.member_role;
  if (!role) throw ApiError.forbidden('You are not a member of this project.');
  return { project, role };
}

async function requireProjectManager(user, projectId) {
  const access = await getProjectAccess(user, projectId);
  if (!MANAGE_ROLES.includes(access.role)) {
    throw ApiError.forbidden('Only the project owner or a manager can do this.');
  }
  return access;
}

async function requireProjectOwner(user, projectId) {
  const access = await getProjectAccess(user, projectId);
  if (!['owner', 'admin'].includes(access.role)) {
    throw ApiError.forbidden('Only the project owner can do this.');
  }
  return access;
}

// Loads a task and checks the caller can see it (member of its project)
async function getTaskAccess(user, taskId) {
  const id = Number(taskId);
  const doc = Number.isInteger(id) ? await Task.findById(id).lean() : null;
  if (!doc) throw ApiError.notFound('Task not found.');
  const task = {
    id: doc._id,
    project_id: doc.project_id,
    title: doc.title,
    status: doc.status,
    assignee_id: doc.assignee_id,
    created_by: doc.created_by,
  };
  const access = await getProjectAccess(user, task.project_id);
  const isManager = MANAGE_ROLES.includes(access.role);
  const isInvolved = task.assignee_id === user.id || task.created_by === user.id;
  return { task, role: access.role, project: access.project, canEdit: isManager || isInvolved, isManager };
}

async function isProjectMember(projectId, userId) {
  const found = await ProjectMember.exists({ project_id: Number(projectId), user_id: Number(userId) });
  return Boolean(found);
}

// Project ids visible to this user (null means "all" for admins)
async function accessibleProjectIds(user) {
  if (user.role === 'admin') return null;
  const rows = await ProjectMember.find({ user_id: user.id }, { project_id: 1 }).lean();
  return rows.map((r) => r.project_id);
}

module.exports = {
  MANAGE_ROLES,
  getProjectAccess,
  requireProjectManager,
  requireProjectOwner,
  getTaskAccess,
  isProjectMember,
  accessibleProjectIds,
};
