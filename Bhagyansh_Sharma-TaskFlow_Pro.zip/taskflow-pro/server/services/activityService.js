// Writes and reads the MongoDB activity log.
// Logging is "best effort": if writing a log entry fails, the main operation still
// succeeds and a warning is printed.
const ActivityLog = require('../models/ActivityLog');
const { isMongoReady } = require('../config/mongo');
const ApiError = require('../utils/ApiError');
const config = require('../config/env');

async function logActivity({ actor, action, entityType, projectId = null, taskId = null, description, metadata = {} }) {
  if (!isMongoReady()) return null;
  try {
    return await ActivityLog.create({
      actor: { id: actor.id, name: actor.name },
      action,
      entityType,
      projectId,
      taskId,
      description,
      metadata,
    });
  } catch (err) {
    if (!config.isTest) console.warn('[activity] failed to write log:', err.message);
    return null;
  }
}

function ensureMongo() {
  if (!isMongoReady()) {
    throw ApiError.unavailable('Activity log is unavailable because MongoDB is not connected.');
  }
}

// Returns recent activity limited to the given project ids (null = no restriction, admin)
async function recentForProjects(projectIds, { limit = 10, actorId } = {}) {
  if (!isMongoReady()) return [];
  const filter = {};
  if (projectIds) {
    filter.$or = [{ projectId: { $in: projectIds } }];
    if (actorId) filter.$or.push({ projectId: null, 'actor.id': actorId });
  }
  const docs = await ActivityLog.find(filter).sort({ createdAt: -1 }).limit(limit);
  return docs.map((d) => d.toJSON());
}

module.exports = { logActivity, ensureMongo, recentForProjects };
