// Allowed enum values - kept in one place and shared by validators, services and tests.
module.exports = {
  TASK_STATUSES: ['To Do', 'In Progress', 'In Review', 'Completed'],
  PRIORITIES: ['Low', 'Medium', 'High', 'Urgent'],
  PROJECT_STATUSES: ['Planning', 'Active', 'On Hold', 'Completed', 'Cancelled'],
  PROJECT_ROLES: ['owner', 'manager', 'member'],
  // Weight of each task status when calculating progress (see utils/progress.js)
  STATUS_WEIGHT: { 'To Do': 0, 'In Progress': 0.5, 'In Review': 0.75, Completed: 1 },
  PRIORITY_RANK: { Low: 1, Medium: 2, High: 3, Urgent: 4 },
};
