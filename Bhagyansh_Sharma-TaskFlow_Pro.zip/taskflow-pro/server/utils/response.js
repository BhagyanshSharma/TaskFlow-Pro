// Consistent JSON envelope for every successful response:
// { success: true, message, data, pagination? }
function ok(res, data = null, message = 'OK', extra = {}) {
  return res.status(200).json({ success: true, message, data, ...extra });
}

function created(res, data = null, message = 'Created') {
  return res.status(201).json({ success: true, message, data });
}

module.exports = { ok, created };
