// Small date helpers. Calendar dates (start_date, deadline, due_date) are stored as
// 'YYYY-MM-DD' strings, so they compare correctly as text and never shift time zones.
function pad(n) {
  return String(n).padStart(2, '0');
}

// Today's date on the server, e.g. '2026-10-11'
function todayISO(date = new Date()) {
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

// '2026-10-11' + 3 -> '2026-10-14'
function addDays(isoDate, days) {
  const d = new Date(isoDate + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

// Whole days from a to b (b - a)
function daysBetween(a, b) {
  return Math.round((new Date(b + 'T00:00:00Z') - new Date(a + 'T00:00:00Z')) / 86400000);
}

function isValidISODate(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const d = new Date(value + 'T00:00:00Z');
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === value;
}

// Empty string / undefined -> null so optional date fields can be cleared
function normaliseDate(value) {
  if (value === undefined) return undefined;
  if (value === null || value === '') return null;
  return String(value).slice(0, 10);
}

// Escape user text before using it inside a MongoDB $regex search
function escapeRegex(text) {
  return String(text).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

module.exports = { todayISO, addDays, daysBetween, isValidISODate, normaliseDate, escapeRegex };
