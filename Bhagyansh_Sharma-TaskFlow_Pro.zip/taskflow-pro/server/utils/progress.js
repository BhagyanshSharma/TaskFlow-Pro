// Progress calculations.
//
// Progress is expressed as a percentage so it does not depend on HOW MANY tasks
// a project has ("quantity-independent"): a project with 2 tasks and one with
// 200 tasks are compared on the same 0-100 scale.
//
// Each task contributes a weight based on its status:
//   To Do = 0, In Progress = 0.5, In Review = 0.75, Completed = 1
// progress = round( sum(weights) / totalTasks * 100 )
const { STATUS_WEIGHT } = require('./constants');

function calculateProgress(counts) {
  const total =
    (counts.todo || 0) + (counts.in_progress || 0) + (counts.in_review || 0) + (counts.completed || 0);
  if (total === 0) return 0;
  const weighted =
    (counts.todo || 0) * STATUS_WEIGHT['To Do'] +
    (counts.in_progress || 0) * STATUS_WEIGHT['In Progress'] +
    (counts.in_review || 0) * STATUS_WEIGHT['In Review'] +
    (counts.completed || 0) * STATUS_WEIGHT.Completed;
  return Math.round((weighted / total) * 100);
}

function completionRate(completed, total) {
  if (!total) return 0;
  return Math.round((completed / total) * 100);
}

module.exports = { calculateProgress, completionRate };
