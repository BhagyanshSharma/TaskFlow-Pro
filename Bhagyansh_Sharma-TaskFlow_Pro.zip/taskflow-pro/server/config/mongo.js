// MongoDB connection (Mongoose). MongoDB is the only database used by the API:
// users, projects, members, tasks, comments, favourites, time logs and the activity log.
const mongoose = require('mongoose');
const config = require('./env');

mongoose.set('strictQuery', true);

let listenersAttached = false;

function attachListeners() {
  if (listenersAttached) return;
  listenersAttached = true;
  mongoose.connection.on('disconnected', () => {
    if (!config.isTest) console.warn('[mongo] disconnected');
  });
  mongoose.connection.on('reconnected', () => {
    if (!config.isTest) console.log('[mongo] reconnected');
  });
  mongoose.connection.on('error', (err) => {
    if (!config.isTest) console.error('[mongo] error:', err.message);
  });
}

// Connects and makes sure the unique indexes (e.g. one account per email) exist.
async function connectMongo(uri = config.mongo.uri) {
  if (!uri) throw new Error('MONGODB_URI is not set. Add it to server/.env');
  attachListeners();
  if (mongoose.connection.readyState === 1) return true;
  await mongoose.connect(uri, { serverSelectionTimeoutMS: 8000 });
  // Load every model, then build its indexes before the API accepts requests
  require('../models');
  await Promise.all(Object.values(mongoose.models).map((m) => m.init()));
  if (!config.isTest) console.log(`[mongo] connected to "${mongoose.connection.name}"`);
  return true;
}

function isMongoReady() {
  return mongoose.connection.readyState === 1;
}

async function pingMongo() {
  if (!isMongoReady()) return false;
  try {
    await mongoose.connection.db.admin().command({ ping: 1 });
    return true;
  } catch {
    return false;
  }
}

async function closeMongo() {
  if (mongoose.connection.readyState !== 0) {
    await mongoose.connection.close();
  }
}

module.exports = { connectMongo, isMongoReady, pingMongo, closeMongo };
