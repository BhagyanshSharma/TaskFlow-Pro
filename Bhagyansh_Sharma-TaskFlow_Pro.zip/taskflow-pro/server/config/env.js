// Centralised, validated environment configuration.
// All secrets come from environment variables (.env locally, dashboard on Render).
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env'), quiet: true });

const NODE_ENV = process.env.NODE_ENV || 'development';
const isProd = NODE_ENV === 'production';
const isTest = NODE_ENV === 'test';

function bool(value, fallback = false) {
  if (value === undefined || value === '') return fallback;
  return ['1', 'true', 'yes', 'on'].includes(String(value).toLowerCase());
}

const config = {
  env: NODE_ENV,
  isProd,
  isTest,
  port: Number(process.env.PORT) || 5000,

  // Comma separated list of allowed browser origins (the deployed React site)
  corsOrigins: (process.env.CORS_ORIGIN || 'http://localhost:5173')
    .split(',')
    .map((o) => o.trim().replace(/\/$/, ''))
    .filter(Boolean),

  jwt: {
    secret: process.env.JWT_SECRET,
    expiresIn: process.env.JWT_EXPIRES_IN || '1d',
  },

  bcryptRounds: Number(process.env.BCRYPT_ROUNDS) || 10,

  // MongoDB is the only database. Default = local MongoDB on this computer.
  mongo: {
    uri: process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/taskflow_pro',
    // Insert the demo data automatically the first time the API starts on an empty database
    autoSeed: bool(process.env.AUTO_SEED, true),
  },
};

// Fail fast on missing critical secrets
if (!config.jwt.secret) {
  if (isProd) {
    throw new Error('JWT_SECRET is required in production. Set it in your environment variables.');
  }
  config.jwt.secret = 'dev-only-insecure-secret-change-me';
  if (!isTest) {
    console.warn('[config] JWT_SECRET not set - using an insecure development secret.');
  }
}
if (isProd && config.jwt.secret.length < 32) {
  throw new Error('JWT_SECRET must be at least 32 characters in production.');
}

module.exports = config;
