// Express application (no network listening here, so tests can import it with supertest)
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const config = require('./config/env');
const routes = require('./routes');
const { notFound, errorHandler } = require('./middleware/errorHandler');

const app = express();

app.set('trust proxy', 1); // Render / proxies send X-Forwarded-For
app.disable('x-powered-by');
app.use(helmet());

// CORS: only the configured frontend origins may call the API from a browser
app.use(
  cors({
    origin(origin, callback) {
      // Allow non-browser clients (Postman, curl, health checks) that send no Origin
      if (!origin) return callback(null, true);
      const clean = origin.replace(/\/$/, '');
      if (config.corsOrigins.includes('*') || config.corsOrigins.includes(clean)) return callback(null, true);
      return callback(null, false);
    },
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization'],
    maxAge: 600,
  })
);

app.use(express.json({ limit: '100kb' }));
if (!config.isTest) app.use(morgan(config.isProd ? 'combined' : 'dev'));

app.get('/', (req, res) => {
  res.json({ success: true, message: 'TaskFlow Pro API. See /api/health and docs/api-documentation.md' });
});

app.use('/api', routes);
app.use(notFound);
app.use(errorHandler);

module.exports = app;
