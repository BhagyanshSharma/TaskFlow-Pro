const router = require('express').Router();
const h = require('../utils/asyncHandler');
const validate = require('../middleware/validate');
const { authenticate } = require('../middleware/auth');
const v = require('../validators/activityValidators');
const ctrl = require('../controllers/activityController');

router.use(authenticate);
router.get('/', v.listActivityRules, validate, h(ctrl.listActivities));
router.post('/', v.createNoteRules, validate, h(ctrl.createNote));
router.get('/:id', v.mongoIdParam, validate, h(ctrl.getActivity));
router.put('/:id', v.updateNoteRules, validate, h(ctrl.updateNote));
router.delete('/:id', v.mongoIdParam, validate, h(ctrl.deleteActivity));

module.exports = router;
