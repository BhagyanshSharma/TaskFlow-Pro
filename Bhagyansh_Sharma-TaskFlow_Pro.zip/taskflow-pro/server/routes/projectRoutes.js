const router = require('express').Router();
const h = require('../utils/asyncHandler');
const validate = require('../middleware/validate');
const { authenticate } = require('../middleware/auth');
const { idParam } = require('../validators/common');
const v = require('../validators/projectValidators');
const ctrl = require('../controllers/projectController');

router.use(authenticate);

router.get('/', v.listProjectRules, validate, h(ctrl.listProjects));
router.post('/', v.createProjectRules, validate, h(ctrl.createProject));
router.get('/:id', idParam(), validate, h(ctrl.getProject));
router.put('/:id', v.updateProjectRules, validate, h(ctrl.updateProject));
router.delete('/:id', idParam(), validate, h(ctrl.deleteProject));

// Team membership
router.get('/:id/members', idParam(), validate, h(ctrl.listMembers));
router.post('/:id/members', v.addMemberRules, validate, h(ctrl.addMember));
router.patch('/:id/members/:userId', v.updateMemberRules, validate, h(ctrl.updateMemberRole));
router.delete('/:id/members/:userId', idParam(), idParam('userId'), validate, h(ctrl.removeMember));

module.exports = router;
