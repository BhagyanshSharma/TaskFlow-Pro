const router = require('express').Router();
const h = require('../utils/asyncHandler');
const validate = require('../middleware/validate');
const { authenticate } = require('../middleware/auth');
const { idParam } = require('../validators/common');
const ctrl = require('../controllers/projectController');

router.use(authenticate);
router.get('/', h(ctrl.listFavourites));
router.post('/:projectId', idParam('projectId'), validate, h(ctrl.addFavourite));
router.delete('/:projectId', idParam('projectId'), validate, h(ctrl.removeFavourite));

module.exports = router;
