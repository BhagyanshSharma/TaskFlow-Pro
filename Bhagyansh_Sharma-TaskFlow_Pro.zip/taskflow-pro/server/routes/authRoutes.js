const router = require('express').Router();
const h = require('../utils/asyncHandler');
const validate = require('../middleware/validate');
const { authenticate } = require('../middleware/auth');
const { authLimiter } = require('../middleware/rateLimit');
const { registerRules, loginRules } = require('../validators/authValidators');
const ctrl = require('../controllers/authController');

router.post('/register', authLimiter, registerRules, validate, h(ctrl.register));
router.post('/login', authLimiter, loginRules, validate, h(ctrl.login));
router.get('/me', authenticate, h(ctrl.me));

module.exports = router;
