const router = require('express').Router();
const h = require('../utils/asyncHandler');
const validate = require('../middleware/validate');
const { authenticate } = require('../middleware/auth');
const { profileRules, passwordChangeRules } = require('../validators/authValidators');
const ctrl = require('../controllers/userController');

router.use(authenticate);
router.get('/search', h(ctrl.searchUsers));
router.put('/me', profileRules, validate, h(ctrl.updateProfile));
router.put('/me/password', passwordChangeRules, validate, h(ctrl.changePassword));

module.exports = router;
