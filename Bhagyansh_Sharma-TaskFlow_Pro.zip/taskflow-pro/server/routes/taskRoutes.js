const router = require('express').Router();
const h = require('../utils/asyncHandler');
const validate = require('../middleware/validate');
const { authenticate } = require('../middleware/auth');
const { idParam } = require('../validators/common');
const v = require('../validators/taskValidators');
const ctrl = require('../controllers/taskController');

router.use(authenticate);

router.get('/', v.listTaskRules, validate, h(ctrl.listTasks));
router.post('/', v.createTaskRules, validate, h(ctrl.createTask));
router.get('/:id', idParam(), validate, h(ctrl.getTask));
router.put('/:id', v.updateTaskRules, validate, h(ctrl.updateTask));
router.delete('/:id', idParam(), validate, h(ctrl.deleteTask));

// Comments
router.get('/:id/comments', idParam(), validate, h(ctrl.listComments));
router.post('/:id/comments', v.commentRules, validate, h(ctrl.addComment));
router.delete('/:id/comments/:commentId', idParam(), idParam('commentId'), validate, h(ctrl.deleteComment));

// Time tracking (carried over from the original project)
router.post('/:id/timer/start', idParam(), validate, h(ctrl.startTimer));
router.post('/:id/timer/stop', idParam(), validate, h(ctrl.stopTimer));

module.exports = router;
