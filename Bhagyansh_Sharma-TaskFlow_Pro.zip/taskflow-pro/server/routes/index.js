const router = require('express').Router();
const h = require('../utils/asyncHandler');
const { authenticate } = require('../middleware/auth');
const { pingMongo } = require('../config/mongo');
const { getDashboard } = require('../controllers/dashboardController');
const { TASK_STATUSES, PRIORITIES, PROJECT_STATUSES } = require('../utils/constants');

// Health check used by Render and for quick diagnostics
router.get('/health', h(async (req, res) => {
  const mongo = await pingMongo();
  res.status(mongo ? 200 : 503).json({
    success: mongo,
    message: mongo ? 'API is healthy' : 'MongoDB is not reachable',
    data: {
      status: mongo ? 'ok' : 'degraded',
      uptimeSeconds: Math.round(process.uptime()),
      databases: { mongodb: mongo ? 'connected' : 'disconnected' },
      timestamp: new Date().toISOString(),
    },
  });
}));

// Enum values for building dropdowns on the client
router.get('/meta', (req, res) => {
  res.json({ success: true, message: 'OK', data: { TASK_STATUSES, PRIORITIES, PROJECT_STATUSES } });
});

router.use('/auth', require('./authRoutes'));
router.use('/users', require('./userRoutes'));
router.use('/projects', require('./projectRoutes'));
router.use('/tasks', require('./taskRoutes'));
router.use('/favourites', require('./favouriteRoutes'));
router.use('/activities', require('./activityRoutes'));
router.get('/dashboard', authenticate, h(getDashboard));

module.exports = router;
