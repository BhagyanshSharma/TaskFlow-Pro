// Connects to the test database and refills it with the demo data for each test file.
const mongoose = require('mongoose');
const config = require('../../config/env');
const { connectMongo } = require('../../config/mongo');
const { seedDatabase } = require('../../scripts/seed');

async function resetDatabase() {
  await connectMongo();
  const db = mongoose.connection.name;
  if (!/test/i.test(db)) throw new Error(`Refusing to reset non-test database "${db}" (${config.mongo.uri})`);
  await seedDatabase();
}

module.exports = { resetDatabase };
