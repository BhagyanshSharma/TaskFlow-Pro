const { calculateProgress, completionRate } = require('../../utils/progress');
const { getPagination, buildMeta } = require('../../utils/pagination');
const { isValidISODate } = require('../../utils/dates');

describe('calculateProgress', () => {
  test('returns 0 for a project with no tasks', () => {
    expect(calculateProgress({})).toBe(0);
  });
  test('all completed = 100', () => {
    expect(calculateProgress({ completed: 3 })).toBe(100);
  });
  test('weights statuses (To Do 0, In Progress 50%, In Review 75%, Completed 100%)', () => {
    expect(calculateProgress({ todo: 1, in_progress: 1, in_review: 1, completed: 1 })).toBe(56);
  });
  test('is independent of task quantity', () => {
    expect(calculateProgress({ todo: 1, completed: 1 })).toBe(calculateProgress({ todo: 100, completed: 100 }));
  });
});

describe('completionRate', () => {
  test('handles zero', () => expect(completionRate(0, 0)).toBe(0));
  test('rounds percentage', () => expect(completionRate(1, 3)).toBe(33));
});

describe('pagination', () => {
  test('defaults and clamps values', () => {
    expect(getPagination({}, 20)).toEqual({ page: 1, limit: 20, offset: 0 });
    expect(getPagination({ page: '3', limit: '500' }, 20, 100)).toEqual({ page: 3, limit: 100, offset: 200 });
    expect(getPagination({ page: '-1', limit: 'abc' }, 10)).toEqual({ page: 1, limit: 10, offset: 0 });
  });
  test('meta', () => expect(buildMeta(2, 10, 35)).toEqual({ page: 2, limit: 10, total: 35, totalPages: 4 }));
});

describe('isValidISODate', () => {
  test('accepts real dates', () => expect(isValidISODate('2026-02-28')).toBe(true));
  test('rejects impossible dates', () => expect(isValidISODate('2026-02-30')).toBe(false));
  test('rejects other formats', () => expect(isValidISODate('28-02-2026')).toBe(false));
});
