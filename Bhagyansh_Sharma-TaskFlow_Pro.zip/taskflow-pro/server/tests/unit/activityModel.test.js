// Mongoose schema validation runs without a database connection.
const ActivityLog = require('../../models/ActivityLog');

describe('ActivityLog model validation', () => {
  test('valid document passes', () => {
    const doc = new ActivityLog({ actor: { id: 1, name: 'A' }, action: 'task.created', entityType: 'task', description: 'A created a task' });
    expect(doc.validateSync()).toBeUndefined();
  });
  test('unknown action and missing description fail', () => {
    const doc = new ActivityLog({ actor: { id: 1, name: 'A' }, action: 'task.exploded', entityType: 'task' });
    const err = doc.validateSync();
    expect(Object.keys(err.errors)).toEqual(expect.arrayContaining(['action', 'description']));
  });
  test('description longer than 500 characters fails', () => {
    const doc = new ActivityLog({ actor: { id: 1, name: 'A' }, action: 'note.created', entityType: 'note', description: 'x'.repeat(501) });
    expect(doc.validateSync().errors.description).toBeDefined();
  });
});
