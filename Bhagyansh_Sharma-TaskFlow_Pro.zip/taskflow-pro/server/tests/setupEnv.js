// Runs before every test file: isolate tests in a separate MongoDB database.
process.env.NODE_ENV = 'test';
process.env.JWT_SECRET = process.env.JWT_SECRET || 'test-secret-that-is-long-enough-for-tests-123';
// Never point tests at the real database by accident
process.env.MONGODB_URI = process.env.TEST_MONGODB_URI || 'mongodb://127.0.0.1:27017/taskflow_test';
process.env.AUTO_SEED = 'false';
process.env.BCRYPT_ROUNDS = '4'; // faster hashing in tests
