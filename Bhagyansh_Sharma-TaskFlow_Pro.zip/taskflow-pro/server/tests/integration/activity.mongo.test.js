// MongoDB activity-log tests (uses the same taskflow_test database as the API tests).
const request = require('supertest');
const app = require('../../app');
const { closeMongo } = require('../../config/mongo');
const ActivityLog = require('../../models/ActivityLog');
const { resetDatabase } = require('../helpers/db');

describe('Activity log (MongoDB)', () => {
  const tokens = {};
  const auth = (who) => ({ Authorization: `Bearer ${tokens[who]}` });

  beforeAll(async () => {
    await resetDatabase();
    await ActivityLog.deleteMany({});
    for (const who of ['riya', 'kabir', 'admin']) {
      const res = await request(app).post('/api/auth/login').send({ email: `${who}@example.com`, password: 'Demo@1234' });
      tokens[who] = res.body.data.token;
    }
  });

  afterAll(async () => {
    await ActivityLog.deleteMany({});
    await closeMongo();
  });

  test('creating a task writes an audit entry', async () => {
    const res = await request(app).post('/api/tasks').set(auth('riya')).send({ project_id: 1, title: 'Logged task', assignee_id: 3 });
    expect(res.status).toBe(201);
    const entries = await ActivityLog.find({ taskId: res.body.data.id }).lean();
    expect(entries.map((e) => e.action)).toEqual(expect.arrayContaining(['task.created', 'task.assigned']));
    expect(entries[0].actor.name).toBe('Riya Kapoor');
  });

  test('status change is logged with from/to metadata', async () => {
    await request(app).put('/api/tasks/5').set(auth('riya')).send({ status: 'In Progress' });
    const entry = await ActivityLog.findOne({ taskId: 5, action: 'task.status_changed' }).lean();
    expect(entry.metadata).toEqual({ from: 'To Do', to: 'In Progress' });
  });

  test('note CRUD: create, read, update, delete', async () => {
    const created = await request(app).post('/api/activities').set(auth('riya')).send({ project_id: 1, description: 'Client call at 4 PM' });
    expect(created.status).toBe(201);
    const id = created.body.data.id;

    const read = await request(app).get(`/api/activities/${id}`).set(auth('riya'));
    expect(read.body.data.description).toBe('Client call at 4 PM');

    const updated = await request(app).put(`/api/activities/${id}`).set(auth('riya')).send({ description: 'Client call moved to 5 PM' });
    expect(updated.body.data.description).toBe('Client call moved to 5 PM');

    const list = await request(app).get('/api/activities?project_id=1').set(auth('riya'));
    expect(list.body.data.some((a) => a.id === id)).toBe(true);

    const del = await request(app).delete(`/api/activities/${id}`).set(auth('riya'));
    expect(del.status).toBe(200);
    expect(await ActivityLog.findById(id)).toBeNull();
  });

  test('system entries cannot be edited by users', async () => {
    const entry = await ActivityLog.findOne({ action: 'task.created' });
    const res = await request(app).put(`/api/activities/${entry.id}`).set(auth('riya')).send({ description: 'rewrite history' });
    expect(res.status).toBe(403);
  });

  test('users cannot read activity of projects they are not in', async () => {
    const res = await request(app).get('/api/activities?project_id=1').set(auth('kabir'));
    expect(res.status).toBe(200); // Kabir is a member of project 1
    const blocked = await request(app).get('/api/activities?project_id=5').set(auth('riya'));
    expect(blocked.status).toBe(403);
  });

  test('invalid activity id returns 422', async () => {
    const res = await request(app).get('/api/activities/not-an-id').set(auth('riya'));
    expect(res.status).toBe(422);
  });
});
