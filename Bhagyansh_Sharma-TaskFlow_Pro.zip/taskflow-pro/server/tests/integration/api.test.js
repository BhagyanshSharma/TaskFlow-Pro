// End-to-end API tests against a real MongoDB test database (taskflow_test).
// Run:  npm test      (needs MongoDB running locally, or set TEST_MONGODB_URI)
const request = require('supertest');
const jwt = require('jsonwebtoken');
const app = require('../../app');
const { closeMongo } = require('../../config/mongo');
const { resetDatabase } = require('../helpers/db');

const PASSWORD = 'Demo@1234';
const tokens = {};

async function login(email, password = PASSWORD) {
  return request(app).post('/api/auth/login').send({ email, password });
}
const auth = (who) => ({ Authorization: `Bearer ${tokens[who]}` });

beforeAll(async () => {
  await resetDatabase();
  for (const who of ['riya', 'arjun', 'neha', 'kabir', 'admin']) {
    const res = await login(`${who}@example.com`);
    tokens[who] = res.body.data.token;
  }
});

afterAll(async () => {
  await closeMongo();
});

describe('Health', () => {
  test('GET /api/health reports MongoDB connected', async () => {
    const res = await request(app).get('/api/health');
    expect(res.status).toBe(200);
    expect(res.body.data.databases.mongodb).toBe('connected');
  });

  test('unknown route returns JSON 404', async () => {
    const res = await request(app).get('/api/does-not-exist');
    expect(res.status).toBe(404);
    expect(res.body.success).toBe(false);
  });
});

describe('Authentication', () => {
  test('registers a new user with a hashed password', async () => {
    const res = await request(app)
      .post('/api/auth/register')
      .send({ name: 'Test Student', email: 'student@example.com', password: 'Secret123' });
    expect(res.status).toBe(201);
    expect(res.body.data.user.email).toBe('student@example.com');
    expect(res.body.data.user.password_hash).toBeUndefined();
    expect(res.body.data.token).toBeDefined();
  });

  test('registered account is stored in MongoDB', async () => {
    const User = require('../../models/User');
    const saved = await User.findOne({ email: 'student@example.com' }).lean();
    expect(saved).not.toBeNull();
    expect(saved.name).toBe('Test Student');
    expect(saved.password_hash).not.toBe('Secret123');
  });

  test('email is case-insensitive for duplicates and login', async () => {
    const dup = await request(app).post('/api/auth/register').send({ name: 'Copy', email: 'Student@Example.com', password: 'Secret123' });
    expect(dup.status).toBe(409);
    const res = await login('STUDENT@example.com', 'Secret123');
    expect(res.status).toBe(200);
  });

  test('rejects duplicate email registration (409)', async () => {
    const res = await request(app)
      .post('/api/auth/register')
      .send({ name: 'Copy', email: 'student@example.com', password: 'Secret123' });
    expect(res.status).toBe(409);
  });

  test('validates registration input (422)', async () => {
    const res = await request(app).post('/api/auth/register').send({ name: 'A', email: 'bad', password: 'short' });
    expect(res.status).toBe(422);
    expect(res.body.errors.length).toBeGreaterThanOrEqual(1);
  });

  test('logs in with correct credentials', async () => {
    const res = await login('student@example.com', 'Secret123');
    expect(res.status).toBe(200);
    expect(res.body.data.token).toBeDefined();
  });

  test('rejects invalid password (401)', async () => {
    const res = await login('riya@example.com', 'WrongPass1');
    expect(res.status).toBe(401);
    expect(res.body.message).toMatch(/invalid email or password/i);
  });

  test('rejects unknown email with the same message (401)', async () => {
    const res = await login('nobody@example.com', 'WrongPass1');
    expect(res.status).toBe(401);
    expect(res.body.message).toMatch(/invalid email or password/i);
  });

  test('GET /api/auth/me returns the current user', async () => {
    const res = await request(app).get('/api/auth/me').set(auth('riya'));
    expect(res.status).toBe(200);
    expect(res.body.data.user.name).toBe('Riya Kapoor');
  });

  test('protected route without token returns 401', async () => {
    const res = await request(app).get('/api/projects');
    expect(res.status).toBe(401);
  });

  test('tampered token returns 401', async () => {
    const res = await request(app).get('/api/projects').set({ Authorization: `Bearer ${tokens.riya}x` });
    expect(res.status).toBe(401);
  });

  test('expired token returns 401 with session-expired message', async () => {
    const expired = jwt.sign({ sub: 2, role: 'user' }, process.env.JWT_SECRET, { expiresIn: -10, issuer: 'taskflow-pro' });
    const res = await request(app).get('/api/projects').set({ Authorization: `Bearer ${expired}` });
    expect(res.status).toBe(401);
    expect(res.body.message).toMatch(/expired/i);
  });
});

describe('Profile', () => {
  test('updates profile details', async () => {
    const res = await request(app).put('/api/users/me').set(auth('neha')).send({ job_title: 'API Developer', bio: 'Loves SQL' });
    expect(res.status).toBe(200);
    expect(res.body.data.user.job_title).toBe('API Developer');
  });

  test('rejects wrong current password on password change', async () => {
    const res = await request(app).put('/api/users/me/password').set(auth('neha')).send({ currentPassword: 'nope', newPassword: 'NewPass123' });
    expect(res.status).toBe(400);
  });
});

describe('Projects CRUD and permissions', () => {
  let projectId;

  test('lists only projects the user belongs to', async () => {
    const res = await request(app).get('/api/projects').set(auth('riya'));
    expect(res.status).toBe(200);
    const names = res.body.data.map((p) => p.name);
    expect(names).toContain('Campus Event Portal');
    expect(names).not.toContain('Placement Cell Dashboard'); // Riya is not a member
    expect(res.body.pagination.total).toBe(4);
  });

  test('searches and filters projects', async () => {
    const res = await request(app).get('/api/projects?q=library&status=Active').set(auth('riya'));
    expect(res.body.data).toHaveLength(1);
    expect(res.body.data[0].name).toBe('Library Management Revamp');
  });

  test('creates a project and makes the creator the owner', async () => {
    const res = await request(app).post('/api/projects').set(auth('riya')).send({
      name: 'Hostel Complaint System',
      description: 'Track hostel maintenance requests',
      priority: 'High',
      status: 'Active',
      start_date: '2026-01-01',
      deadline: '2026-03-01',
      member_ids: [4],
    });
    expect(res.status).toBe(201);
    projectId = res.body.data.id;
    expect(res.body.data.my_role).toBe('owner');
    expect(res.body.data.members.map((m) => m.id).sort()).toEqual([2, 4]);
  });

  test('rejects a deadline before the start date', async () => {
    const res = await request(app).post('/api/projects').set(auth('riya')).send({ name: 'Bad Dates', start_date: '2026-05-01', deadline: '2026-04-01' });
    expect(res.status).toBe(422);
  });

  test('rejects an invalid calendar date', async () => {
    const res = await request(app).post('/api/projects').set(auth('riya')).send({ name: 'Bad Date', deadline: '2026-02-30' });
    expect(res.status).toBe(422);
  });

  test('member cannot edit the project (403)', async () => {
    const res = await request(app).put(`/api/projects/${projectId}`).set(auth('neha')).send({ name: 'Hacked' });
    expect(res.status).toBe(403);
  });

  test('non-member cannot view the project (403)', async () => {
    const res = await request(app).get(`/api/projects/${projectId}`).set(auth('kabir'));
    expect(res.status).toBe(403);
  });

  test('owner updates the project', async () => {
    const res = await request(app).put(`/api/projects/${projectId}`).set(auth('riya')).send({ status: 'On Hold', name: 'Hostel Complaint Tracker' });
    expect(res.status).toBe(200);
    expect(res.body.data.status).toBe('On Hold');
    expect(res.body.data.name).toBe('Hostel Complaint Tracker');
  });

  test('project not found returns 404', async () => {
    const res = await request(app).get('/api/projects/99999').set(auth('riya'));
    expect(res.status).toBe(404);
  });

  test('admin can see every project', async () => {
    const res = await request(app).get('/api/projects?limit=50').set(auth('admin'));
    expect(res.body.pagination.total).toBe(6);
  });

  test('manager cannot delete (only owner)', async () => {
    const res = await request(app).delete('/api/projects/1').set(auth('arjun'));
    expect(res.status).toBe(403);
  });

  test('owner deletes the project', async () => {
    const res = await request(app).delete(`/api/projects/${projectId}`).set(auth('riya'));
    expect(res.status).toBe(200);
    const after = await request(app).get(`/api/projects/${projectId}`).set(auth('riya'));
    expect(after.status).toBe(404);
  });
});

describe('Members', () => {
  test('manager adds a member by email', async () => {
    const res = await request(app).post('/api/projects/2/members').set(auth('riya')).send({ email: 'neha@example.com', role: 'member' });
    expect(res.status).toBe(201);
    expect(res.body.data.some((m) => m.email === 'neha@example.com')).toBe(true);
  });

  test('adding an existing member returns 409', async () => {
    const res = await request(app).post('/api/projects/2/members').set(auth('riya')).send({ email: 'neha@example.com' });
    expect(res.status).toBe(409);
  });

  test('member cannot add members (403)', async () => {
    const res = await request(app).post('/api/projects/2/members').set(auth('arjun')).send({ email: 'admin@example.com' });
    expect(res.status).toBe(403);
  });

  test('owner cannot be removed', async () => {
    const res = await request(app).delete('/api/projects/2/members/2').set(auth('riya'));
    expect(res.status).toBe(400);
  });

  test('removing a member unassigns their tasks in that project', async () => {
    const res = await request(app).delete('/api/projects/2/members/5').set(auth('riya'));
    expect(res.status).toBe(200);
    const task = await request(app).get('/api/tasks/9').set(auth('riya'));
    expect(task.body.data.assignee).toBeNull();
  });
});

describe('Tasks CRUD, search, filters and sorting', () => {
  let taskId;

  test('creates a task assigned to a project member', async () => {
    const res = await request(app).post('/api/tasks').set(auth('riya')).send({
      project_id: 1,
      title: 'Prepare demo script',
      description: 'Steps for the viva demo',
      priority: 'Urgent',
      assignee_id: 4,
      due_date: '2030-01-15',
    });
    expect(res.status).toBe(201);
    taskId = res.body.data.id;
    expect(res.body.data.assignee.name).toBe('Neha Singh');
    expect(res.body.data.status).toBe('To Do');
  });

  test('validates missing title and project (422)', async () => {
    const res = await request(app).post('/api/tasks').set(auth('riya')).send({ description: 'no title' });
    expect(res.status).toBe(422);
  });

  test('rejects an invalid due date (422)', async () => {
    const res = await request(app).post('/api/tasks').set(auth('riya')).send({ project_id: 1, title: 'Bad date', due_date: '15-01-2030' });
    expect(res.status).toBe(422);
  });

  test('cannot assign to a non-member (400)', async () => {
    const res = await request(app).post('/api/tasks').set(auth('riya')).send({ project_id: 1, title: 'Outsider task', assignee_id: 1 });
    expect(res.status).toBe(400);
  });

  test('non-member cannot create a task in the project (403)', async () => {
    const res = await request(app).post('/api/tasks').set(auth('kabir')).send({ project_id: 2, title: 'Sneaky task' });
    expect(res.status).toBe(403);
  });

  test('searches tasks by text', async () => {
    const res = await request(app).get('/api/tasks?q=demo%20script').set(auth('riya'));
    expect(res.body.data.map((t) => t.id)).toContain(taskId);
  });

  test('filters by status, priority and assignee', async () => {
    const res = await request(app).get('/api/tasks?project_id=1&priority=Urgent&assignee=4&status=To%20Do').set(auth('riya'));
    expect(res.body.data.every((t) => t.priority === 'Urgent' && t.assignee.id === 4 && t.status === 'To Do')).toBe(true);
    expect(res.body.data.length).toBeGreaterThanOrEqual(1);
  });

  test('filters overdue tasks', async () => {
    const res = await request(app).get('/api/tasks?overdue=true').set(auth('riya'));
    expect(res.body.data.length).toBeGreaterThan(0);
    expect(res.body.data.every((t) => t.is_overdue)).toBe(true);
  });

  test('sorts by priority descending', async () => {
    const res = await request(app).get('/api/tasks?project_id=1&sort=priority&order=desc').set(auth('riya'));
    const rank = { Low: 1, Medium: 2, High: 3, Urgent: 4 };
    const ranks = res.body.data.map((t) => rank[t.priority]);
    expect([...ranks].sort((a, b) => b - a)).toEqual(ranks);
  });

  test('sorts by due date ascending: open tasks first, earliest deadline first', async () => {
    const res = await request(app).get('/api/tasks?project_id=1&sort=due_date&order=asc').set(auth('riya'));
    const statuses = res.body.data.map((t) => t.status === 'Completed');
    expect([...statuses].sort()).toEqual(statuses); // false (open) before true (completed)
    const openDates = res.body.data.filter((t) => t.status !== 'Completed').map((t) => t.due_date).filter(Boolean);
    expect([...openDates].sort()).toEqual(openDates);
  });

  test('paginates task lists', async () => {
    const res = await request(app).get('/api/tasks?limit=5&page=2').set(auth('riya'));
    expect(res.body.data.length).toBeLessThanOrEqual(5);
    expect(res.body.pagination.page).toBe(2);
  });

  test('assignee can change status; completed_at is set', async () => {
    const res = await request(app).put(`/api/tasks/${taskId}`).set(auth('neha')).send({ status: 'Completed' });
    expect(res.status).toBe(200);
    expect(res.body.data.status).toBe('Completed');
    expect(res.body.data.completed_at).not.toBeNull();
  });

  test('member who is not involved cannot edit the task (403)', async () => {
    const res = await request(app).put(`/api/tasks/${taskId}`).set(auth('kabir')).send({ title: 'Changed by Kabir' });
    expect(res.status).toBe(403);
  });

  test('assignee cannot reassign a task they did not create (403)', async () => {
    const res = await request(app).put(`/api/tasks/${taskId}`).set(auth('neha')).send({ assignee_id: 3 });
    expect(res.status).toBe(403);
  });

  test('progress is a percentage independent of task count', async () => {
    const res = await request(app).get('/api/projects/1').set(auth('riya'));
    expect(res.body.data.progress).toBeGreaterThanOrEqual(0);
    expect(res.body.data.progress).toBeLessThanOrEqual(100);
    expect(res.body.data.task_counts.total).toBe(7);
  });

  test('comments: add, list and delete', async () => {
    const add = await request(app).post(`/api/tasks/${taskId}/comments`).set(auth('neha')).send({ body: 'Done, please check.' });
    expect(add.status).toBe(201);
    const list = await request(app).get(`/api/tasks/${taskId}/comments`).set(auth('riya'));
    expect(list.body.data.some((c) => c.body === 'Done, please check.')).toBe(true);
    const forbidden = await request(app).delete(`/api/tasks/${taskId}/comments/${add.body.data.id}`).set(auth('kabir'));
    expect(forbidden.status).toBe(403);
    const del = await request(app).delete(`/api/tasks/${taskId}/comments/${add.body.data.id}`).set(auth('neha'));
    expect(del.status).toBe(200);
  });

  test('empty comment is rejected (422)', async () => {
    const res = await request(app).post(`/api/tasks/${taskId}/comments`).set(auth('neha')).send({ body: '   ' });
    expect(res.status).toBe(422);
  });

  test('timer: start, prevent double start, stop', async () => {
    const start = await request(app).post('/api/tasks/4/timer/start').set(auth('neha'));
    expect(start.status).toBe(200);
    expect(start.body.data.timer_started_at).not.toBeNull();
    expect(start.body.data.status).toBe('In Progress'); // To Do -> In Progress automatically
    const again = await request(app).post('/api/tasks/4/timer/start').set(auth('neha'));
    expect(again.status).toBe(409);
    const stop = await request(app).post('/api/tasks/4/timer/stop').set(auth('neha'));
    expect(stop.status).toBe(200);
    expect(stop.body.data.timer_started_at).toBeNull();
  });

  test('creator deletes the task', async () => {
    const res = await request(app).delete(`/api/tasks/${taskId}`).set(auth('riya'));
    expect(res.status).toBe(200);
    const after = await request(app).get(`/api/tasks/${taskId}`).set(auth('riya'));
    expect(after.status).toBe(404);
  });
});

describe('Favourites', () => {
  test('add, list and remove a favourite project', async () => {
    const add = await request(app).post('/api/favourites/2').set(auth('riya'));
    expect(add.status).toBe(200);
    const list = await request(app).get('/api/favourites').set(auth('riya'));
    expect(list.body.data.map((p) => p.id)).toContain(2);
    const filtered = await request(app).get('/api/projects?favourites=true').set(auth('riya'));
    expect(filtered.body.data.every((p) => p.is_favourite)).toBe(true);
    const del = await request(app).delete('/api/favourites/2').set(auth('riya'));
    expect(del.status).toBe(200);
  });

  test('cannot favourite a project you cannot access (403)', async () => {
    const res = await request(app).post('/api/favourites/5').set(auth('riya'));
    expect(res.status).toBe(403);
  });
});

describe('Dashboard', () => {
  test('returns database-driven statistics', async () => {
    const res = await request(app).get('/api/dashboard').set(auth('riya'));
    expect(res.status).toBe(200);
    const { tasks, projects } = res.body.data;
    expect(projects.total).toBe(4);
    expect(tasks.total).toBe(tasks.todo + tasks.in_progress + tasks.in_review + tasks.completed);
    expect(tasks.overdue).toBeGreaterThan(0);
  });

  test('a brand-new user gets an empty dashboard', async () => {
    const reg = await request(app).post('/api/auth/register').send({ name: 'New Person', email: 'new@example.com', password: 'Secret123' });
    const res = await request(app).get('/api/dashboard').set({ Authorization: `Bearer ${reg.body.data.token}` });
    expect(res.status).toBe(200);
    expect(res.body.data.projects.total).toBe(0);
  });
});
