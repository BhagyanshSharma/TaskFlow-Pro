// Registration, login and current-user endpoints (MongoDB + bcrypt + JWT)
const bcrypt = require('bcrypt');
const config = require('../config/env');
const { User, nextId } = require('../models');
const { signToken } = require('../middleware/auth');
const ApiError = require('../utils/ApiError');
const { ok, created } = require('../utils/response');
const { logActivity } = require('../services/activityService');

const AVATAR_COLOURS = ['#5B0888', '#7C3AED', '#2563EB', '#0F766E', '#B45309', '#BE185D', '#4338CA'];
// Used to keep login timing similar whether or not the email exists
const DUMMY_HASH = '$2b$10$CwTycUXWue0Thq9StjUM0uJ8.ZBQyZ6bHX4V8nM2o5S5H6p3f5JvW';

// Accepts a MongoDB document (with _id) or an already shaped user (with id)
function publicUser(u) {
  return {
    id: u.id ?? u._id,
    name: u.name,
    email: u.email,
    role: u.role,
    job_title: u.job_title ?? null,
    bio: u.bio ?? null,
    avatar_color: u.avatar_color,
    created_at: u.created_at,
  };
}

async function register(req, res) {
  const { name, email, password } = req.body;

  const existing = await User.exists({ email: email.toLowerCase() });
  if (existing) throw ApiError.conflict('An account with this email already exists.');

  const passwordHash = await bcrypt.hash(password, config.bcryptRounds);
  const colour = AVATAR_COLOURS[Math.floor(Math.random() * AVATAR_COLOURS.length)];

  let doc;
  try {
    doc = await User.create({
      _id: await nextId('users'),
      name,
      email,
      password_hash: passwordHash,
      avatar_color: colour,
    });
  } catch (err) {
    // Two sign-ups with the same email at the same moment: the unique index stops the second one
    if (err.code === 11000) throw ApiError.conflict('An account with this email already exists.');
    throw err;
  }

  const user = publicUser(doc.toObject());
  await logActivity({
    actor: user,
    action: 'user.registered',
    entityType: 'user',
    description: `${user.name} created an account`,
  });

  // The UI sends users to the login page after registering (register -> login -> dashboard),
  // but a token is returned too so API clients can continue immediately.
  return created(res, { user, token: signToken(user) }, 'Registration successful. You can now log in.');
}

async function login(req, res) {
  const { email, password } = req.body;
  const doc = await User.findOne({ email: email.toLowerCase() }).lean();

  const valid = await bcrypt.compare(password, doc ? doc.password_hash : DUMMY_HASH);
  if (!doc || !valid) throw ApiError.unauthorized('Invalid email or password.');

  const user = publicUser(doc);
  return ok(res, { user, token: signToken(user) }, `Welcome back, ${user.name}!`);
}

async function me(req, res) {
  return ok(res, { user: publicUser(req.user) });
}

module.exports = { register, login, me, publicUser };
