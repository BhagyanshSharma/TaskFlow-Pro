// Project CRUD + membership + favourites (MongoDB), with activity logging
const { Project, ProjectMember, Task, Comment, Favourite, TimeLog, User, nextId } = require('../models');
const ApiError = require('../utils/ApiError');
const { ok, created } = require('../utils/response');
const { getPagination, buildMeta } = require('../utils/pagination');
const { calculateProgress, completionRate } = require('../utils/progress');
const { normaliseDate, escapeRegex } = require('../utils/dates');
const { logActivity } = require('../services/activityService');
const { taskStatsFor, memberCountsFor } = require('../services/statsService');
const {
  getProjectAccess,
  requireProjectManager,
  requireProjectOwner,
  accessibleProjectIds,
} = require('../services/accessService');

const PRIORITY_ORDER = ['Urgent', 'High', 'Medium', 'Low'];
const ROLE_ORDER = ['owner', 'manager', 'member'];

function shapeProject(doc, extra) {
  const s = extra.stats;
  const counts = { todo: s.todo, in_progress: s.in_progress, in_review: s.in_review, completed: s.completed };
  return {
    id: doc._id,
    name: doc.name,
    description: doc.description ?? null,
    status: doc.status,
    priority: doc.priority,
    start_date: doc.start_date ?? null,
    deadline: doc.deadline ?? null,
    owner: { id: doc.owner_id, name: extra.ownerName },
    my_role: extra.myRole || null,
    is_favourite: Boolean(extra.isFavourite),
    member_count: extra.memberCount || 0,
    task_counts: { total: s.total_tasks, ...counts, overdue: s.overdue },
    progress: calculateProgress(counts),
    completion_rate: completionRate(counts.completed, s.total_tasks),
    created_at: doc.created_at,
    updated_at: doc.updated_at,
  };
}

// Adds owner name, my role, favourite flag and task counters to a list of project documents
async function shapeProjects(docs, userId) {
  const ids = docs.map((d) => d._id);
  const ownerIds = [...new Set(docs.map((d) => d.owner_id))];
  const [owners, myRoles, favs, stats, memberCounts] = await Promise.all([
    User.find({ _id: { $in: ownerIds } }, { name: 1 }).lean(),
    ProjectMember.find({ project_id: { $in: ids }, user_id: userId }, { project_id: 1, role: 1 }).lean(),
    Favourite.find({ project_id: { $in: ids }, user_id: userId }, { project_id: 1 }).lean(),
    taskStatsFor(ids),
    memberCountsFor(ids),
  ]);
  const ownerName = new Map(owners.map((u) => [u._id, u.name]));
  const roleOf = new Map(myRoles.map((m) => [m.project_id, m.role]));
  const favSet = new Set(favs.map((f) => f.project_id));
  return docs.map((d) =>
    shapeProject(d, {
      ownerName: ownerName.get(d.owner_id) || null,
      myRole: roleOf.get(d._id),
      isFavourite: favSet.has(d._id),
      memberCount: memberCounts.get(d._id),
      stats: stats.get(d._id),
    })
  );
}

const time = (v) => (v ? new Date(v).getTime() : 0);

const SORTS = {
  updated: (a, b) => time(b.updated_at) - time(a.updated_at),
  created: (a, b) => time(b.created_at) - time(a.created_at),
  name: (a, b) => a.name.localeCompare(b.name, undefined, { sensitivity: 'base' }),
  deadline: (a, b) => {
    if (!a.deadline && !b.deadline) return 0;
    if (!a.deadline) return 1; // projects without a deadline go last
    if (!b.deadline) return -1;
    return a.deadline < b.deadline ? -1 : a.deadline > b.deadline ? 1 : 0;
  },
  priority: (a, b) => PRIORITY_ORDER.indexOf(a.priority) - PRIORITY_ORDER.indexOf(b.priority),
  progress: (a, b) => b.progress - a.progress,
};

// GET /api/projects?q=&status=&priority=&favourites=true&sort=&page=&limit=
async function listProjects(req, res) {
  const { page, limit, offset } = getPagination(req.query, 12, 100);
  const filter = {};

  // Non-admins only see projects they belong to
  const ids = await accessibleProjectIds(req.user);
  if (ids !== null) filter._id = { $in: ids };

  if (req.query.q) {
    const pattern = new RegExp(escapeRegex(String(req.query.q).trim()), 'i');
    filter.$or = [{ name: pattern }, { description: pattern }];
  }
  if (req.query.status) filter.status = req.query.status;
  if (req.query.priority) filter.priority = req.query.priority;
  if (req.query.favourites === 'true') {
    const favs = await Favourite.find({ user_id: req.user.id }, { project_id: 1 }).lean();
    const favIds = favs.map((f) => f.project_id);
    filter._id = ids === null ? { $in: favIds } : { $in: favIds.filter((id) => ids.includes(id)) };
  }

  const docs = await Project.find(filter).lean();
  const shaped = await shapeProjects(docs, req.user.id);
  const compare = SORTS[req.query.sort] || SORTS.updated;
  shaped.sort((a, b) => compare(a, b) || b.id - a.id);

  const pageItems = shaped.slice(offset, offset + limit);
  return ok(res, pageItems, 'Projects loaded', { pagination: buildMeta(page, limit, shaped.length) });
}

async function loadProject(projectId, userId) {
  const doc = await Project.findById(Number(projectId)).lean();
  if (!doc) return null;
  const [project] = await shapeProjects([doc], userId);
  return project;
}

async function loadMembers(projectId) {
  const pid = Number(projectId);
  const members = await ProjectMember.find({ project_id: pid }).lean();
  const userIds = members.map((m) => m.user_id);
  const [users, openTasks] = await Promise.all([
    User.find({ _id: { $in: userIds } }, { name: 1, email: 1, avatar_color: 1, job_title: 1 }).lean(),
    Task.find({ project_id: pid, assignee_id: { $in: userIds }, status: { $ne: 'Completed' } }, { assignee_id: 1 }).lean(),
  ]);
  const userById = new Map(users.map((u) => [u._id, u]));
  const openCount = new Map();
  for (const t of openTasks) openCount.set(t.assignee_id, (openCount.get(t.assignee_id) || 0) + 1);

  return members
    .filter((m) => userById.has(m.user_id))
    .map((m) => {
      const u = userById.get(m.user_id);
      return {
        id: u._id,
        name: u.name,
        email: u.email,
        avatar_color: u.avatar_color,
        job_title: u.job_title ?? null,
        role: m.role,
        joined_at: m.joined_at,
        open_tasks: openCount.get(u._id) || 0,
      };
    })
    .sort((a, b) => ROLE_ORDER.indexOf(a.role) - ROLE_ORDER.indexOf(b.role) || a.name.localeCompare(b.name));
}

// GET /api/projects/:id
async function getProject(req, res) {
  const { role } = await getProjectAccess(req.user, req.params.id);
  const project = await loadProject(req.params.id, req.user.id);
  project.my_role = role;
  project.members = await loadMembers(req.params.id);
  return ok(res, project);
}

// POST /api/projects
async function createProject(req, res) {
  const { name, description = null, status = 'Planning', priority = 'Medium' } = req.body;
  const startDate = normaliseDate(req.body.start_date) ?? null;
  const deadline = normaliseDate(req.body.deadline) ?? null;
  const memberIds = [...new Set((req.body.member_ids || []).map(Number).filter((id) => id !== req.user.id))];

  // Check every member exists before writing anything
  if (memberIds.length) {
    const found = await User.find({ _id: { $in: memberIds } }, { _id: 1 }).lean();
    const foundIds = new Set(found.map((u) => u._id));
    const missing = memberIds.find((id) => !foundIds.has(id));
    if (missing) throw ApiError.badRequest(`User ${missing} does not exist.`);
  }

  const projectId = await nextId('projects');
  await Project.create({
    _id: projectId,
    name,
    description: description || null,
    status,
    priority,
    start_date: startDate,
    deadline,
    owner_id: req.user.id,
  });
  await ProjectMember.insertMany([
    { project_id: projectId, user_id: req.user.id, role: 'owner' },
    ...memberIds.map((uid) => ({ project_id: projectId, user_id: uid, role: 'member' })),
  ]);

  await logActivity({
    actor: req.user,
    action: 'project.created',
    entityType: 'project',
    projectId,
    description: `${req.user.name} created project "${name}"`,
    metadata: { status, priority, deadline },
  });

  const project = await loadProject(projectId, req.user.id);
  project.members = await loadMembers(projectId);
  return created(res, project, 'Project created successfully.');
}

// PUT /api/projects/:id
async function updateProject(req, res) {
  const { project: existingRef } = await requireProjectManager(req.user, req.params.id);
  const existing = await Project.findById(existingRef.id).lean();

  const updates = {};
  for (const key of ['name', 'description', 'status', 'priority']) {
    if (req.body[key] !== undefined) updates[key] = req.body[key] === '' && key === 'description' ? null : req.body[key];
  }
  for (const key of ['start_date', 'deadline']) {
    const v = normaliseDate(req.body[key]);
    if (v !== undefined) updates[key] = v;
  }
  if (!Object.keys(updates).length) throw ApiError.badRequest('Nothing to update.');

  // Cross-field date check against values already stored
  const start = updates.start_date !== undefined ? updates.start_date : existing.start_date;
  const end = updates.deadline !== undefined ? updates.deadline : existing.deadline;
  if (start && end && end < start) throw ApiError.badRequest('Deadline cannot be before the start date.');

  const changes = {};
  for (const [k, v] of Object.entries(updates)) {
    if (String(existing[k] ?? '') !== String(v ?? '')) changes[k] = { from: existing[k] ?? null, to: v };
  }

  await Project.updateOne({ _id: existing._id }, { $set: updates }, { runValidators: true });

  if (Object.keys(changes).length) {
    await logActivity({
      actor: req.user,
      action: 'project.updated',
      entityType: 'project',
      projectId: existingRef.id,
      description: `${req.user.name} updated ${Object.keys(changes).join(', ').replace(/_/g, ' ')} of "${updates.name || existing.name}"`,
      metadata: { changes },
    });
  }

  const project = await loadProject(existing._id, req.user.id);
  project.members = await loadMembers(existing._id);
  return ok(res, project, 'Project updated successfully.');
}

// Removes a project and everything that belongs to it
async function deleteProjectCascade(projectId) {
  const taskIds = (await Task.find({ project_id: projectId }, { _id: 1 }).lean()).map((t) => t._id);
  await Promise.all([
    Comment.deleteMany({ task_id: { $in: taskIds } }),
    TimeLog.deleteMany({ task_id: { $in: taskIds } }),
    Task.deleteMany({ project_id: projectId }),
    ProjectMember.deleteMany({ project_id: projectId }),
    Favourite.deleteMany({ project_id: projectId }),
  ]);
  await Project.deleteOne({ _id: projectId });
}

// DELETE /api/projects/:id
async function deleteProject(req, res) {
  const { project } = await requireProjectOwner(req.user, req.params.id);
  await deleteProjectCascade(project.id);
  await logActivity({
    actor: req.user,
    action: 'project.deleted',
    entityType: 'project',
    projectId: project.id,
    description: `${req.user.name} deleted project "${project.name}"`,
  });
  return ok(res, { id: project.id }, 'Project deleted.');
}

/* ----------------------------- Members ----------------------------- */

// GET /api/projects/:id/members
async function listMembers(req, res) {
  await getProjectAccess(req.user, req.params.id);
  return ok(res, await loadMembers(req.params.id));
}

// POST /api/projects/:id/members  { user_id | email, role }
async function addMember(req, res) {
  const { project } = await requireProjectManager(req.user, req.params.id);
  const role = req.body.role || 'member';

  const member = req.body.user_id
    ? await User.findById(Number(req.body.user_id), { name: 1, email: 1 }).lean()
    : await User.findOne({ email: String(req.body.email).toLowerCase() }, { name: 1, email: 1 }).lean();
  if (!member) throw ApiError.notFound('No registered user found with that email/id.');

  const already = await ProjectMember.exists({ project_id: project.id, user_id: member._id });
  if (already) throw ApiError.conflict(`${member.name} is already a member of this project.`);

  await ProjectMember.create({ project_id: project.id, user_id: member._id, role });
  await logActivity({
    actor: req.user,
    action: 'member.added',
    entityType: 'member',
    projectId: project.id,
    description: `${req.user.name} added ${member.name} to "${project.name}" as ${role}`,
    metadata: { userId: member._id, role },
  });
  return created(res, await loadMembers(project.id), `${member.name} added to the project.`);
}

async function findMembership(projectId, userId) {
  const membership = await ProjectMember.findOne({ project_id: projectId, user_id: Number(userId) }).lean();
  if (!membership) return null;
  const user = await User.findById(membership.user_id, { name: 1 }).lean();
  return { role: membership.role, name: user ? user.name : 'Unknown user' };
}

// PATCH /api/projects/:id/members/:userId  { role }
async function updateMemberRole(req, res) {
  const { project } = await requireProjectOwner(req.user, req.params.id);
  const target = await findMembership(project.id, req.params.userId);
  if (!target) throw ApiError.notFound('That user is not a member of this project.');
  if (target.role === 'owner') throw ApiError.badRequest("The owner's role cannot be changed.");

  await ProjectMember.updateOne({ project_id: project.id, user_id: Number(req.params.userId) }, { $set: { role: req.body.role } });
  await logActivity({
    actor: req.user,
    action: 'member.updated',
    entityType: 'member',
    projectId: project.id,
    description: `${req.user.name} changed ${target.name}'s role to ${req.body.role}`,
    metadata: { userId: Number(req.params.userId), from: target.role, to: req.body.role },
  });
  return ok(res, await loadMembers(project.id), 'Member role updated.');
}

// DELETE /api/projects/:id/members/:userId  (managers remove others, anyone can leave)
async function removeMember(req, res) {
  const userId = Number(req.params.userId);
  const isSelf = userId === req.user.id;
  const { project } = isSelf
    ? await getProjectAccess(req.user, req.params.id)
    : await requireProjectManager(req.user, req.params.id);

  const target = await findMembership(project.id, userId);
  if (!target) throw ApiError.notFound('That user is not a member of this project.');
  if (target.role === 'owner') throw ApiError.badRequest('The project owner cannot be removed.');

  await ProjectMember.deleteOne({ project_id: project.id, user_id: userId });
  // Their open tasks in this project become unassigned
  await Task.updateMany({ project_id: project.id, assignee_id: userId }, { $set: { assignee_id: null } });
  await Favourite.deleteMany({ project_id: project.id, user_id: userId });

  await logActivity({
    actor: req.user,
    action: 'member.removed',
    entityType: 'member',
    projectId: project.id,
    description: isSelf ? `${req.user.name} left "${project.name}"` : `${req.user.name} removed ${target.name} from "${project.name}"`,
    metadata: { userId },
  });
  return ok(res, await loadMembers(project.id), isSelf ? 'You left the project.' : `${target.name} removed from the project.`);
}

/* ---------------------------- Favourites ---------------------------- */

// GET /api/favourites
async function listFavourites(req, res) {
  const favs = await Favourite.find({ user_id: req.user.id }).sort({ created_at: -1 }).lean();
  const order = favs.map((f) => f.project_id);
  const docs = await Project.find({ _id: { $in: order } }).lean();
  const shaped = await shapeProjects(docs, req.user.id);
  shaped.sort((a, b) => order.indexOf(a.id) - order.indexOf(b.id));
  return ok(res, shaped);
}

// POST /api/favourites/:projectId
async function addFavourite(req, res) {
  const { project } = await getProjectAccess(req.user, req.params.projectId);
  await Favourite.updateOne(
    { user_id: req.user.id, project_id: project.id },
    { $setOnInsert: { created_at: new Date() } },
    { upsert: true }
  );
  await logActivity({
    actor: req.user,
    action: 'project.favourited',
    entityType: 'project',
    projectId: project.id,
    description: `${req.user.name} added "${project.name}" to favourites`,
  });
  return ok(res, { project_id: project.id, is_favourite: true }, 'Added to favourites.');
}

// DELETE /api/favourites/:projectId
async function removeFavourite(req, res) {
  const { project } = await getProjectAccess(req.user, req.params.projectId);
  await Favourite.deleteOne({ user_id: req.user.id, project_id: project.id });
  await logActivity({
    actor: req.user,
    action: 'project.unfavourited',
    entityType: 'project',
    projectId: project.id,
    description: `${req.user.name} removed "${project.name}" from favourites`,
  });
  return ok(res, { project_id: project.id, is_favourite: false }, 'Removed from favourites.');
}

module.exports = {
  listProjects,
  getProject,
  createProject,
  updateProject,
  deleteProject,
  listMembers,
  addMember,
  updateMemberRole,
  removeMember,
  listFavourites,
  addFavourite,
  removeFavourite,
};
