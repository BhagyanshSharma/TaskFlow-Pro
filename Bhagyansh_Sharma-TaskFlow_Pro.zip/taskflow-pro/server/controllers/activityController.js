// Activity / audit log endpoints (MongoDB via Mongoose).
//  - System entries are created automatically by other controllers.
//  - Users can create, edit and delete their own manual project notes (full CRUD).
//  - Admins can delete any entry.
const ActivityLog = require('../models/ActivityLog');
const ApiError = require('../utils/ApiError');
const { ok, created } = require('../utils/response');
const { getPagination, buildMeta } = require('../utils/pagination');
const { ensureMongo } = require('../services/activityService');
const { accessibleProjectIds, getProjectAccess, getTaskAccess } = require('../services/accessService');

async function visibilityFilter(user) {
  const ids = await accessibleProjectIds(user);
  if (ids === null) return {}; // admin
  return { $or: [{ projectId: { $in: ids } }, { projectId: null, 'actor.id': user.id }] };
}

// GET /api/activities?project_id=&task_id=&entity_type=&page=&limit=
async function listActivities(req, res) {
  ensureMongo();
  const { page, limit, offset } = getPagination(req.query, 20, 100);
  const filter = await visibilityFilter(req.user);

  if (req.query.project_id) {
    await getProjectAccess(req.user, req.query.project_id);
    filter.projectId = Number(req.query.project_id);
  }
  if (req.query.task_id) {
    await getTaskAccess(req.user, req.query.task_id);
    filter.taskId = Number(req.query.task_id);
  }
  if (req.query.entity_type) filter.entityType = req.query.entity_type;

  const [items, total] = await Promise.all([
    ActivityLog.find(filter).sort({ createdAt: -1 }).skip(offset).limit(limit),
    ActivityLog.countDocuments(filter),
  ]);
  return ok(res, items.map((d) => d.toJSON()), 'Activity loaded', { pagination: buildMeta(page, limit, total) });
}

async function findVisible(req) {
  const doc = await ActivityLog.findById(req.params.id);
  if (!doc) throw ApiError.notFound('Activity entry not found.');
  if (req.user.role !== 'admin') {
    if (doc.projectId) await getProjectAccess(req.user, doc.projectId);
    else if (doc.actor.id !== req.user.id) throw ApiError.forbidden();
  }
  return doc;
}

// GET /api/activities/:id
async function getActivity(req, res) {
  ensureMongo();
  const doc = await findVisible(req);
  return ok(res, doc.toJSON());
}

// POST /api/activities  { project_id, task_id?, description }  -> manual note
async function createNote(req, res) {
  ensureMongo();
  const { project } = await getProjectAccess(req.user, req.body.project_id);
  if (req.body.task_id) {
    const { task } = await getTaskAccess(req.user, req.body.task_id);
    if (task.project_id !== project.id) throw ApiError.badRequest('Task does not belong to this project.');
  }
  const doc = await ActivityLog.create({
    actor: { id: req.user.id, name: req.user.name },
    action: 'note.created',
    entityType: 'note',
    projectId: project.id,
    taskId: req.body.task_id || null,
    description: req.body.description,
    metadata: { projectName: project.name },
    editable: true,
  });
  return created(res, doc.toJSON(), 'Note added to the activity log.');
}

// PUT /api/activities/:id  { description }  -> only the author's own notes
async function updateNote(req, res) {
  ensureMongo();
  const doc = await findVisible(req);
  if (!doc.editable) throw ApiError.forbidden('System audit entries cannot be edited.');
  if (doc.actor.id !== req.user.id) throw ApiError.forbidden('You can only edit your own notes.');
  doc.description = req.body.description;
  doc.metadata = { ...(doc.metadata || {}), editedAt: new Date().toISOString() };
  doc.markModified('metadata');
  await doc.save();
  return ok(res, doc.toJSON(), 'Note updated.');
}

// DELETE /api/activities/:id
async function deleteActivity(req, res) {
  ensureMongo();
  const doc = await findVisible(req);
  const isAdmin = req.user.role === 'admin';
  if (!isAdmin) {
    if (!doc.editable) throw ApiError.forbidden('System audit entries can only be removed by an administrator.');
    if (doc.actor.id !== req.user.id) throw ApiError.forbidden('You can only delete your own notes.');
  }
  await doc.deleteOne();
  return ok(res, { id: req.params.id }, 'Activity entry deleted.');
}

module.exports = { listActivities, getActivity, createNote, updateNote, deleteActivity };
