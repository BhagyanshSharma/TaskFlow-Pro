// Profile management + user search (used when adding project members)
const bcrypt = require('bcrypt');
const config = require('../config/env');
const { User } = require('../models');
const ApiError = require('../utils/ApiError');
const { ok } = require('../utils/response');
const { escapeRegex } = require('../utils/dates');
const { publicUser } = require('./authController');
const { logActivity } = require('../services/activityService');

async function updateProfile(req, res) {
  const allowed = ['name', 'job_title', 'bio', 'avatar_color'];
  const updates = {};
  for (const key of allowed) {
    if (req.body[key] !== undefined) {
      updates[key] = req.body[key] === '' && key !== 'name' ? null : req.body[key];
    }
  }
  if (!Object.keys(updates).length) throw ApiError.badRequest('Nothing to update.');

  const doc = await User.findByIdAndUpdate(req.user.id, { $set: updates }, { new: true, runValidators: true }).lean();
  const user = publicUser(doc);
  await logActivity({ actor: user, action: 'user.updated', entityType: 'user', description: `${user.name} updated their profile` });
  return ok(res, { user }, 'Profile updated.');
}

async function changePassword(req, res) {
  const { currentPassword, newPassword } = req.body;
  const row = await User.findById(req.user.id, { password_hash: 1 }).lean();
  const valid = await bcrypt.compare(currentPassword, row.password_hash);
  if (!valid) throw ApiError.badRequest('Current password is incorrect.');
  if (currentPassword === newPassword) throw ApiError.badRequest('New password must be different from the current one.');

  const hash = await bcrypt.hash(newPassword, config.bcryptRounds);
  await User.updateOne({ _id: req.user.id }, { $set: { password_hash: hash } });
  return ok(res, null, 'Password changed successfully.');
}

// GET /api/users/search?q=ana  -> minimal public fields only
async function searchUsers(req, res) {
  const q = String(req.query.q || '').trim();
  if (q.length < 2) return ok(res, []);
  const pattern = new RegExp(escapeRegex(q), 'i');
  const rows = await User.find(
    { $or: [{ name: pattern }, { email: pattern }] },
    { name: 1, email: 1, avatar_color: 1, job_title: 1 }
  )
    .sort({ name: 1 })
    .limit(10)
    .lean();
  return ok(
    res,
    rows.map((u) => ({ id: u._id, name: u.name, email: u.email, avatar_color: u.avatar_color, job_title: u.job_title ?? null }))
  );
}

module.exports = { updateProfile, changePassword, searchUsers };
