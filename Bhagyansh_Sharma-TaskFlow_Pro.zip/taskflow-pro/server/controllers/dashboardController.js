// Dashboard statistics - every number is calculated from the MongoDB data
const { Project, Task, User } = require('../models');
const { ok } = require('../utils/response');
const { calculateProgress, completionRate } = require('../utils/progress');
const { todayISO, addDays, daysBetween } = require('../utils/dates');
const { accessibleProjectIds } = require('../services/accessService');
const { recentForProjects } = require('../services/activityService');
const { isMongoReady } = require('../config/mongo');

const byDueAsc = (a, b) => {
  if (!a.due_date && !b.due_date) return a._id - b._id;
  if (!a.due_date) return 1;
  if (!b.due_date) return -1;
  return a.due_date < b.due_date ? -1 : a.due_date > b.due_date ? 1 : a._id - b._id;
};

// GET /api/dashboard
async function getDashboard(req, res) {
  const ids = await accessibleProjectIds(req.user);
  if (ids !== null && ids.length === 0) {
    const data = emptyDashboard();
    data.recent_activity = await recentForProjects([], { limit: 8, actorId: req.user.id });
    return ok(res, data, 'Dashboard loaded');
  }

  const projectFilter = ids === null ? {} : { _id: { $in: ids } };
  const taskFilter = ids === null ? {} : { project_id: { $in: ids } };
  const [projects, tasks] = await Promise.all([
    Project.find(projectFilter, { name: 1, status: 1, priority: 1, deadline: 1 }).lean(),
    Task.find(taskFilter, { project_id: 1, title: 1, status: 1, priority: 1, due_date: 1, assignee_id: 1 }).lean(),
  ]);

  const today = todayISO();
  const in14Days = addDays(today, 14);
  const projectName = new Map(projects.map((p) => [p._id, p.name]));
  const isOpen = (t) => t.status !== 'Completed';
  const isOverdue = (t) => isOpen(t) && t.due_date && t.due_date < today;

  const statusCounts = { todo: 0, in_progress: 0, in_review: 0, completed: 0 };
  const key = { 'To Do': 'todo', 'In Progress': 'in_progress', 'In Review': 'in_review', Completed: 'completed' };
  const perProject = new Map(projects.map((p) => [p._id, { todo: 0, in_progress: 0, in_review: 0, completed: 0 }]));
  const priorityCounts = { Low: 0, Medium: 0, High: 0, Urgent: 0 };
  let overdue = 0;
  let assignedToMe = 0;
  for (const t of tasks) {
    statusCounts[key[t.status]] += 1;
    const projectCounts = perProject.get(t.project_id);
    if (projectCounts) projectCounts[key[t.status]] += 1;
    if (isOpen(t)) priorityCounts[t.priority] += 1;
    if (isOverdue(t)) overdue += 1;
    if (t.assignee_id === req.user.id && isOpen(t)) assignedToMe += 1;
  }
  const totalTasks = tasks.length;

  // Names of assignees for the "upcoming deadlines" list
  const upcomingDocs = tasks
    .filter((t) => isOpen(t) && t.due_date && t.due_date >= today && t.due_date <= in14Days)
    .sort(byDueAsc)
    .slice(0, 8);
  const assignees = await User.find({ _id: { $in: upcomingDocs.map((t) => t.assignee_id).filter((v) => v != null) } }, { name: 1 }).lean();
  const assigneeName = new Map(assignees.map((u) => [u._id, u.name]));

  const projectProgress = projects
    .filter((p) => !['Completed', 'Cancelled'].includes(p.status))
    .sort((a, b) => byDueAsc({ _id: a._id, due_date: a.deadline }, { _id: b._id, due_date: b.deadline }))
    .slice(0, 6)
    .map((p) => {
      const counts = perProject.get(p._id);
      return {
        id: p._id,
        name: p.name,
        status: p.status,
        priority: p.priority,
        deadline: p.deadline ?? null,
        total_tasks: counts.todo + counts.in_progress + counts.in_review + counts.completed,
        completed_tasks: counts.completed,
        progress: calculateProgress(counts),
      };
    });

  const recentActivity = await recentForProjects(ids, { limit: 8, actorId: req.user.id });

  return ok(
    res,
    {
      projects: {
        total: projects.length,
        active: projects.filter((p) => p.status === 'Active').length,
        completed: projects.filter((p) => p.status === 'Completed').length,
        not_started_or_paused: projects.filter((p) => ['Planning', 'On Hold'].includes(p.status)).length,
      },
      tasks: {
        total: totalTasks,
        ...statusCounts,
        // "Pending" = not yet started (To Do)
        pending: statusCounts.todo,
        overdue,
        assigned_to_me: assignedToMe,
        completion_rate: completionRate(statusCounts.completed, totalTasks),
        overall_progress: calculateProgress(statusCounts),
      },
      priority_breakdown: ['Low', 'Medium', 'High', 'Urgent'].map((p) => ({ priority: p, count: priorityCounts[p] })),
      project_progress: projectProgress,
      upcoming_deadlines: upcomingDocs.map((t) => ({
        id: t._id,
        title: t.title,
        due_date: t.due_date,
        status: t.status,
        priority: t.priority,
        project_id: t.project_id,
        project_name: projectName.get(t.project_id) || null,
        assignee_name: t.assignee_id != null ? assigneeName.get(t.assignee_id) || null : null,
        days_left: daysBetween(today, t.due_date),
      })),
      overdue_tasks: tasks
        .filter(isOverdue)
        .sort(byDueAsc)
        .slice(0, 6)
        .map((t) => ({
          id: t._id,
          title: t.title,
          due_date: t.due_date,
          priority: t.priority,
          project_id: t.project_id,
          project_name: projectName.get(t.project_id) || null,
          days_overdue: daysBetween(t.due_date, today),
        })),
      my_tasks: tasks
        .filter((t) => t.assignee_id === req.user.id && isOpen(t))
        .sort(byDueAsc)
        .slice(0, 6)
        .map((t) => ({
          id: t._id,
          title: t.title,
          status: t.status,
          priority: t.priority,
          due_date: t.due_date ?? null,
          project_name: projectName.get(t.project_id) || null,
          project_id: t.project_id,
        })),
      recent_activity: recentActivity,
      activity_available: isMongoReady(),
    },
    'Dashboard loaded'
  );
}

function emptyDashboard() {
  return {
    projects: { total: 0, active: 0, completed: 0, not_started_or_paused: 0 },
    tasks: { total: 0, todo: 0, in_progress: 0, in_review: 0, completed: 0, pending: 0, overdue: 0, assigned_to_me: 0, completion_rate: 0, overall_progress: 0 },
    priority_breakdown: ['Low', 'Medium', 'High', 'Urgent'].map((p) => ({ priority: p, count: 0 })),
    project_progress: [],
    upcoming_deadlines: [],
    overdue_tasks: [],
    my_tasks: [],
    recent_activity: [],
    activity_available: isMongoReady(),
  };
}

module.exports = { getDashboard };
