// Task CRUD, comments and time tracking (MongoDB) with activity logging
const { Task, Project, User, Comment, TimeLog, nextId } = require('../models');
const ApiError = require('../utils/ApiError');
const { ok, created } = require('../utils/response');
const { getPagination, buildMeta } = require('../utils/pagination');
const { normaliseDate, todayISO, escapeRegex } = require('../utils/dates');
const { PRIORITY_RANK, TASK_STATUSES } = require('../utils/constants');
const { logActivity } = require('../services/activityService');
const {
  getProjectAccess,
  getTaskAccess,
  isProjectMember,
  accessibleProjectIds,
} = require('../services/accessService');

const seconds = (from, to) => Math.max(0, Math.floor((new Date(to || Date.now()) - new Date(from)) / 1000));

// Turns task documents into the JSON shape the client expects
// (project name, assignee, creator, overdue flag, comment count, tracked time, running timer).
async function shapeTasks(docs) {
  if (!docs.length) return [];
  const ids = docs.map((t) => t._id);
  const projectIds = [...new Set(docs.map((t) => t.project_id))];
  const userIds = [...new Set(docs.flatMap((t) => [t.assignee_id, t.created_by]).filter((v) => v != null))];

  const [projects, users, comments, logs] = await Promise.all([
    Project.find({ _id: { $in: projectIds } }, { name: 1 }).lean(),
    User.find({ _id: { $in: userIds } }, { name: 1, avatar_color: 1 }).lean(),
    Comment.find({ task_id: { $in: ids } }, { task_id: 1 }).lean(),
    TimeLog.find({ task_id: { $in: ids } }, { task_id: 1, started_at: 1, ended_at: 1 }).lean(),
  ]);
  const projectName = new Map(projects.map((p) => [p._id, p.name]));
  const userById = new Map(users.map((u) => [u._id, u]));
  const commentCount = new Map();
  for (const c of comments) commentCount.set(c.task_id, (commentCount.get(c.task_id) || 0) + 1);
  const tracked = new Map();
  const running = new Map();
  for (const l of logs) {
    tracked.set(l.task_id, (tracked.get(l.task_id) || 0) + seconds(l.started_at, l.ended_at));
    if (!l.ended_at) {
      const prev = running.get(l.task_id);
      if (!prev || l.started_at > prev) running.set(l.task_id, l.started_at);
    }
  }

  const today = todayISO();
  return docs.map((t) => {
    const assignee = t.assignee_id != null ? userById.get(t.assignee_id) : null;
    const creator = userById.get(t.created_by);
    const timer = running.get(t._id);
    return {
      id: t._id,
      project: { id: t.project_id, name: projectName.get(t.project_id) || null },
      title: t.title,
      description: t.description ?? null,
      status: t.status,
      priority: t.priority,
      due_date: t.due_date ?? null,
      is_overdue: Boolean(t.due_date && t.due_date < today && t.status !== 'Completed'),
      assignee: assignee ? { id: assignee._id, name: assignee.name, avatar_color: assignee.avatar_color } : null,
      created_by: { id: t.created_by, name: creator ? creator.name : null },
      comment_count: commentCount.get(t._id) || 0,
      tracked_seconds: tracked.get(t._id) || 0,
      // UTC timestamp of the running timer, or null (kept from the original start/stop tracker)
      timer_started_at: timer ? new Date(timer).toISOString() : null,
      completed_at: t.completed_at ?? null,
      created_at: t.created_at,
      updated_at: t.updated_at,
    };
  });
}

async function loadTask(id) {
  const doc = await Task.findById(Number(id)).lean();
  if (!doc) return null;
  const [task] = await shapeTasks([doc]);
  return task;
}

async function loadComments(taskId, filter = {}) {
  const rows = await Comment.find({ task_id: Number(taskId), ...filter }).sort({ created_at: 1, _id: 1 }).lean();
  const users = await User.find({ _id: { $in: [...new Set(rows.map((c) => c.user_id))] } }, { name: 1, avatar_color: 1 }).lean();
  const userById = new Map(users.map((u) => [u._id, u]));
  return rows.map((c) => ({
    id: c._id,
    body: c.body,
    created_at: c.created_at,
    updated_at: c.updated_at,
    user_id: c.user_id,
    user_name: userById.get(c.user_id)?.name || null,
    avatar_color: userById.get(c.user_id)?.avatar_color || null,
  }));
}

const time = (v) => (v ? new Date(v).getTime() : 0);
const STATUS_INDEX = (s) => TASK_STATUSES.indexOf(s);

// GET /api/tasks?project_id=&q=&status=&priority=&assignee=me|unassigned|<id>&overdue=true&sort=&order=&page=&limit=
async function listTasks(req, res) {
  const { page, limit, offset } = getPagination(req.query, 25, 200);
  const filter = {};

  if (req.query.project_id) {
    await getProjectAccess(req.user, req.query.project_id); // 403/404 if not allowed
    filter.project_id = Number(req.query.project_id);
  } else {
    const ids = await accessibleProjectIds(req.user);
    if (ids !== null) {
      if (!ids.length) {
        return ok(res, [], 'Tasks loaded', { pagination: buildMeta(page, limit, 0) });
      }
      filter.project_id = { $in: ids };
    }
  }

  if (req.query.q) {
    const pattern = new RegExp(escapeRegex(String(req.query.q).trim()), 'i');
    filter.$or = [{ title: pattern }, { description: pattern }];
  }
  if (req.query.status) filter.status = req.query.status;
  if (req.query.priority) filter.priority = req.query.priority;
  if (req.query.assignee === 'me') filter.assignee_id = req.user.id;
  else if (req.query.assignee === 'unassigned') filter.assignee_id = null;
  else if (req.query.assignee) filter.assignee_id = Number(req.query.assignee);
  if (req.query.overdue === 'true') {
    filter.due_date = { $ne: null, $lt: todayISO() };
    if (!filter.status) filter.status = { $ne: 'Completed' };
    else if (filter.status === 'Completed') filter._id = -1; // completed tasks are never overdue
  }

  const docs = await Task.find(filter).lean();

  const sort = req.query.sort || 'created';
  let order = req.query.order;
  if (!order) order = ['due_date', 'title'].includes(sort) ? 'asc' : 'desc';
  const dir = order === 'asc' ? 1 : -1;

  const comparators = {
    // Deadline sort shows open work first: completed tasks go to the end, tasks without a date after dated ones
    due_date: (a, b) => {
      const ca = a.status === 'Completed' ? 1 : 0;
      const cb = b.status === 'Completed' ? 1 : 0;
      if (ca !== cb) return ca - cb;
      if (!a.due_date && !b.due_date) return 0;
      if (!a.due_date) return 1;
      if (!b.due_date) return -1;
      return (a.due_date < b.due_date ? -1 : a.due_date > b.due_date ? 1 : 0) * dir;
    },
    priority: (a, b) => (PRIORITY_RANK[a.priority] - PRIORITY_RANK[b.priority]) * dir,
    status: (a, b) => (STATUS_INDEX(a.status) - STATUS_INDEX(b.status)) * dir,
    created: (a, b) => (time(a.created_at) - time(b.created_at)) * dir,
    updated: (a, b) => (time(a.updated_at) - time(b.updated_at)) * dir,
    title: (a, b) => a.title.localeCompare(b.title, undefined, { sensitivity: 'base' }) * dir,
  };
  const compare = comparators[sort] || comparators.created;
  docs.sort((a, b) => compare(a, b) || b._id - a._id);

  const items = await shapeTasks(docs.slice(offset, offset + limit));
  return ok(res, items, 'Tasks loaded', { pagination: buildMeta(page, limit, docs.length) });
}

// GET /api/tasks/:id   (task + comments + time logs + permissions for the UI)
async function getTask(req, res) {
  const access = await getTaskAccess(req.user, req.params.id);
  const task = await loadTask(access.task.id);
  task.comments = await loadComments(access.task.id);

  const logs = await TimeLog.find({ task_id: access.task.id }).sort({ started_at: -1 }).limit(20).lean();
  const logUsers = await User.find({ _id: { $in: [...new Set(logs.map((l) => l.user_id))] } }, { name: 1 }).lean();
  const nameOf = new Map(logUsers.map((u) => [u._id, u.name]));
  task.time_logs = logs.map((l) => ({
    id: l._id,
    started_at: l.started_at,
    ended_at: l.ended_at ?? null,
    user_name: nameOf.get(l.user_id) || null,
    seconds: seconds(l.started_at, l.ended_at),
  }));

  task.permissions = {
    role: access.role,
    can_edit: access.canEdit,
    can_delete: access.isManager || access.task.created_by === req.user.id,
    can_assign: access.isManager || access.task.created_by === req.user.id,
  };
  return ok(res, task);
}

async function assertAssignable(projectId, assigneeId) {
  if (!assigneeId) return;
  if (!(await isProjectMember(projectId, assigneeId))) {
    throw ApiError.badRequest('Tasks can only be assigned to members of the project.');
  }
}

// POST /api/tasks
async function createTask(req, res) {
  const { title, description = null, status = 'To Do', priority = 'Medium' } = req.body;
  const projectId = Number(req.body.project_id);
  const assigneeId = req.body.assignee_id ? Number(req.body.assignee_id) : null;
  const dueDate = normaliseDate(req.body.due_date) ?? null;

  const { project } = await getProjectAccess(req.user, projectId);
  await assertAssignable(projectId, assigneeId);

  const id = await nextId('tasks');
  await Task.create({
    _id: id,
    project_id: projectId,
    title,
    description: description || null,
    status,
    priority,
    assignee_id: assigneeId,
    created_by: req.user.id,
    due_date: dueDate,
    completed_at: status === 'Completed' ? new Date() : null,
  });
  const task = await loadTask(id);

  await logActivity({
    actor: req.user,
    action: 'task.created',
    entityType: 'task',
    projectId: project.id,
    taskId: task.id,
    description: `${req.user.name} created task "${title}" in "${project.name}"`,
    metadata: { status, priority, due_date: dueDate },
  });
  if (task.assignee) {
    await logActivity({
      actor: req.user,
      action: 'task.assigned',
      entityType: 'task',
      projectId: project.id,
      taskId: task.id,
      description: `${req.user.name} assigned "${title}" to ${task.assignee.name}`,
      metadata: { assigneeId: task.assignee.id },
    });
  }
  return created(res, task, 'Task created successfully.');
}

async function stopRunningTimer(taskId) {
  await TimeLog.updateMany({ task_id: taskId, ended_at: null }, { $set: { ended_at: new Date() } });
}

// PUT /api/tasks/:id
async function updateTask(req, res) {
  const access = await getTaskAccess(req.user, req.params.id);
  if (!access.canEdit) {
    throw ApiError.forbidden('Only the assignee, the creator or a project manager can edit this task.');
  }
  const existing = await Task.findById(access.task.id).lean();

  const updates = {};
  for (const key of ['title', 'description', 'status', 'priority']) {
    if (req.body[key] !== undefined) updates[key] = req.body[key] === '' && key === 'description' ? null : req.body[key];
  }
  const due = normaliseDate(req.body.due_date);
  if (due !== undefined) updates.due_date = due;

  if (req.body.assignee_id !== undefined) {
    const newAssignee = req.body.assignee_id === '' || req.body.assignee_id === null ? null : Number(req.body.assignee_id);
    if (newAssignee !== (existing.assignee_id ?? null)) {
      const canAssign = access.isManager || existing.created_by === req.user.id;
      if (!canAssign) throw ApiError.forbidden('Only the task creator or a project manager can reassign this task.');
      await assertAssignable(existing.project_id, newAssignee);
      updates.assignee_id = newAssignee;
    }
  }
  if (!Object.keys(updates).length) throw ApiError.badRequest('Nothing to update.');

  const statusChanged = updates.status && updates.status !== existing.status;
  if (statusChanged) {
    updates.completed_at = updates.status === 'Completed' ? new Date() : null;
  }

  await Task.updateOne({ _id: existing._id }, { $set: updates }, { runValidators: true });
  // Same behaviour as the original tool: completing a task stops its timer
  if (statusChanged && updates.status === 'Completed') await stopRunningTimer(existing._id);

  const task = await loadTask(existing._id);
  const base = { actor: req.user, entityType: 'task', projectId: existing.project_id, taskId: task.id };

  if (statusChanged) {
    await logActivity({
      ...base,
      action: 'task.status_changed',
      description: `${req.user.name} moved "${task.title}" from ${existing.status} to ${updates.status}`,
      metadata: { from: existing.status, to: updates.status },
    });
  }
  if (updates.assignee_id !== undefined) {
    await logActivity({
      ...base,
      action: 'task.assigned',
      description: task.assignee
        ? `${req.user.name} assigned "${task.title}" to ${task.assignee.name}`
        : `${req.user.name} unassigned "${task.title}"`,
      metadata: { from: existing.assignee_id ?? null, to: updates.assignee_id },
    });
  }
  const otherChanges = Object.keys(updates).filter(
    (k) => !['status', 'assignee_id', 'completed_at'].includes(k) && String(existing[k] ?? '') !== String(updates[k] ?? '')
  );
  if (otherChanges.length) {
    await logActivity({
      ...base,
      action: 'task.updated',
      description: `${req.user.name} updated ${otherChanges.join(', ').replace(/_/g, ' ')} of "${task.title}"`,
      metadata: { fields: otherChanges },
    });
  }

  return ok(res, task, 'Task updated successfully.');
}

// DELETE /api/tasks/:id
async function deleteTask(req, res) {
  const access = await getTaskAccess(req.user, req.params.id);
  if (!(access.isManager || access.task.created_by === req.user.id)) {
    throw ApiError.forbidden('Only the task creator or a project manager can delete this task.');
  }
  await Promise.all([
    Comment.deleteMany({ task_id: access.task.id }),
    TimeLog.deleteMany({ task_id: access.task.id }),
  ]);
  await Task.deleteOne({ _id: access.task.id });
  await logActivity({
    actor: req.user,
    action: 'task.deleted',
    entityType: 'task',
    projectId: access.task.project_id,
    taskId: access.task.id,
    description: `${req.user.name} deleted task "${access.task.title}"`,
  });
  return ok(res, { id: access.task.id }, 'Task deleted.');
}

/* ----------------------------- Comments ----------------------------- */

// GET /api/tasks/:id/comments
async function listComments(req, res) {
  const { task } = await getTaskAccess(req.user, req.params.id);
  return ok(res, await loadComments(task.id));
}

// POST /api/tasks/:id/comments  { body }
async function addComment(req, res) {
  const { task } = await getTaskAccess(req.user, req.params.id);
  const id = await nextId('comments');
  await Comment.create({ _id: id, task_id: task.id, user_id: req.user.id, body: req.body.body });
  const [comment] = await loadComments(task.id, { _id: id });
  await logActivity({
    actor: req.user,
    action: 'comment.added',
    entityType: 'comment',
    projectId: task.project_id,
    taskId: task.id,
    description: `${req.user.name} commented on "${task.title}"`,
    metadata: { commentId: comment.id, preview: req.body.body.slice(0, 80) },
  });
  return created(res, comment, 'Comment added.');
}

// DELETE /api/tasks/:id/comments/:commentId
async function deleteComment(req, res) {
  const access = await getTaskAccess(req.user, req.params.id);
  const comment = await Comment.findOne({ _id: Number(req.params.commentId), task_id: access.task.id }).lean();
  if (!comment) throw ApiError.notFound('Comment not found.');
  if (comment.user_id !== req.user.id && !access.isManager) {
    throw ApiError.forbidden('You can only delete your own comments.');
  }
  await Comment.deleteOne({ _id: comment._id });
  await logActivity({
    actor: req.user,
    action: 'comment.deleted',
    entityType: 'comment',
    projectId: access.task.project_id,
    taskId: access.task.id,
    description: `${req.user.name} deleted a comment on "${access.task.title}"`,
  });
  return ok(res, { id: comment._id }, 'Comment deleted.');
}

/* ---------------------------- Time tracking ---------------------------- */

// POST /api/tasks/:id/timer/start
async function startTimer(req, res) {
  const access = await getTaskAccess(req.user, req.params.id);
  if (!access.canEdit) throw ApiError.forbidden('Only the assignee, the creator or a project manager can track time on this task.');
  if (access.task.status === 'Completed') throw ApiError.badRequest('Completed tasks cannot be timed. Move it back to In Progress first.');

  const running = await TimeLog.exists({ task_id: access.task.id, ended_at: null });
  if (running) throw ApiError.conflict('The timer is already running for this task.');

  await TimeLog.create({ _id: await nextId('time_logs'), task_id: access.task.id, user_id: req.user.id, started_at: new Date(), ended_at: null });
  // Starting work on a "To Do" task moves it to "In Progress"
  if (access.task.status === 'To Do') {
    await Task.updateOne({ _id: access.task.id }, { $set: { status: 'In Progress' } });
  }
  await logActivity({
    actor: req.user,
    action: 'task.timer_started',
    entityType: 'task',
    projectId: access.task.project_id,
    taskId: access.task.id,
    description: `${req.user.name} started the timer on "${access.task.title}"`,
  });
  return ok(res, await loadTask(access.task.id), 'Timer started.');
}

// POST /api/tasks/:id/timer/stop
async function stopTimer(req, res) {
  const access = await getTaskAccess(req.user, req.params.id);
  if (!access.canEdit) throw ApiError.forbidden('Only the assignee, the creator or a project manager can track time on this task.');
  const running = await TimeLog.exists({ task_id: access.task.id, ended_at: null });
  if (!running) throw ApiError.badRequest('The timer is not running for this task.');

  await stopRunningTimer(access.task.id);
  const task = await loadTask(access.task.id);
  await logActivity({
    actor: req.user,
    action: 'task.timer_stopped',
    entityType: 'task',
    projectId: access.task.project_id,
    taskId: access.task.id,
    description: `${req.user.name} stopped the timer on "${access.task.title}"`,
    metadata: { totalSeconds: task.tracked_seconds },
  });
  return ok(res, task, 'Timer stopped.');
}

module.exports = {
  listTasks,
  getTask,
  createTask,
  updateTask,
  deleteTask,
  listComments,
  addComment,
  deleteComment,
  startTimer,
  stopTimer,
};
