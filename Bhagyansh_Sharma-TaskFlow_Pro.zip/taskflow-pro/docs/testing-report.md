# Testing Report

This report separates **tests that were actually executed** (with their observed results) from **tests you still need to run** on your own Windows computer and on the deployed site.

## Test environment used for the executed tests

| Item | Value |
|---|---|
| OS | Ubuntu 24.04 (Linux sandbox) |
| Node.js | 22.22.0 |
| MySQL | 8.0.46 (local server, databases `taskflow_pro` and `taskflow_test`) |
| MongoDB | **Not available in the sandbox** (MongoDB downloads were blocked). See section 1.2. |
| Browser | Chromium (Playwright 1.56, headless) |
| Date of run | 10 October 2026 |

---

## 1. Executed tests

### 1.1 Automated backend tests (Jest + Supertest, real MySQL)

Command: `cd server && npm test`

Result observed: **69 passed, 0 failed, 6 skipped** (4 suites). The 6 skipped tests are the MongoDB suite, which only runs when `TEST_MONGODB_URI` is set.

The integration tests rebuild `taskflow_test` from `database/mysql-schema.sql` plus the seed data before running, so they never touch your real data.

| # | Suite | Test | Result |
|---|---|---|---|
| 1 | Health | GET /api/health reports MySQL connected | Passed |
| 2 | Health | unknown route returns JSON 404 | Passed |
| 3 | Authentication | registers a new user with a hashed password | Passed |
| 4 | Authentication | rejects duplicate email registration (409) | Passed |
| 5 | Authentication | validates registration input (422) | Passed |
| 6 | Authentication | logs in with correct credentials | Passed |
| 7 | Authentication | rejects invalid password (401) | Passed |
| 8 | Authentication | rejects unknown email with the same message (401) | Passed |
| 9 | Authentication | GET /api/auth/me returns the current user | Passed |
| 10 | Authentication | protected route without token returns 401 | Passed |
| 11 | Authentication | tampered token returns 401 | Passed |
| 12 | Authentication | expired token returns 401 with session-expired message | Passed |
| 13 | Profile | updates profile details | Passed |
| 14 | Profile | rejects wrong current password on password change | Passed |
| 15 | Projects CRUD and permissions | lists only projects the user belongs to | Passed |
| 16 | Projects CRUD and permissions | searches and filters projects | Passed |
| 17 | Projects CRUD and permissions | creates a project and makes the creator the owner | Passed |
| 18 | Projects CRUD and permissions | rejects a deadline before the start date | Passed |
| 19 | Projects CRUD and permissions | rejects an invalid calendar date | Passed |
| 20 | Projects CRUD and permissions | member cannot edit the project (403) | Passed |
| 21 | Projects CRUD and permissions | non-member cannot view the project (403) | Passed |
| 22 | Projects CRUD and permissions | owner updates the project | Passed |
| 23 | Projects CRUD and permissions | project not found returns 404 | Passed |
| 24 | Projects CRUD and permissions | admin can see every project | Passed |
| 25 | Projects CRUD and permissions | manager cannot delete (only owner) | Passed |
| 26 | Projects CRUD and permissions | owner deletes the project | Passed |
| 27 | Members | manager adds a member by email | Passed |
| 28 | Members | adding an existing member returns 409 | Passed |
| 29 | Members | member cannot add members (403) | Passed |
| 30 | Members | owner cannot be removed | Passed |
| 31 | Members | removing a member unassigns their tasks in that project | Passed |
| 32 | Tasks CRUD, search, filters and sorting | creates a task assigned to a project member | Passed |
| 33 | Tasks CRUD, search, filters and sorting | validates missing title and project (422) | Passed |
| 34 | Tasks CRUD, search, filters and sorting | rejects an invalid due date (422) | Passed |
| 35 | Tasks CRUD, search, filters and sorting | cannot assign to a non-member (400) | Passed |
| 36 | Tasks CRUD, search, filters and sorting | non-member cannot create a task in the project (403) | Passed |
| 37 | Tasks CRUD, search, filters and sorting | searches tasks by text | Passed |
| 38 | Tasks CRUD, search, filters and sorting | filters by status, priority and assignee | Passed |
| 39 | Tasks CRUD, search, filters and sorting | filters overdue tasks | Passed |
| 40 | Tasks CRUD, search, filters and sorting | sorts by priority descending | Passed |
| 41 | Tasks CRUD, search, filters and sorting | sorts by due date ascending: open tasks first, earliest deadline first | Passed |
| 42 | Tasks CRUD, search, filters and sorting | paginates task lists | Passed |
| 43 | Tasks CRUD, search, filters and sorting | assignee can change status; completed_at is set | Passed |
| 44 | Tasks CRUD, search, filters and sorting | member who is not involved cannot edit the task (403) | Passed |
| 45 | Tasks CRUD, search, filters and sorting | assignee cannot reassign a task they did not create (403) | Passed |
| 46 | Tasks CRUD, search, filters and sorting | progress is a percentage independent of task count | Passed |
| 47 | Tasks CRUD, search, filters and sorting | comments: add, list and delete | Passed |
| 48 | Tasks CRUD, search, filters and sorting | empty comment is rejected (422) | Passed |
| 49 | Tasks CRUD, search, filters and sorting | timer: start, prevent double start, stop | Passed |
| 50 | Tasks CRUD, search, filters and sorting | creator deletes the task | Passed |
| 51 | Favourites | add, list and remove a favourite project | Passed |
| 52 | Favourites | cannot favourite a project you cannot access (403) | Passed |
| 53 | Dashboard | returns database-driven statistics | Passed |
| 54 | Dashboard | a brand-new user gets an empty dashboard | Passed |
| 55 | Activity log when MongoDB is not configured | activity endpoints return 503 but core features keep working | Passed |
| 56 | Activity log (MongoDB) | creating a task writes an audit entry | Skipped (needs MongoDB, see 1.2) |
| 57 | Activity log (MongoDB) | status change is logged with from/to metadata | Skipped (needs MongoDB, see 1.2) |
| 58 | Activity log (MongoDB) | note CRUD: create, read, update, delete | Skipped (needs MongoDB, see 1.2) |
| 59 | Activity log (MongoDB) | system entries cannot be edited by users | Skipped (needs MongoDB, see 1.2) |
| 60 | Activity log (MongoDB) | users cannot read activity of projects they are not in | Skipped (needs MongoDB, see 1.2) |
| 61 | Activity log (MongoDB) | invalid activity id returns 422 | Skipped (needs MongoDB, see 1.2) |
| 62 | ActivityLog model validation | valid document passes | Passed |
| 63 | ActivityLog model validation | unknown action and missing description fail | Passed |
| 64 | ActivityLog model validation | description longer than 500 characters fails | Passed |
| 65 | calculateProgress | returns 0 for a project with no tasks | Passed |
| 66 | calculateProgress | all completed = 100 | Passed |
| 67 | calculateProgress | weights statuses (To Do 0, In Progress 50%, In Review 75%, Completed 100%) | Passed |
| 68 | calculateProgress | is independent of task quantity | Passed |
| 69 | completionRate | handles zero | Passed |
| 70 | completionRate | rounds percentage | Passed |
| 71 | pagination | defaults and clamps values | Passed |
| 72 | pagination | meta | Passed |
| 73 | isValidISODate | accepts real dates | Passed |
| 74 | isValidISODate | rejects impossible dates | Passed |
| 75 | isValidISODate | rejects other formats | Passed |

### 1.2 MongoDB activity-log tests

Real MongoDB could not be installed in the sandbox. To still exercise the Mongoose code paths (connect, `create`, `find` with filters/sort/skip/limit, `countDocuments`, `save`, `deleteOne`, `insertMany`), the API was pointed at a **minimal in-memory stand-in that speaks the MongoDB wire protocol**. This stand-in was a temporary test tool and is not part of the project.

| What ran against the stand-in | Observed result |
|---|---|
| `TEST_MONGODB_URI=... npx jest tests/integration/activity.mongo.test.js` | 6 passed, 0 failed |
| `npm run db:seed` with `MONGODB_URI` set | 67 activity entries inserted |
| Postman folder "6. Activity log (MongoDB)" | All requests passed |
| Browser: add / edit / delete a project note | Passed |

**This is not a substitute for real MongoDB.** You must re-run these on local MongoDB or Atlas (section 2). The code uses only standard Mongoose calls, so no differences are expected, but it has not been verified against a real server.

### 1.3 Postman collection (run with Newman, the Postman command-line runner)

Command: `npx newman run docs/postman-collection.json -e docs/postman-environment.json`

| | Executed | Failed |
|---|---|---|
| Requests | 51 | 0 |
| Test scripts | 51 | 0 |
| Assertions | 69 | 0 |

Average response time 15 ms (local machine, not a performance measurement).

### 1.4 Browser walkthrough (Playwright, Chromium)

Desktop viewport 1440 x 900, mobile viewport 390 x 844. Result: **29 of 29 checks passed, no JavaScript errors in the console** (failed Google Fonts requests were excluded because the sandbox has no internet access).

| # | Check | Result |
|---|---|---|
| 1 | Visiting `/dashboard` while logged out redirects to `/login` | Passed |
| 2 | Login form shows "Email is required" on empty submit | Passed |
| 3 | Wrong password shows "Invalid email or password." | Passed |
| 4 | Register shows password-rule and "Passwords do not match" errors | Passed |
| 5 | Register > redirected to login with "Account created" message | Passed |
| 6 | Login > dashboard with empty state for a new user | Passed |
| 7 | Create project; deadline-before-start error shown first | Passed |
| 8 | Open project; add two tasks | Passed |
| 9 | Task form shows "Task title is required" | Passed |
| 10 | Move task to Completed on the board; progress updates to 50% | Passed |
| 11 | Task drawer: add comment, start timer, stop timer, history tab | Passed |
| 12 | Favourite a project; it appears in the sidebar | Passed |
| 13 | Project activity: add, edit and delete a note | Passed |
| 14 | Team tab: search "Neha" and add her as a member | Passed |
| 15 | Global search finds the task | Passed |
| 16 | Delete project with confirmation dialog | Passed |
| 17 | Log out | Passed |
| 18 | Seeded user dashboard loads with charts | Passed |
| 19 | Projects grid; status filter "Planning" shows exactly one project | Passed |
| 20 | Project Kanban board loads | Passed |
| 21 | Tasks list; "Overdue" chip shows only overdue rows | Passed |
| 22 | Activity page lists entries | Passed |
| 23 | Profile edit saves | Passed |
| 24 | Settings shows API / MySQL / MongoDB status | Passed |
| 25 | Non-member opening `/projects/5` sees "You do not have access" | Passed |
| 26 | Unknown URL shows the 404 page | Passed |
| 27 | Dark mode toggle | Passed |
| 28 | Mobile: no horizontal scrolling on 6 pages; hamburger menu opens | Passed |
| 29 | Invalid token in storage sends the user back to login | Passed |

### 1.5 Manual checks run with curl

| Check | Observed result |
|---|---|
| Stop MySQL, call `/api/health` | `503`, `"mysql":"disconnected"` |
| Stop MySQL, call `/api/projects` with a valid token | `503` "Database is unavailable. Please try again shortly." |
| Restart MySQL, call again | `200` (pool reconnects without restarting the API) |
| Request with `Origin: http://evil.example` | No `Access-Control-Allow-Origin` header (browser would block it) |
| Request with `Origin: http://localhost:5173` | `Access-Control-Allow-Origin: http://localhost:5173` |
| Start with `NODE_ENV=production` and no `JWT_SECRET` | Refuses to start: "JWT_SECRET is required in production" |
| Start with `NODE_ENV=production` and a short `JWT_SECRET` | Refuses to start: "must be at least 32 characters" |
| `VITE_API_URL=https://taskflow-pro-api.onrender.com/api npm run build` | Built bundle calls that URL; the only "localhost" text in the bundle is inside the Axios library, not app code |
| `npm run build` (client) | Build succeeded (144 modules) |

---

## 2. Tests you still need to run

Fill in the "Result" column yourself after running each one. Do not copy results from section 1.

| # | Test | How | Result |
|---|---|---|---|
| 1 | Backend tests on your Windows PC | `cd server` then `npm test` (MySQL running, `.env` filled) | |
| 2 | MongoDB tests against real MongoDB | `set TEST_MONGODB_URI=mongodb://127.0.0.1:27017/taskflow_activity_test` then `npm test` (PowerShell: `$env:TEST_MONGODB_URI="..."`) | |
| 3 | Seed with real MongoDB | `npm run db:reset` and check MongoDB Compass shows the `activitylogs` collection | |
| 4 | Postman collection on your PC | Import both JSON files, select the environment, run the collection | |
| 5 | Full UI walkthrough on your PC | Follow the demo sequence in `docs/viva-and-presentation-guide.md` | |
| 6 | Responsive check on a real phone | Open the deployed site on your phone | |
| 7 | Deployed health check | Open `https://<your-api>.onrender.com/api/health` | |
| 8 | Deployed register > login > dashboard | Use the deployed frontend URL | |
| 9 | CORS in production | Frontend loads data without "CORS" errors in the browser console | |
| 10 | Atlas activity log in production | Create a task on the deployed site, then see it in Activity | |
| 11 | Token expiry | Set `JWT_EXPIRES_IN=1m`, log in, wait 2 minutes, click anything: you should be sent to login | |

## 3. Known limitations found during testing

- The first request to a Render free web service after 15 minutes of inactivity can take 30 to 60 seconds (the service sleeps). This is a hosting limit, not a bug.
- Activity entries are written "best effort": if MongoDB is down, the MySQL change still succeeds and that one log entry is lost.
- Timers are per task (one running timer per task at a time), the same as in the original project.
