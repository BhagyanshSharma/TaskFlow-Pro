# Viva and Presentation Guide: TaskFlow Pro

Use this to prepare for the presentation and the viva. Read the explanations in your own words; examiners can tell when answers are memorised.

---

## 1. Short introduction (about 1 minute)

> "My project is TaskFlow Pro, a full-stack project management system. I started from my earlier Project Management Tool, which was only HTML, CSS and JavaScript and saved everything in the browser's LocalStorage. That meant no logins, no sharing between team members, and data lost when the browser was cleared.
>
> I rebuilt it as a React and Vite frontend talking to a Node.js and Express REST API. Users, projects, tasks, comments and time logs are stored in MySQL, and an activity history of who did what is stored in MongoDB. Users register and log in with bcrypt-hashed passwords and JWT tokens, and each project has owner, manager and member roles.
>
> The app has a live dashboard, projects with progress, a Kanban board, search, filters, favourites, task comments, a start/stop timer from my original project, and it works on phones as well as laptops. It covers all six Technical Training experiments in one application."

---

## 2. The project in simple language

- A **project** is a piece of work, like "Campus Event Portal". It has a deadline, a status and a team.
- A **task** is one job inside a project, like "Build registration API". It has a person assigned, a priority, a due date and a status: To Do, In Progress, In Review or Completed.
- The **dashboard** answers "how are we doing?": how many tasks are pending, in progress, completed or overdue, which deadlines are coming, and what changed recently.
- The **timer** records how long someone actually worked on a task.
- **Comments** let the team discuss a task in one place instead of WhatsApp.
- The **activity log** is a history: "Riya moved 'Build registration API' from In Progress to In Review, 2 hours ago".

---

## 3. System architecture

Three parts:

1. **Frontend (React in the browser).** Shows pages, collects input, and calls the API with Axios. It never talks to a database directly.
2. **Backend (Express on Node.js).** Receives HTTP requests, checks the JWT, validates input, checks permissions, runs SQL queries or MongoDB operations, and returns JSON.
3. **Databases.** MySQL for structured, related data; MongoDB for the activity log.

Flow for "create a task":

```
React form → Axios POST /api/tasks (JSON + Bearer token)
→ Express: validate body → verify JWT → check user is a project member
→ INSERT into MySQL tasks → write "task.created" document to MongoDB
→ respond 201 with the task → React shows it on the board + toast message
```

---

## 4. Database explanation

**Why MySQL for the main data?** Users, projects, members and tasks are related to each other. MySQL enforces those relations with foreign keys (a task must belong to an existing project), unique constraints (one account per email), transactions (create a project and its owner membership together), and cascading deletes (deleting a project deletes its tasks).

**The 7 MySQL tables:** `users`, `projects`, `project_members` (who is in which project and with which role), `tasks`, `task_comments`, `project_favourites`, `task_time_logs`.

**Why `project_members` is a separate table:** a user can be in many projects and a project has many users. That is a many-to-many relationship, which needs a junction table. The role (owner/manager/member) belongs to the relationship, so it is stored there.

**Why MongoDB for the activity log?** Each action stores different extra information (a status change stores from/to; a member addition stores the role). A MongoDB document can hold any shape in its `metadata` field without changing a schema. The log is mostly written, rarely changed, and can grow large without affecting the main tables.

**Normalisation:** no data is duplicated. Progress, task counts and overdue flags are calculated by queries rather than stored, so they are always correct.

---

## 5. Frontend-backend integration

- `client/src/api/client.js` creates one Axios instance. Its base URL comes from the environment variable `VITE_API_URL`.
- In development, Vite's proxy forwards `/api` to `http://localhost:5000`, so there are no CORS problems locally.
- A request interceptor adds `Authorization: Bearer <token>` to every request.
- A response interceptor watches for 401 errors: it clears the token and sends the user back to login.
- `client/src/api/services.js` has one function per endpoint, for example `taskApi.update(id, body)`.
- Pages use the custom `useAsync` hook to track loading, error and data, so every screen shows a loader, an error with "Try again", or the data.

---

## 6. Important REST APIs to explain

| Endpoint | What to say |
|---|---|
| `POST /api/auth/register` | Validates input, checks the email is not taken (409 if it is), hashes the password with bcrypt, inserts the user. |
| `POST /api/auth/login` | Finds the user, compares the password with `bcrypt.compare`, returns a signed JWT. Same error for wrong email or password so attackers cannot find valid emails. |
| `GET /api/projects` | Returns only projects where the user is a member, with task counts and progress, supporting search, filters, sorting and pages. |
| `PUT /api/tasks/:id` | Only the assignee, the creator or a manager can edit. Completing a task records `completed_at` and stops its timer. Every change is logged in MongoDB. |
| `GET /api/dashboard` | Several SQL aggregate queries run in parallel (`Promise.all`) and return all dashboard numbers in one response. |
| `POST /api/activities` | Creates a note document in MongoDB on a project timeline. |
| `GET /api/health` | Reports whether MySQL and MongoDB are connected; Render uses it to check the service is alive. |

HTTP methods: GET reads, POST creates, PUT updates, PATCH partially updates (used for member role), DELETE deletes.

---

## 7. Key concepts explained

**JWT (JSON Web Token).** A string with three parts: header, payload and signature. The payload holds the user id and expiry time. The server signs it with a secret key. On each request the server checks the signature; if anyone changed the token, the signature will not match. The server does not need to store sessions. In my app the token expires after one day.

**bcrypt.** A password hashing algorithm. It adds a random salt to each password and is deliberately slow (cost factor 10), so even if the database is stolen, cracking passwords is very expensive. You cannot "decrypt" a bcrypt hash; at login we hash the typed password the same way and compare.

**Axios.** A JavaScript library for HTTP requests. It converts JSON automatically, supports interceptors (I use them to attach the token and handle 401), and throws an error for non-2xx responses, which makes error handling simple.

**React Hooks.**
- `useState` stores values that change the screen (form fields, modal open/closed).
- `useEffect` runs code after rendering, such as loading data when a page opens.
- `useContext` reads shared data without passing props through every level; I use it for the logged-in user and the theme.
- Custom hooks: `useAsync` (load data with loading/error), `useDebounce` (wait until typing stops before searching), `useNow` (tick every second for the timer).

**CRUD.** Create, Read, Update, Delete: the four basic data operations. In SQL they are INSERT, SELECT, UPDATE, DELETE; in REST they are POST, GET, PUT, DELETE.

**REST API.** A way to design web APIs around resources (projects, tasks) identified by URLs, using HTTP methods for actions and status codes for results (200 OK, 201 Created, 401 not logged in, 403 not allowed, 404 not found, 422 invalid input). Each request is independent (stateless).

**MySQL.** A relational database: data in tables with rows and columns, related by keys, queried with SQL. I use the `mysql2` package with a connection pool (reuses up to 10 connections) and prepared statements (`?` placeholders) which prevent SQL injection.

**MongoDB.** A document database: data stored as JSON-like documents in collections. No fixed schema at database level; Mongoose adds a schema and validation in the application.

**Git.** A version control system that records snapshots (commits) of the code, so I can see history and go back to earlier versions.

**GitHub.** A website that hosts Git repositories online, for backup, sharing and connecting to deployment services like Render.

**Deployment.** Putting the app on a server on the internet. On Render the API runs as a web service (`npm start`) and the React app is built into static files (`npm run build`) served as a static site. Secrets go in environment variables on Render, not in the code.

**CORS.** Browsers block a page on one domain from reading responses from another domain unless the server allows it. My API allows only the frontend URL in `CORS_ORIGIN`.

**Environment variables.** Settings outside the code (database passwords, JWT secret, API URL). Locally they live in `.env` files, which are in `.gitignore`.

---

## 8. Frequently asked viva questions

**Q1. Why did you use two databases?**
MySQL is best for related, structured data that must stay consistent (foreign keys, transactions). The activity log has a different shape for each action and is written constantly, which fits MongoDB. It also let me demonstrate both experiments' databases in one real feature.

**Q2. What happens if MongoDB goes down?**
Projects and tasks still work because they are in MySQL. The activity service skips logging when MongoDB is not connected, the activity endpoints return 503, and the dashboard shows a message. The health endpoint reports MongoDB as disconnected.

**Q3. Where is the password stored?**
Only the bcrypt hash is stored in `users.password_hash`. The plain password is never saved or logged, and the API never returns the hash.

**Q4. How do you stop a user seeing another team's project?**
Every project query joins `project_members` with the logged-in user's id. For a single project, `accessService.getProjectAccess` returns 403 if the user is not a member (admins excepted).

**Q5. What is the difference between 401 and 403?**
401 means "we don't know who you are" (no token, invalid or expired token). 403 means "we know who you are, but you are not allowed" (for example, a member trying to delete a project).

**Q6. How is SQL injection prevented?**
All user values go through `?` placeholders in `pool.execute`, so MySQL treats them as data, not SQL. Sort columns are picked from a fixed list instead of being taken from the URL.

**Q7. Where is the JWT stored on the client and why?**
In `sessionStorage`, or `localStorage` if "Keep me signed in" is ticked. It is sent only in the Authorization header. Cookies were avoided because the frontend and API are on different Render subdomains, where browsers increasingly block third-party cookies. React escapes output, which reduces the XSS risk of storing tokens in web storage.

**Q8. How is progress calculated?**
Each task gets a weight by status (To Do 0, In Progress 0.5, In Review 0.75, Completed 1). Progress is the average weight times 100. Because it is a percentage, a project with 4 tasks and one with 40 can be compared fairly.

**Q9. What is a connection pool?**
A set of open database connections that are reused. Opening a new connection for each request is slow; the pool hands out an idle connection and takes it back afterwards.

**Q10. Why use transactions?**
When creating a project, the project row and the owner's membership row must both be saved, or neither. If the second insert fails, the transaction rolls back the first.

**Q11. What does `ON DELETE CASCADE` do?**
When a parent row is deleted, related child rows are deleted automatically. Deleting a project removes its tasks, comments, members and time logs.

**Q12. What is middleware in Express?**
A function that runs between receiving a request and sending the response. Mine include helmet (security headers), cors, the JSON parser, validators, `authenticate` (JWT check), and the error handler.

**Q13. What does the error handler do?**
Any error thrown in a controller reaches one function that converts it into the standard JSON shape with the right status code, for example a duplicate email error from MySQL (`ER_DUP_ENTRY`) becomes 409.

**Q14. What is the purpose of Vite?**
It runs the development server with instant reload and builds optimised production files. It also injects `VITE_` environment variables, which is how the frontend knows the API URL in production.

**Q15. How do protected routes work in React?**
`ProtectedRoute` checks the auth context. While the stored token is being checked, it shows a loader. If there is no user, it redirects to `/login`; otherwise it renders the page.

**Q16. How does the timer work?**
Starting inserts a row in `task_time_logs` with `started_at` and `ended_at = NULL`. Stopping sets `ended_at`. Total time is the sum of `TIMESTAMPDIFF` for all rows. The browser adds one second per tick to show a live clock. This is the same idea as the `logs` array in my original LocalStorage version, but now stored on the server.

**Q17. What did you keep from the original project?**
The purple colour and Young Serif heading font, the start/stop timer, status changes, SweetAlert confirmations, and the idea of a team chat, which became task comments.

**Q18. What bugs did the original have?**
Data only in LocalStorage, no login, IDs taken from array length (duplicates after delete), user input inserted with `innerHTML` (XSS risk), and chat history that never reloaded.

**Q19. How did you test the project?**
Jest and Supertest tests call the real API against a separate MySQL test database (69 tests pass). A Postman collection of 51 requests checks status codes and data. I also walked through the UI in a browser at desktop and phone sizes.

**Q20. What is pagination and why use it?**
Returning results in pages (`?page=2&limit=15`) instead of everything at once. It keeps responses fast when there are many tasks.

**Q21. What is debouncing?**
Waiting until the user stops typing (350 ms) before sending a search request, so typing "registration" sends one request instead of twelve.

**Q22. How would you scale this application?**
Run several API instances behind a load balancer (JWT makes this easy because there are no server sessions), add indexes as data grows, cache dashboard results, and use read replicas for MySQL.

**Q23. What is `helmet`?**
Middleware that sets security-related HTTP headers, for example to stop the page being embedded in another site's frame.

**Q24. Why rate limiting on login?**
To slow down attackers trying many passwords. After 50 attempts in 15 minutes from one IP, the API returns 429.

**Q25. What are the limitations?**
No real-time updates, no email/password reset, activity logging is skipped while MongoDB is down, and tokens cannot be revoked before expiry.

---

## 9. Demo sequence (about 10 minutes)

Before the viva:

- [ ] MySQL and MongoDB running (or Atlas connected).
- [ ] `cd server && npm run db:reset` for fresh demo data.
- [ ] Terminal 1: `cd server && npm run dev`. Terminal 2: `cd client && npm run dev`.
- [ ] If showing the deployed version, open `/api/health` a minute early to wake the free Render service.
- [ ] Postman open with the collection and environment imported.
- [ ] MySQL Workbench open on the `users` table; MongoDB Compass open on `activitylogs`.

| Step | Do this | Say this | Experiment |
|---|---|---|---|
| 1 | Open `http://localhost:5173/dashboard` while logged out | "Protected route: without a token I'm sent to login." | 6 |
| 2 | Click "Create an account", submit an empty form, then type a weak password | "Validation in React; the password rules update live." | 2 |
| 3 | Register properly | "The API hashed the password with bcrypt and I'm sent to login: register → login → dashboard." | 4, 6 |
| 4 | In Workbench, show the new user's `password_hash` | "Only the hash is stored." | 4 |
| 5 | Log out, log in as `riya@example.com` / `Demo@1234` | "JWT returned and stored; every request now carries it." | 4, 6 |
| 6 | Walk through the dashboard | "All numbers come from SQL aggregate queries; recent activity comes from MongoDB." | 5 |
| 7 | Projects: search "library", filter by status, star a project | "Server-side search and filters; favourites are stored in MySQL and appear in the sidebar." | 2, 5 |
| 8 | Create a project with the deadline before the start date, then fix it | "Validated in the browser and again on the server." | 2, 4 |
| 9 | Open "Campus Event Portal", drag a card to Completed | "Status saved through Axios; progress % recalculates." | 5 |
| 10 | Open a task: add a comment, start and stop the timer, open History | "Timer from my original project, now stored in MySQL; history from MongoDB." | 3, 5 |
| 11 | Team tab: add a member | "Only owners and managers can manage members." | 4 |
| 12 | Activity tab: add, edit, delete a note; show Compass | "This is the MongoDB CRUD from Experiment 3." | 3 |
| 13 | Resize the browser to phone width, open the menu | "Responsive layout; the table becomes cards." | 1 |
| 14 | Toggle dark mode | "Bootstrap 5.3 colour modes." | 1 |
| 15 | Postman: run "Login", then "Protected route without token (401)", then the whole collection | "API testing: 51 requests with assertions." | 3, 4 |
| 16 | Log in as `neha@example.com`, try to edit Campus Event Portal (no Edit button) or call the API in Postman | "Role-based permissions: members can't edit projects (403)." | 4 |
| 17 | Show GitHub repo, commit history, `render.yaml` and the deployed URL | "Version control and deployment configuration." | 6 |

If something fails during the demo, open Settings: it shows whether the API, MySQL and MongoDB are connected.
