# Phase 1: Analysis of the Original Project

## What was uploaded

`25MCI10119_Bhagyansh Sharma(front end tech project).zip` contained one folder, `Project-management-tool--main`, with five files:

| File | Lines | Purpose |
|---|---|---|
| `index.html` | 181 | Single page: header, "New User" form, user dropdown + "Delete User", "Add Task" modal, a chatbox, and a task table |
| `script.js` | 436 | `taskObj` object with all logic, stored in `localStorage` under the key `projects` |
| `style.css` | 205 | Purple header (`#5B0888`), Young Serif font, chatbox and table styling |
| `README.md` | 35 | Description written for the Bharat Intern internship task |
| `.vscode/settings.json` | 1 | Editor setting |

The original files are kept unchanged in `legacy-frontend/` for reference.

**Note:** the six Technical Training-II experiment PDFs mentioned in the brief were not part of the upload. The experiment mapping in `docs/experiment-mapping.md` follows the experiment descriptions written in the brief. Compare it against the actual PDFs before submitting and adjust wording if your teacher's PDFs list extra tasks.

## Features found in the original code

1. **"Projects" are really users.** `addProject()` creates an object `{ id, name, tasks: [] }` from a "User Name" field. The UI labels it "User", so each person owns a list of tasks.
2. **Tasks** have `name`, `status` (`Progress` or `Completed`), `isStarted`, `logs[]`, `started`, `ended`.
3. **Time tracking.** "Start" pushes `{ startTime, endTime: 0 }` into `logs`; "Stop" fills `endTime`. A `setInterval` ticks the running timer every second and shows `HH:MM:SS`.
4. **Status changes** through a dropdown: Start, Stop, Mark as Completed, Make in Progress Again, Delete.
5. **Confirmations** with SweetAlert ("Are you sure?").
6. **Chatbox** where you type a name and a message. Messages get a random colour and are written to `localStorage.chatHistory`, but loading history is commented out, so messages disappear on refresh.
7. **Bootstrap 4 + jQuery** for the modal.

## Problems and limitations found

| Area | Problem |
|---|---|
| Data storage | Everything lives in one browser's `localStorage`. Nothing is shared between users or devices, and clearing the browser deletes all data. |
| Identity | No registration, login or passwords even though the README describes them. Anyone with the page can delete any "user". |
| IDs | `id: data.length` and `id: tasks.length` produce duplicate IDs after a delete (delete item 0 of 2, add a new one, two items share id 1). |
| Security | Task names and user names are concatenated straight into HTML (`innerHTML`), so a name like `<img src=x onerror=alert(1)>` runs script (stored XSS). |
| Chat | History is saved but never loaded (the code is commented out); the chat is not linked to any task or project. |
| Timer | The 1-second interval writes the whole projects array to `localStorage` every second for every running task. |
| Script loading | `script.js` is loaded in `<head>` before jQuery/Bootstrap, relying on the `load` event. |
| Structure | One 436-line object mixes data access, HTML string building and event handling. |
| Missing | No projects (as a concept), priorities, due dates, assignment, search, filters, dashboard, roles, or validation beyond "field is empty". |

## What was kept and how it was upgraded

| Original idea | In TaskFlow Pro |
|---|---|
| Purple brand header `#5B0888`, Young Serif font | Brand colour and display font of the new UI (sidebar, headings, buttons) |
| User list + tasks per user | Real user accounts (MySQL `users`), projects with members, tasks assigned to members |
| Task status dropdown (Progress / Completed) | Four statuses (To Do, In Progress, In Review, Completed) on a Kanban board and in tables |
| Start/Stop timer with `logs[]` and HH:MM:SS display | `task_time_logs` table, `/timer/start` and `/timer/stop` endpoints, live HH:MM:SS clock, "completing a task stops the timer" rule kept |
| SweetAlert "Are you sure?" confirmations | SweetAlert2 confirmations for every destructive action |
| Chatbox | Task comments stored in MySQL (`task_comments`), linked to a task and to real users |
| "Delete User" deletes its tasks | Deleting a project cascades to its tasks, comments and time logs through foreign keys |

## Implementation plan that was followed

1. Design the MySQL schema (7 tables) and the MongoDB activity model.
2. Build the Express API: config, middleware (JWT, validation, errors, rate limit), access-control service, controllers, routes.
3. Seed script with fictional data and relative dates (so "overdue" and "upcoming" always exist).
4. Automated API tests with Jest + Supertest against a real MySQL test database.
5. React + Vite client: auth context, protected routes, Axios layer, layout, pages, components.
6. Browser walkthrough of every main flow, plus phone-width checks.
7. Postman collection, documentation, deployment configuration, report and viva guide.
