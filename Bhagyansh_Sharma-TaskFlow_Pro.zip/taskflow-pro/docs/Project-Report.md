# Cover Page

**CHANDIGARH UNIVERSITY**

University Institute of Computing

**PROJECT REPORT**

on

## TaskFlow Pro: Full-Stack Project Management System

Submitted in partial fulfilment of the requirements of the course

**Technical Training-II (25CAP-707)**

| | |
|---|---|
| Submitted by | Bhagyansh Sharma |
| UID | 25MCI10119 |
| Programme / Branch | Master of Computer Applications (MCA), AIML |
| Section / Group | 25MAM5-A |
| Semester | 3rd |
| Submitted to | [Faculty name] |
| Academic session | [Session, e.g. 2026-27] |
| Date of submission | [DD/MM/YYYY] |

\newpage

# Certificate

> [Placeholder. Use the certificate format prescribed by the department, if one is required.]

This is to certify that the project report entitled **"TaskFlow Pro: Full-Stack Project Management System"** submitted by **Bhagyansh Sharma (UID 25MCI10119)**, MCA (AIML), Section 25MAM5-A, in partial fulfilment of the requirements of the course Technical Training-II (25CAP-707), is a record of work carried out by the student under my supervision.

| | |
|---|---|
| Faculty signature | ______________________ |
| Name | [Faculty name] |
| Designation | [Designation] |
| Date | [DD/MM/YYYY] |

\newpage

# Acknowledgement

I would like to thank [Faculty name], my faculty for Technical Training-II, for the guidance given throughout the course and this project. The six laboratory experiments of the course, covering responsive frontends, React, Node.js with MongoDB, secure backends with MySQL, full-stack integration and deployment, provided the foundation on which this project was built.

I also thank the University Institute of Computing, Chandigarh University, for the laboratory facilities, and my classmates for their feedback while testing the application.

Bhagyansh Sharma
UID 25MCI10119

\newpage

# Abstract

Small teams, such as student project groups, often manage their work through chat messages and spreadsheets, which makes it hard to see who is doing what, what is late, and how far a project has progressed. My earlier Project Management Tool addressed part of this problem with a single-page HTML, CSS and JavaScript interface, but it stored everything in the browser's LocalStorage, had no user accounts, and could not be shared between team members.

This project upgrades that tool into **TaskFlow Pro**, a full-stack web application. The frontend is built with React and Vite, styled with Bootstrap 5, and communicates with a REST API built using Node.js and Express. Relational data (users, projects, memberships, tasks, comments, favourites and time logs) is stored in MySQL through the `mysql2` driver, while an activity and audit log is stored in MongoDB through Mongoose. Users register and log in with passwords hashed by bcrypt, and every private request is authorised with a JSON Web Token and checked against the user's role in the project (owner, manager or member).

The application provides a dashboard calculated from live database records, project and task CRUD operations, a Kanban board, search, filters, sorting, favourites, team management, task comments, a per-task start/stop timer carried over from the original project, and a project activity timeline. It is responsive across phone, tablet and desktop screens and supports a dark mode.

The backend was verified with 75 automated Jest and Supertest tests (69 run against MySQL; 6 MongoDB tests run only when a MongoDB URI is supplied), a Postman collection of 51 requests with 69 assertions, and a 29-step browser walkthrough. The project is prepared for deployment on Render with a hosted MySQL database and MongoDB Atlas. The work demonstrates every topic of the six Technical Training-II experiments in one working application.

**Keywords:** React, Vite, Node.js, Express, MySQL, MongoDB, JWT, bcrypt, REST API, project management.

\newpage

# 1. Introduction

Project management software helps a team plan work, divide it into tasks, assign responsibility, set deadlines and monitor progress. Commercial tools such as Trello, Jira and Asana are widely used, but building a smaller version end to end is an effective way to learn how a modern web application is put together: the user interface, the server, the databases, security and deployment.

My first version of a Project Management Tool was created during an internship task. It allowed a user to type names, add tasks under each name, start and stop a timer on a task, mark tasks as completed and chat in a simple chatbox. It was entirely client-side and saved data in LocalStorage.

TaskFlow Pro keeps the ideas that worked (task status changes, the time tracker, confirmation dialogs, the purple visual identity) and rebuilds the application as a client-server system with real accounts, two databases and an API that enforces permissions. The project also serves as a single demonstration of the topics covered in the six Technical Training-II experiments.

# 2. Problem Statement

The original Project Management Tool had the following problems:

1. **No shared or persistent storage.** Data lived in one browser's LocalStorage. Other team members could not see it, and clearing browser data deleted everything.
2. **No authentication.** There was no registration, login or password, so anyone with the page could add or delete users and tasks.
3. **No access control.** There was no idea of who owns a project or who is allowed to change it.
4. **Unsafe rendering.** User-entered names were inserted into the page with `innerHTML`, which allows stored cross-site scripting.
5. **Fragile identifiers.** IDs were generated from array length, so deleting and adding items could create duplicate IDs.
6. **Limited project features.** There were no projects as such, no priorities, due dates, assignment, search, filtering, dashboard statistics or history of changes.
7. **Chat not connected to work.** Chat messages were not linked to any task and were not reloaded after a refresh.

The problem addressed by this project is to design and build a secure, multi-user, database-backed project management system that solves these issues while preserving the useful parts of the original tool.

# 3. Objectives

1. Analyse the existing frontend project and preserve its useful features and visual identity.
2. Build a responsive single-page frontend with React, Vite and Bootstrap 5.
3. Build a REST API with Node.js and Express with consistent JSON responses, validation and centralised error handling.
4. Store relational data in a normalised MySQL schema using the `mysql2` driver with a connection pool.
5. Store an activity and audit log in MongoDB using Mongoose, with working create, read, update and delete operations.
6. Implement secure registration and login with bcrypt password hashing and JWT authentication, protected API endpoints and protected frontend routes.
7. Implement role-based permissions per project (owner, manager, member) and a global administrator role.
8. Provide a dashboard whose figures are computed from database records.
9. Implement project and task CRUD, team membership, comments, favourites, search, filtering, sorting and time tracking.
10. Test the system with automated tests, Postman and browser checks, and prepare it for deployment on Render with Git and GitHub.

# 4. Scope of the Project

**In scope**

- Multi-user web application accessed through a browser on desktop, tablet or phone.
- Account registration, login, logout, profile editing and password change.
- Projects with status, priority, start date, deadline, members and progress.
- Tasks with status, priority, assignee, due date, description, comments and time logs.
- Dashboard statistics, charts, upcoming and overdue deadlines.
- Activity history for projects and tasks, including user-written notes.
- Deployment configuration for Render, hosted MySQL and MongoDB Atlas.

**Out of scope (see Future Enhancements)**

- Real-time updates over WebSockets (other users see changes after a refresh or the next action).
- Email notifications and password reset by email.
- File attachments.
- Native mobile applications.

# 5. Hardware and Software Requirements

## 5.1 Hardware (development machine)

| Component | Minimum | Recommended |
|---|---|---|
| Processor | Dual-core, 64-bit | Quad-core |
| RAM | 4 GB | 8 GB or more |
| Free disk space | 3 GB | 5 GB |
| Network | Required for installing packages and deployment | Broadband |

## 5.2 Software

| Software | Version | Purpose |
|---|---|---|
| Windows 10/11 (or Linux/macOS) | | Operating system |
| Node.js | 20 LTS or newer (developed on 22) | JavaScript runtime for the API and build tools |
| npm | 10 | Package manager |
| MySQL Server + Workbench | 8.0 | Primary relational database |
| MongoDB Community Server + Compass (or Atlas) | 7 or newer | Activity log database |
| Visual Studio Code | Latest | Code editor |
| Git | Latest | Version control |
| Postman | Latest | API testing |
| Google Chrome / Microsoft Edge | Latest | Testing the frontend |

# 6. Technology Stack

| Layer | Technology | Why it was chosen |
|---|---|---|
| UI framework | React 18 | Component-based UI, hooks for state and side effects |
| Build tool | Vite 5 | Fast development server, production builds, environment variables |
| Routing | React Router 6 | Client-side pages and protected routes |
| HTTP client | Axios | Interceptors for tokens and error handling |
| Styling | Bootstrap 5.3, Bootstrap Icons, custom CSS | Responsive grid and components, colour modes for dark theme |
| Charts | Chart.js with react-chartjs-2 | Doughnut and bar charts on the dashboard |
| Feedback | react-hot-toast, SweetAlert2 | Toast messages and confirmation dialogs |
| Server | Node.js, Express 4 | Lightweight REST API framework |
| Validation | express-validator | Declarative request validation |
| Security | jsonwebtoken, bcrypt, helmet, cors, express-rate-limit | Authentication, password hashing, HTTP headers, origin control, brute-force limiting |
| Relational DB | MySQL 8 with mysql2/promise | Users, projects, tasks and related data with foreign keys |
| Document DB | MongoDB with Mongoose 8 | Flexible activity documents with varying metadata |
| Testing | Jest, Supertest, Postman/Newman | Automated API tests and collection runs |
| Deployment | Git, GitHub, Render | Version control and hosting |

# 7. System Architecture

TaskFlow Pro follows a three-tier client-server architecture.

![Figure 1: System architecture](images/architecture.png){ width=100% }

**Request flow example (changing a task's status):**

1. The user drags a card to "Completed" on the board. React updates the card immediately (optimistic update) and Axios sends `PUT /api/tasks/12` with `{ "status": "Completed" }` and the JWT.
2. Express validates the body with express-validator.
3. The `authenticate` middleware verifies the JWT and loads the user from MySQL.
4. The task controller asks the access service whether the user may edit this task (owner/manager, assignee or creator).
5. In a MySQL transaction, the task is updated, `completed_at` is set and any running timer is stopped.
6. The activity service writes a `task.status_changed` document to MongoDB with `{ from, to }` metadata.
7. The API responds with the updated task. If anything failed, the frontend rolls the card back and shows an error toast.

**Design decisions**

- **Two databases with clear roles.** MySQL holds data that has relationships and must stay consistent (foreign keys, cascading deletes, transactions). MongoDB holds an append-mostly log whose `metadata` field differs per action type, which suits a document store.
- **Activity logging is best effort.** If MongoDB is unavailable, the MySQL operation still succeeds and the activity endpoints return HTTP 503. The rest of the application keeps working.
- **Stateless authentication.** The server does not store sessions; each request carries a signed JWT, which suits horizontal scaling and hosting on Render.

# 8. Frontend Design and Component Architecture

## 8.1 Pages and routes

| Route | Page | Access |
|---|---|---|
| `/login` | Login | Public only (logged-in users are redirected) |
| `/register` | Register | Public only |
| `/dashboard` | Dashboard | Protected |
| `/projects` | Projects grid with filters | Protected |
| `/projects/:id` | Project detail: Tasks (board/list), Team, Activity, Overview tabs | Protected, project members |
| `/tasks` | All tasks across projects (list/board) | Protected |
| `/activity` | Activity log with filters and notes | Protected |
| `/profile` | Profile editing | Protected |
| `/settings` | Theme, password change, system status | Protected |
| `*` | 404 page | Public |

## 8.2 Component hierarchy

```
main.jsx
└─ BrowserRouter
   └─ ThemeProvider (light/dark, Bootstrap data-bs-theme)
      └─ AuthProvider (user, login, logout, token restore)
         └─ App (routes)
            ├─ PublicOnlyRoute → AuthLayout → Login | Register
            └─ ProtectedRoute → AppLayout
                 ├─ Sidebar (navigation, favourites)
                 ├─ Topbar (GlobalSearch, New task, theme, user menu)
                 ├─ <Outlet> → Dashboard | Projects | ProjectDetail | Tasks | Activity | Profile | Settings
                 ├─ TaskDrawer (task details, timer, comments, history)
                 └─ TaskFormModal (shared "New task")
```

Reusable components include `StatCard`, `ProgressBar`, `StatusBadge`, `PriorityBadge`, `DueBadge`, `Avatar`, `AvatarStack`, `Modal`, `EmptyState`, `ErrorState`, `Loader`, `Pagination`, `ProjectCard`, `ProjectFormModal`, `TaskFormModal`, `TaskTable`, `TaskBoard`, `TaskTimer`, `ActivityFeed`, `MemberManager` and `GlobalSearch`.

## 8.3 State management and hooks

- `useState` and `useEffect` for local component state and data loading.
- `useContext` through `AuthContext` (current user, login, logout) and `ThemeContext`.
- `useMemo` and `useCallback` to keep context values and handlers stable.
- Custom hooks: `useAsync` (loading, error, data, reload), `useDebounce` (search boxes call the API 350 ms after typing stops), `useNow` (ticks every second for running timers) and `useDocumentTitle`.
- The layout passes `openTask`, `openNewTask`, `version` and `bump` to pages through the router outlet context. When any change is saved, `bump()` increments `version`, and pages re-fetch their data.

## 8.4 API layer

`src/api/client.js` creates one Axios instance whose base URL comes from `VITE_API_URL` (default `/api`, which the Vite dev server proxies to `http://localhost:5000`). A request interceptor attaches the JWT; a response interceptor clears the token and signals the app to return to the login page when the API answers 401. `src/api/services.js` exposes one function per endpoint, so components never build URLs.

## 8.5 Visual design

The brand colour `#5B0888` and the Young Serif display font from the original project's header were kept and paired with the Inter typeface for body text. The interface uses a dark sidebar, a sticky top bar with global search, card-based content, colour-coded status and priority badges, and progress bars. Bootstrap 5.3 colour modes power the dark theme. Below 992 px the sidebar becomes a slide-in menu; below 768 px task tables turn into stacked cards and filter controls wrap into two columns.

# 9. Backend Architecture and REST API Design

## 9.1 Folder structure

| Folder | Responsibility |
|---|---|
| `config/` | Environment loading and validation (`env.js`), MySQL pool (`mysql.js`), MongoDB connection (`mongo.js`) |
| `middleware/` | `auth.js` (JWT verify, role check), `validate.js`, `errorHandler.js`, `rateLimit.js` |
| `validators/` | express-validator rule sets for auth, projects, tasks, activity |
| `services/` | `accessService.js` (permission rules), `activityService.js` (MongoDB logging) |
| `controllers/` | Request handlers for auth, users, projects, tasks, activity, dashboard |
| `routes/` | Express routers that combine validators, middleware and controllers |
| `models/` | Mongoose `ActivityLog` model |
| `utils/` | `ApiError`, response helpers, pagination, progress calculation, dates |
| `scripts/` | `initDb.js` (schema), `seed.js` (demo data) |
| `tests/` | Jest unit and integration tests |

`app.js` builds the Express application without listening on a port so tests can import it; `server.js` connects the databases, starts listening and closes connections cleanly on `SIGINT`/`SIGTERM`.

## 9.2 Response format and status codes

Every success response has the form `{ "success": true, "message": "...", "data": ... }`, with `pagination` added for paged lists. Every error has the form `{ "success": false, "message": "...", "errors": [...] }`. Status codes used: 200, 201, 400, 401, 403, 404, 409, 422, 429, 500 and 503.

## 9.3 Endpoint summary

| Area | Endpoints |
|---|---|
| System | `GET /api/health`, `GET /api/meta` |
| Authentication | `POST /api/auth/register`, `POST /api/auth/login`, `GET /api/auth/me` |
| Profile | `PUT /api/users/me`, `PUT /api/users/me/password`, `GET /api/users/search` |
| Dashboard | `GET /api/dashboard` |
| Projects | `GET/POST /api/projects`, `GET/PUT/DELETE /api/projects/:id` |
| Members | `GET/POST /api/projects/:id/members`, `PATCH/DELETE /api/projects/:id/members/:userId` |
| Favourites | `GET /api/favourites`, `POST/DELETE /api/favourites/:projectId` |
| Tasks | `GET/POST /api/tasks`, `GET/PUT/DELETE /api/tasks/:id` |
| Comments | `GET/POST /api/tasks/:id/comments`, `DELETE /api/tasks/:id/comments/:commentId` |
| Time tracking | `POST /api/tasks/:id/timer/start`, `POST /api/tasks/:id/timer/stop` |
| Activity | `GET/POST /api/activities`, `GET/PUT/DELETE /api/activities/:id` |

The full specification (request bodies, responses, errors) is in `docs/api-documentation.md`.

## 9.4 Search, filtering, sorting and pagination

List endpoints accept query parameters such as `q`, `status`, `priority`, `assignee`, `overdue`, `sort`, `order`, `page` and `limit`. Search uses parameterised `LIKE` conditions. Sort columns are chosen from a fixed allow-list, never taken directly from user input, which prevents SQL injection through `ORDER BY`. `limit` is capped (100 for projects and activity, 200 for tasks).

# 10. MySQL Database Design and Schema

## 10.1 Entity-relationship overview

![Figure 2: Entity-relationship diagram of the MySQL database](images/er-diagram.png){ width=100% }

`project_members` and `project_favourites` resolve the many-to-many relationships between users and projects.

## 10.2 Tables

**users**

| Column | Type | Constraints |
|---|---|---|
| id | INT UNSIGNED | PK, auto increment |
| name | VARCHAR(80) | NOT NULL |
| email | VARCHAR(120) | NOT NULL, UNIQUE |
| password_hash | VARCHAR(255) | NOT NULL (bcrypt hash only) |
| role | ENUM('user','admin') | default 'user' |
| job_title, bio, avatar_color | VARCHAR | optional profile fields |
| created_at, updated_at | TIMESTAMP | automatic |

**projects**

| Column | Type | Constraints |
|---|---|---|
| id | INT UNSIGNED | PK |
| name | VARCHAR(120) | NOT NULL |
| description | TEXT | |
| status | ENUM('Planning','Active','On Hold','Completed','Cancelled') | default 'Planning', indexed |
| priority | ENUM('Low','Medium','High','Urgent') | default 'Medium' |
| start_date, deadline | DATE | CHECK deadline >= start_date; deadline indexed |
| owner_id | INT UNSIGNED | FK → users(id) ON DELETE CASCADE, indexed |

**project_members**: composite PK (`project_id`, `user_id`); `role` ENUM('owner','manager','member'); FKs to projects and users with cascade; index on `user_id`.

**tasks**

| Column | Type | Constraints |
|---|---|---|
| id | INT UNSIGNED | PK |
| project_id | INT UNSIGNED | FK → projects, cascade; composite index (project_id, status) |
| title | VARCHAR(160) | NOT NULL |
| description | TEXT | |
| status | ENUM('To Do','In Progress','In Review','Completed') | default 'To Do' |
| priority | ENUM('Low','Medium','High','Urgent') | indexed |
| assignee_id | INT UNSIGNED | FK → users ON DELETE SET NULL, indexed |
| created_by | INT UNSIGNED | FK → users, cascade |
| due_date | DATE | indexed |
| completed_at | DATETIME | set when status becomes Completed |

**task_comments**: `id`, `task_id` (FK, cascade), `user_id` (FK, cascade), `body` VARCHAR(2000), timestamps; index (`task_id`, `created_at`).

**project_favourites**: composite PK (`user_id`, `project_id`), both FKs cascade.

**task_time_logs**: `id`, `task_id` (FK, cascade), `user_id` (FK), `started_at` DATETIME, `ended_at` DATETIME NULL (NULL = timer running); index (`task_id`, `ended_at`). This table replaces the `logs[]` array of the original LocalStorage version.

## 10.3 Normalisation

All tables are in third normal form: every non-key column depends only on the table's key. Membership roles are stored on the relationship (`project_members.role`) rather than duplicated in users or projects. Derived values (progress, counts, overdue flags, tracked time) are calculated in queries instead of being stored, so they can never become inconsistent.

## 10.4 Integrity rules enforced by the database

- Unique email per user.
- Deleting a project removes its memberships, tasks, comments, favourites and time logs (`ON DELETE CASCADE`).
- Deleting a user unassigns their tasks (`ON DELETE SET NULL` on `assignee_id`).
- A project deadline cannot be earlier than its start date (CHECK constraint, also validated in the API).
- Status and priority values are restricted by ENUM types.

# 11. MongoDB Activity-Log Design

**Collection:** `activitylogs` (model `ActivityLog`).

| Field | Type | Notes |
|---|---|---|
| `_id` | ObjectId | Returned to the client as `id` |
| `actor.id`, `actor.name` | Number, String | Who performed the action (name copied so history stays readable even if the user is renamed) |
| `action` | String (enum of 20 values) | e.g. `project.created`, `task.status_changed`, `member.added`, `comment.added`, `note.created` |
| `entityType` | String enum | `user`, `project`, `task`, `comment`, `member`, `note` |
| `projectId`, `taskId` | Number or null | Links to MySQL rows |
| `description` | String, 2 to 500 chars | Human-readable sentence shown in the UI |
| `metadata` | Mixed | Action-specific data, e.g. `{ from: "To Do", to: "In Progress" }` |
| `editable` | Boolean | `true` only for user notes |
| `createdAt`, `updatedAt` | Date | Mongoose timestamps |

**Indexes:** `{ projectId: 1, createdAt: -1 }` for project timelines, `{ createdAt: -1 }` for the global feed, plus single-field indexes on `actor.id`, `projectId` and `taskId`.

**CRUD:** system entries are created automatically by the controllers; users read them through the activity endpoints; users create, update and delete their own notes; administrators may delete any entry. System entries cannot be edited, which keeps the audit trail trustworthy.

**Why MongoDB here:** each action carries different metadata, entries are written far more often than they are changed, and the log grows independently of the relational data. A document collection handles this without schema changes for each new action type.

# 12. Authentication and Security

| Measure | Implementation |
|---|---|
| Password storage | bcrypt with a configurable cost factor (10 by default); plaintext passwords are never stored or logged |
| Password policy | 8 to 72 characters with at least one letter and one number (checked in the browser and on the server) |
| Login | Same error message for unknown email and wrong password; a dummy bcrypt comparison keeps response times similar |
| Tokens | JWT signed with `JWT_SECRET`, includes issuer and expiry (`1d` by default); the API refuses to start in production without a secret of at least 32 characters |
| Token handling in the browser | Sent only in the `Authorization` header; kept in `sessionStorage` (cleared when the browser closes) or in `localStorage` when the user ticks "Keep me signed in"; validated on page load with `/api/auth/me`; removed on logout or any 401 response |
| Authorisation | Every private route uses the `authenticate` middleware; the user is re-loaded from MySQL each time so deleted accounts lose access immediately; project and task permissions are checked in `accessService.js` |
| Input validation | express-validator on all bodies, params and query strings; Mongoose schema validation for activity documents |
| SQL injection | All values are passed as `?` placeholders in prepared statements; sort columns come from allow-lists |
| XSS | React escapes all rendered text (the original `innerHTML` pattern was removed) |
| HTTP hardening | helmet security headers, `x-powered-by` disabled, 100 kB JSON body limit |
| CORS | Only origins listed in `CORS_ORIGIN` receive CORS headers |
| Brute-force protection | Rate limit of 50 login/register attempts per 15 minutes per IP |
| Secrets | Stored in environment variables; `.env` files are excluded by `.gitignore`; only `.env.example` templates are committed |
| Error leakage | Stack traces are never returned in production |

**Trade-off noted:** storing a JWT in web storage means a successful XSS attack could read it. React's escaping and the absence of `dangerouslySetInnerHTML` reduce this risk. An httpOnly cookie was not used because the frontend and API are deployed on different `onrender.com` subdomains, where third-party cookie restrictions in modern browsers would make cookie-based sessions unreliable.

# 13. Functional Modules

1. **Authentication module:** register, login, logout, session restore, protected and public-only routes.
2. **Dashboard module:** six statistic cards (projects, total tasks, pending, in progress, completed, overdue), status doughnut chart, open-tasks-by-priority bar chart, project progress list, upcoming deadlines (14 days), overdue tasks, my open tasks and recent activity.
3. **Project module:** grid of project cards with progress, search, status/priority filters, favourites filter, sorting, pagination; create/edit modal with date validation; delete with confirmation; detail page with statistics and tabs.
4. **Task module:** Kanban board with drag-and-drop and a move menu, list view with inline status change, search, filters (project, status, priority, assignee, overdue), sorting, pagination; create/edit modal; task drawer with details, comments, history and time logs.
5. **Time-tracking module:** start/stop timer with confirmation, live HH:MM:SS clock, session list; starting a "To Do" task moves it to "In Progress", completing a task stops its timer.
6. **Team module:** member list with open-task counts, add by search or email, role change (owner only), remove member (their tasks become unassigned), leave project.
7. **Collaboration module:** task comments; project notes in the activity timeline.
8. **Activity module:** global and per-project activity feeds with filters and pagination.
9. **Profile and settings module:** edit name, job title, bio and avatar colour; change password; light/dark theme; API and database status.

# 14. Implementation Details

## 14.1 Progress calculation

Progress is a percentage so that projects with different numbers of tasks can be compared. Each task contributes a weight according to its status, and the weights are averaged:

| Status | Weight |
|---|---|
| To Do | 0 |
| In Progress | 0.5 |
| In Review | 0.75 |
| Completed | 1 |

```js
// server/utils/progress.js
function calculateProgress(counts) {
  const total = counts.todo + counts.in_progress + counts.in_review + counts.completed;
  if (total === 0) return 0;
  const weighted = counts.in_progress * 0.5 + counts.in_review * 0.75 + counts.completed * 1;
  return Math.round((weighted / total) * 100);
}
```

For example, a project with one task in each status has progress (0 + 0.5 + 0.75 + 1) / 4 = 56%. A project with 1 To Do and 1 Completed task and a project with 100 of each both show 50%. The plain completion rate (completed / total) is shown alongside.

## 14.2 Protecting a route on the server

```js
// server/routes/taskRoutes.js
router.use(authenticate);                                   // JWT required for every task route
router.put('/:id', v.updateTaskRules, validate, h(ctrl.updateTask));
```

```js
// server/controllers/taskController.js (extract)
const access = await getTaskAccess(req.user, req.params.id); // 404 if missing, 403 if not a member
if (!access.canEdit) {
  throw ApiError.forbidden('Only the assignee, the creator or a project manager can edit this task.');
}
```

## 14.3 Protecting a route in React

```jsx
// client/src/routes/ProtectedRoute.jsx
export function ProtectedRoute() {
  const { isAuthenticated, checking } = useAuth();
  const location = useLocation();
  if (checking) return <FullPageLoader />;
  if (!isAuthenticated) return <Navigate to="/login" replace state={{ from: location }} />;
  return <Outlet />;
}
```

## 14.4 Writing to MongoDB without blocking MySQL work

```js
// server/services/activityService.js
async function logActivity({ actor, action, entityType, projectId = null, taskId = null, description, metadata = {} }) {
  if (!isMongoReady()) return null;          // MongoDB down: skip, the MySQL change already succeeded
  try {
    return await ActivityLog.create({ actor: { id: actor.id, name: actor.name }, action, entityType, projectId, taskId, description, metadata });
  } catch (err) {
    console.warn('[activity] failed to write log:', err.message);
    return null;
  }
}
```

## 14.5 Dashboard query (extract)

```sql
SELECT COUNT(*) AS total,
       SUM(t.status = 'To Do')        AS todo,
       SUM(t.status = 'In Progress')  AS in_progress,
       SUM(t.status = 'In Review')    AS in_review,
       SUM(t.status = 'Completed')    AS completed,
       SUM(t.due_date < CURDATE() AND t.status <> 'Completed') AS overdue
  FROM tasks t
 WHERE t.project_id IN (?, ?, ?);   -- only projects the user belongs to
```

## 14.6 Seed data

`server/scripts/seed.js` inserts five fictional users (all with the password `Demo@1234`, stored as a bcrypt hash), five projects, eighteen tasks, comments, favourites and time logs. Dates are written relative to the current day (`DATE_ADD(CURDATE(), INTERVAL n DAY)`), so the demo always contains overdue and upcoming work. The same SQL is exported to `database/seed.sql`.

# 15. Screenshots

> Insert screenshots taken from **your own** running copy of the application (local or deployed). Replace each placeholder with the image and keep the caption.
>
> Reference screenshots captured during development testing in a Linux sandbox are in `docs/screenshots/`. They show the same screens but use fallback fonts because the sandbox had no internet access. Prefer your own screenshots for submission.

| No. | Screen | What it should show | Screenshot |
|---|---|---|---|
| 15.1 | Login page | Brand panel, login form, validation message | [Insert screenshot] |
| 15.2 | Registration page | Password rules ticking green, mismatch error | [Insert screenshot] |
| 15.3 | Dashboard | Six statistic cards, charts, progress, deadlines, activity | [Insert screenshot] |
| 15.4 | Projects page | Project cards with progress and favourites, filter bar | [Insert screenshot] |
| 15.5 | Create project modal | Form with dates and validation | [Insert screenshot] |
| 15.6 | Project board | Kanban columns with task cards | [Insert screenshot] |
| 15.7 | Task drawer | Details, running timer, comments | [Insert screenshot] |
| 15.8 | Tasks list | Filters, overdue rows, status dropdowns | [Insert screenshot] |
| 15.9 | Team tab | Members with roles, add-member search | [Insert screenshot] |
| 15.10 | Activity page | MongoDB activity feed and note form | [Insert screenshot] |
| 15.11 | Profile page | Profile card and edit form | [Insert screenshot] |
| 15.12 | Dark mode | Any page in dark theme | [Insert screenshot] |
| 15.13 | Mobile view | Dashboard or tasks on a phone-width screen | [Insert screenshot] |
| 15.14 | Postman | Collection run summary | [Insert screenshot] |
| 15.15 | MySQL Workbench | `users` table showing bcrypt hashes | [Insert screenshot] |
| 15.16 | MongoDB Compass / Atlas | `activitylogs` documents | [Insert screenshot] |
| 15.17 | GitHub | Repository page and commit history | [Insert screenshot] |
| 15.18 | Render | Both services "Live" and the health check response | [Insert screenshot] |

# 16. Testing Strategy and Results

## 16.1 Strategy

| Level | Tool | What it covers |
|---|---|---|
| Unit tests | Jest | Progress calculation, completion rate, pagination, date validation, Mongoose model validation |
| API integration tests | Jest + Supertest | Real HTTP requests against the Express app with a real MySQL test database (`taskflow_test`), rebuilt from the schema and seed before each run |
| MongoDB integration tests | Jest + Supertest | Audit entries written by task actions, note CRUD, permission checks (run when `TEST_MONGODB_URI` is set) |
| API collection tests | Postman (run with Newman) | 51 requests in order: health, auth, projects, members, favourites, tasks, timer, comments, dashboard, activity, cleanup |
| UI tests | Playwright (Chromium) | 29 end-to-end checks covering the main user journeys at desktop and phone sizes |
| Manual checks | curl, browser | Database outage, CORS, production configuration |

## 16.2 Results observed during development

These results were recorded in the development environment described in `docs/testing-report.md` (Ubuntu, Node.js 22, MySQL 8.0.46). Real MongoDB was not available there; the MongoDB tests were run against a temporary wire-protocol test stand-in and **must be re-run against real MongoDB** (see 16.3).

| Test set | Result |
|---|---|
| Jest (MySQL) | 69 passed, 0 failed, 6 skipped (the MongoDB suite) |
| Jest MongoDB suite (against the test stand-in) | 6 passed, 0 failed |
| Postman collection via Newman | 51 requests, 69 assertions, 0 failures |
| Browser walkthrough | 29 of 29 checks passed; no JavaScript console errors |
| MySQL stopped while API running | `/api/health` and data endpoints returned 503; after restarting MySQL the API recovered without a restart |
| Request from an unlisted origin | No CORS header returned |
| Production start without `JWT_SECRET` | Server refused to start with a clear message |
| Client production build | Succeeded |

Selected test cases:

| ID | Test case | Expected | Observed |
|---|---|---|---|
| TC-01 | Register with valid data | 201, user returned without password hash | As expected |
| TC-02 | Register with an existing email | 409 | As expected |
| TC-03 | Login with wrong password | 401 "Invalid email or password." | As expected |
| TC-04 | Call `/api/projects` without token | 401 | As expected |
| TC-05 | Call with an expired token | 401 "session has expired" | As expected |
| TC-06 | Member edits project | 403 | As expected |
| TC-07 | Non-member opens project | 403 | As expected |
| TC-08 | Create project with deadline before start | 422 | As expected |
| TC-09 | Assign task to a non-member | 400 | As expected |
| TC-10 | Filter tasks by overdue | Only overdue tasks | As expected |
| TC-11 | Start timer twice | Second call 409 | As expected |
| TC-12 | Remove member | Their tasks in the project become unassigned | As expected |
| TC-13 | Dashboard totals | Total equals sum of the four statuses | As expected |
| TC-14 | Activity endpoints without MongoDB | 503, other features still work | As expected |

## 16.3 Tests to be completed by the student

| Test | Result |
|---|---|
| `npm test` on the Windows development PC | [To be filled after running] |
| MongoDB test suite against local MongoDB or Atlas | [To be filled after running] |
| Postman collection run on the Windows PC | [To be filled after running] |
| Deployed health check (`/api/health`) | [To be filled after deployment] |
| Register, login and create a task on the deployed site | [To be filled after deployment] |
| Responsive check on a physical phone | [To be filled after running] |

# 17. GitHub and Deployment Details

| Item | Value |
|---|---|
| GitHub repository URL | [To be filled after creating the repository] |
| Number of commits at submission | [To be filled] |
| Frontend URL (Render static site) | [To be filled after deployment] |
| Backend URL (Render web service) | [To be filled after deployment] |
| Health check URL | [Backend URL]/api/health |
| MySQL hosting provider | [To be filled, e.g. Aiven / TiDB Cloud] |
| MongoDB hosting | MongoDB Atlas [cluster region to be filled] |

**Deployment configuration prepared in the project**

- `render.yaml` blueprint defining the API web service (root `server`, build `npm ci --omit=dev`, start `npm start`, health check `/api/health`) and the static site (root `client`, build `npm ci && npm run build`, publish `dist`, rewrite `/*` to `/index.html`).
- Production environment variables: `NODE_ENV`, `JWT_SECRET` (generated by Render), `JWT_EXPIRES_IN`, `CORS_ORIGIN`, `MYSQL_URL`, `MYSQL_SSL`, `MYSQL_SSL_CA`, `MONGODB_URI`, `MONGODB_REQUIRED` for the API, and `VITE_API_URL` for the frontend.
- No URLs are hard-coded in application code; the frontend reads `VITE_API_URL` at build time and the API reads `CORS_ORIGIN` at start-up.

Step-by-step instructions and a troubleshooting table are in `docs/deployment-guide.md`.

# 18. Limitations

1. Changes made by one user appear for others only after they refresh or perform another action; there are no real-time updates.
2. There is no "forgot password" flow because the application does not send emails.
3. Activity logging is best effort: if MongoDB is unavailable, that action's log entry is lost even though the change itself is saved.
4. Only one timer can run on a task at a time, and time entries cannot be edited manually.
5. JWTs cannot be revoked before they expire (logging out removes the token from the browser only).
6. On Render's free plan, the API sleeps after inactivity and the first request can take up to a minute.
7. Users cannot upload attachments or profile photos.

# 19. Future Enhancements

1. Real-time collaboration with Socket.IO (live board updates and comment notifications).
2. Email notifications for assignments and approaching deadlines; password reset by email.
3. Refresh tokens with server-side revocation and httpOnly cookies on a shared domain.
4. File attachments on tasks using cloud storage.
5. Sub-tasks, labels, task dependencies and a Gantt / timeline view.
6. Reports exported to PDF or Excel, and time-sheet summaries per member.
7. AI features relevant to the AIML specialisation, such as estimating task duration from past time logs or flagging projects likely to miss their deadline.
8. Progressive Web App support for offline viewing.

# 20. Demonstration of the Six Technical Training Experiments

| Experiment | Topic | Demonstrated by |
|---|---|---|
| 1 | Responsive frontend (HTML, CSS, Bootstrap) | Semantic layout, Bootstrap 5 grid/forms/components, custom CSS with variables and media queries, collapsible sidebar, project and task cards, task table that becomes cards on phones, verified at 390 px width without horizontal scrolling |
| 2 | React frontend | 20+ reusable components, registration and login forms with validation, hooks (`useState`, `useEffect`, `useContext`, `useMemo`, `useCallback`, custom hooks), dashboard, listings, search, filters, favourites, toasts and dialogs |
| 3 | Node.js, Express and MongoDB | Express server, Mongoose connection handling, `ActivityLog` model with validation and indexes, activity REST endpoints with full CRUD for notes, validation and error handling, Postman folder for activity |
| 4 | Secure backend with MySQL | `mysql2` connection pool and prepared statements, registration/login, bcrypt hashing, JWT authentication middleware, protected project and task APIs, validation and error mapping, helmet, CORS, rate limiting |
| 5 | Full-stack integration with MySQL | Every screen loads and saves through Axios; database-driven listings; search, filtering, sorting and pagination on the server; CRUD; progress and overdue calculations; loading and error states; no hard-coded data |
| 6 | React + Vite, Axios, authentication, Git, deployment | Vite project and build, Axios integration with environment-based URL, register → login → dashboard flow, JWT handling, protected routes with React Router, Git repository files, Render blueprint and production configuration |

The detailed file-by-file mapping is in `docs/experiment-mapping.md`.

# 21. Conclusion

TaskFlow Pro turns a single-user LocalStorage prototype into a secure, multi-user web application with a React frontend, an Express REST API and two databases used for what each does best. The original tool's useful ideas (status tracking, the start/stop timer, confirmation dialogs and the purple identity) were kept and extended, while its weaknesses (no accounts, data trapped in one browser, unsafe HTML rendering, duplicate IDs) were removed.

Building the project end to end covered every stage of the six Technical Training-II experiments: responsive layout, component-based UI, REST API design, relational and document databases, authentication and authorisation, integration, automated testing and deployment preparation. The automated tests, Postman collection and browser checks give confidence that the main workflows behave as intended, and the remaining checks on real MongoDB and on the deployed site are listed so they can be completed and recorded.

# 22. References

1. React documentation, "Learn React" and "Hooks reference", https://react.dev
2. Vite documentation, "Env Variables and Modes" and "Server Options (proxy)", https://vitejs.dev
3. React Router documentation, https://reactrouter.com
4. Axios documentation, "Interceptors", https://axios-http.com
5. Bootstrap 5.3 documentation, "Grid system" and "Color modes", https://getbootstrap.com
6. Express 4 documentation, "Routing", "Using middleware" and "Error handling", https://expressjs.com
7. Oracle, MySQL 8.0 Reference Manual, https://dev.mysql.com/doc/refman/8.0/en/
8. mysql2 package documentation, https://sidorares.github.io/node-mysql2/docs
9. Mongoose documentation, "Schemas", "Validation" and "Indexes", https://mongoosejs.com/docs/
10. MongoDB Manual, https://www.mongodb.com/docs/manual/
11. M. Jones, J. Bradley and N. Sakimura, "JSON Web Token (JWT)", RFC 7519, IETF, 2015.
12. N. Provos and D. Mazières, "A Future-Adaptable Password Scheme", Proceedings of the USENIX Annual Technical Conference, 1999 (bcrypt).
13. OWASP Foundation, "Authentication Cheat Sheet", "Password Storage Cheat Sheet" and "SQL Injection Prevention Cheat Sheet", https://cheatsheetseries.owasp.org
14. express-validator documentation, https://express-validator.github.io
15. Helmet documentation, https://helmetjs.github.io
16. Jest documentation, https://jestjs.io; Supertest, https://github.com/ladjs/supertest
17. Postman Learning Center, "Writing tests" and "Running collections", https://learning.postman.com
18. Render documentation, "Blueprint specification", "Static sites" and "Environment variables", https://render.com/docs
19. MongoDB Atlas documentation, "Get Started with Atlas", https://www.mongodb.com/docs/atlas/
20. Git documentation, https://git-scm.com/doc
