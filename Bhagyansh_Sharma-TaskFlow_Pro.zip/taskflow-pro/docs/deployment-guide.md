# GitHub and Deployment Guide

Nothing in this guide has been done for you: no GitHub repository was created and nothing was deployed. Every step below is for you to perform with your own accounts. Write down the real URLs you get, because the report needs them.

Hosting plans and free tiers change often. Check each provider's current pricing page before you sign up.

---

## Part A: Git and GitHub

### A1. One-time Git setup (Windows)

1. Install Git from https://git-scm.com/download/win (keep the default options).
2. Open VS Code, then **Terminal > New Terminal** and run:

```bash
git config --global user.name "Bhagyansh Sharma"
git config --global user.email "your-email@example.com"
```

### A2. Make sure secrets are not committed

`.gitignore` already excludes `.env`, `node_modules/` and `client/dist/`. Before your first commit, check:

```bash
git status
```

You must **not** see `server/.env` or `client/.env` in the list. You should see `server/.env.example` and `client/.env.example`.

### A3. Create the local repository

From the `taskflow-pro` folder:

```bash
git init
git add .
git commit -m "TaskFlow Pro: full-stack project management system"
git branch -M main
```

### A4. Create the GitHub repository and push

1. Go to https://github.com/new
2. Repository name: `taskflow-pro`. Keep it **Public** if your teacher needs to see it, otherwise Private. Do **not** tick "Add a README" (you already have one).
3. Click **Create repository**, then run the commands GitHub shows, which look like:

```bash
git remote add origin https://github.com/<your-username>/taskflow-pro.git
git push -u origin main
```

If Git asks for a password, use a GitHub **Personal Access Token** (GitHub > Settings > Developer settings > Personal access tokens), not your account password. Or sign in through the browser window that Git Credential Manager opens.

### A5. Day-to-day commits (shows version control in your viva)

```bash
git add .
git commit -m "Describe what you changed"
git push
git log --oneline   # show your commit history
```

---

## Part B: Databases in the cloud

Render does not provide a managed MySQL database, so MySQL is hosted elsewhere. MongoDB goes on MongoDB Atlas.

### B1. MySQL-compatible database

Pick one provider that offers a MySQL 8 compatible database with TLS, for example **Aiven for MySQL** or **TiDB Cloud Serverless**. Steps are similar:

1. Create an account and a MySQL service/cluster in a region close to India (for example Mumbai/Singapore).
2. Copy the connection details: host, port, user, password, database name.
3. Build a connection URL:

```
mysql://USER:PASSWORD@HOST:PORT/DATABASE
```

- If the provider's URL ends with something like `?ssl-mode=REQUIRED`, remove that part. TLS is switched on with `MYSQL_SSL=true` instead.
- If your password contains special characters (`@`, `#`, `/`, `:`), URL-encode them (for example `@` becomes `%40`).
- Aiven shows a **CA certificate** (`ca.pem`). Put its content in `MYSQL_SSL_CA` with each line break written as `\n`. TiDB Cloud uses a public certificate, so `MYSQL_SSL_CA` can stay empty.

4. Create the tables and demo data **from your own computer**, pointing the scripts at the cloud database. In `server/.env` temporarily set:

```
MYSQL_URL=mysql://USER:PASSWORD@HOST:PORT/DATABASE
MYSQL_SSL=true
MYSQL_SSL_CA=          # only if needed
MONGODB_URI=           # your Atlas URI from B2 (so the activity seed goes to Atlas too)
```

then run:

```bash
cd server
npm run db:init     # creates the 7 tables (drops existing TaskFlow tables)
npm run db:seed     # optional: fictional demo data
```

Afterwards put your local values back in `server/.env`.

### B2. MongoDB Atlas

1. Sign up at https://www.mongodb.com/cloud/atlas and create a **free (M0) cluster**.
2. **Database Access** > Add user (username + password, role "Read and write to any database").
3. **Network Access** > Add IP Address > `0.0.0.0/0` (allow from anywhere). Render's free services do not have a fixed IP, so this is required; the password still protects the database.
4. **Connect > Drivers** > copy the URI and add the database name `taskflow_activity`:

```
mongodb+srv://USER:PASSWORD@cluster0.xxxxx.mongodb.net/taskflow_activity?retryWrites=true&w=majority
```

---

## Part C: Deploy on Render

### Option 1: Blueprint (uses `render.yaml`)

1. Push your code to GitHub (Part A).
2. Render dashboard > **New > Blueprint** > connect GitHub > choose the `taskflow-pro` repository.
3. Render reads `render.yaml` and proposes two services:
   - `taskflow-pro-api` (Node web service from `server/`)
   - `taskflow-pro-client` (static site from `client/`)
4. Fill in the values it asks for:

| Variable | Service | Value |
|---|---|---|
| `MYSQL_URL` | api | From B1 |
| `MYSQL_SSL_CA` | api | From B1 (or leave empty) |
| `MONGODB_URI` | api | From B2 |
| `CORS_ORIGIN` | api | The client URL, e.g. `https://taskflow-pro-client.onrender.com` (no trailing slash) |
| `VITE_API_URL` | client | The API URL + `/api`, e.g. `https://taskflow-pro-api.onrender.com/api` |

`JWT_SECRET` is generated automatically by Render.

You will only know the exact `.onrender.com` names after Render creates the services. If you guessed wrong, edit `CORS_ORIGIN` / `VITE_API_URL` in each service's **Environment** tab and redeploy. **The client must be rebuilt after changing `VITE_API_URL`** (Manual Deploy > Clear build cache & deploy), because Vite bakes it into the JavaScript at build time.

### Option 2: Create the two services by hand

**API (Web Service)**

| Setting | Value |
|---|---|
| Root directory | `server` |
| Runtime | Node |
| Build command | `npm ci --omit=dev` |
| Start command | `npm start` |
| Health check path | `/api/health` |
| Environment | `NODE_ENV=production`, `JWT_SECRET` (48+ random characters), `JWT_EXPIRES_IN=1d`, `CORS_ORIGIN`, `MYSQL_URL`, `MYSQL_SSL=true`, `MYSQL_SSL_CA` (optional), `MONGODB_URI`, `MONGODB_REQUIRED=false` |

Generate a secret locally with:

```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```

**Frontend (Static Site)**

| Setting | Value |
|---|---|
| Root directory | `client` |
| Build command | `npm ci && npm run build` |
| Publish directory | `dist` |
| Environment | `VITE_API_URL=https://<your-api>.onrender.com/api` |
| Redirects/Rewrites | Source `/*`, Destination `/index.html`, Action **Rewrite** (needed so refreshing `/projects/1` works) |

### C3. Verify the deployment

1. Open `https://<your-api>.onrender.com/api/health`. Expect `"mysql":"connected"` and `"mongodb":"connected"`.
2. Open the client URL, register, log in, create a project and a task.
3. Open the browser DevTools (F12) > Console: there should be no CORS errors.
4. Record the real URLs in the report (section "GitHub and Deployment Details").

Once Atlas works, you can set `MONGODB_REQUIRED=true` so the API refuses to start without MongoDB instead of silently disabling the activity log.

---

## Part D: Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| Browser console: "blocked by CORS policy" | `CORS_ORIGIN` does not exactly match the frontend URL | Copy the client URL from the address bar, no trailing slash, `https://`. Redeploy the API. |
| Frontend calls `.../undefined/...` or its own domain | `VITE_API_URL` not set at build time | Set it on the static site and do "Clear build cache & deploy". |
| Refreshing `/projects/3` shows "Not Found" | Missing SPA rewrite | Add the `/*` > `/index.html` rewrite rule. |
| API logs: `JWT_SECRET is required in production` | Variable missing | Add `JWT_SECRET` (32+ characters). |
| API logs: `[mysql] Cannot connect` / `ER_ACCESS_DENIED_ERROR` | Wrong URL/user/password, or special characters not encoded | Re-check `MYSQL_URL`; URL-encode the password. |
| `HANDSHAKE_SSL_ERROR`, `self-signed certificate in certificate chain` | Provider uses its own CA | Put the provider's CA certificate in `MYSQL_SSL_CA`. |
| `ER_BAD_DB_ERROR` / `Table 'xxx.users' doesn't exist` | Tables not created | Run `npm run db:init` against the cloud DB (B1 step 4). |
| `/api/health` shows `"mongodb":"disconnected"` | Atlas IP access list or URI | Add `0.0.0.0/0` in Network Access; check user/password and that the URI contains the database name. |
| First request takes 30 to 60 seconds | Render free service was sleeping | Normal on the free plan. Open `/api/health` a minute before your demo. |
| Login works locally but returns 401 in production | Token from a different secret | Log out and log in again after changing `JWT_SECRET`. |
| `npm ci` fails on Render | `package-lock.json` missing or out of date | Run `npm install` locally in that folder and commit the lock file. |
| `bcrypt` install error on Windows | Very old Node version | Use Node 20 LTS or newer; delete `node_modules` and run `npm install` again. |
