# Reference screenshots

Captured automatically during development testing (headless Chromium in a Linux sandbox, using the fictional seed data). Fonts fall back to system fonts because the sandbox could not load Google Fonts, and the activity log was served by a temporary MongoDB test stand-in.

Use these as a guide only. For the report, capture your own screenshots from your machine or the deployed site.
