# Experiment-to-Feature Mapping (Technical Training-II, 25CAP-707)

This table shows where each experiment is demonstrated in TaskFlow Pro, with the exact files and the screen or request to show during evaluation.

> The six experiment PDFs were not included in the files provided for this upgrade. The mapping follows the experiment descriptions in the project brief. Before submission, open each PDF and tick off its listed tasks against this table.

## Experiment 1: Responsive frontend development (HTML, CSS, Bootstrap)

| Requirement | Where it is demonstrated | Files |
|---|---|---|
| HTML5 structure | Semantic layout: `<aside>` sidebar, `<header>` topbar, `<main>`, `<section>` cards, `<nav>` pagination | `client/index.html`, `client/src/layouts/*.jsx` |
| CSS3 | Design tokens (CSS variables), gradients, grid, flexbox, animations, `prefers-reduced-motion` | `client/src/styles/app.css` |
| Bootstrap 5 | Grid (`row`, `col-*`), forms, buttons, alerts, list groups, modals, `nav-underline`, Bootstrap Icons, 5.3 colour modes (dark mode) | All pages |
| Responsive navigation | Fixed sidebar on desktop; slide-in sidebar with backdrop and hamburger button under 992 px | `components/Sidebar.jsx`, `components/Topbar.jsx`, `app.css` (media queries) |
| Project/task cards | Project cards with progress bars; Kanban task cards | `components/ProjectCard.jsx`, `components/TaskBoard.jsx` |
| Forms, buttons, interactive UI | Login, register, project and task modals, filters, status dropdowns | `pages/Login.jsx`, `components/ProjectFormModal.jsx`, `components/TaskFormModal.jsx` |
| Responsive across screen sizes | Task table turns into stacked cards on phones; board scrolls horizontally with snap; stat cards wrap 6 > 3 > 2 per row | `app.css` sections "Responsive" |
| Evidence | Browser check at 390 px width: no horizontal scrolling on Dashboard, Projects, Tasks, Project, Activity, Profile | `docs/testing-report.md` |

## Experiment 2: React frontend development

| Requirement | Where | Files |
|---|---|---|
| React components and reusable UI | 20+ components: `StatCard`, `ProgressBar`, `StatusBadge`, `PriorityBadge`, `Avatar`, `Modal`, `EmptyState`, `Pagination`, `TaskTable`, `TaskBoard`, `TaskDrawer`, `ActivityFeed`... | `client/src/components/` |
| Registration and login forms | `/register`, `/login` | `pages/Register.jsx`, `pages/Login.jsx` |
| Form validation | Client-side checks (required, email format, password rules shown live, matching confirm password, deadline after start date) plus server errors mapped onto fields | `Register.jsx`, `ProjectFormModal.jsx`, `TaskFormModal.jsx`, `api/client.js` (`fieldErrors`) |
| React Hooks | `useState`, `useEffect`, `useContext`, `useMemo`, `useCallback`, `useRef`; custom hooks `useAsync`, `useDebounce`, `useNow`, `useDocumentTitle` | `client/src/hooks/`, `context/` |
| Dashboard and listings | Dashboard, Projects grid, Tasks list/board | `pages/Dashboard.jsx`, `pages/Projects.jsx`, `pages/Tasks.jsx` |
| Search, filtering, favourites | Global search box; filter bars; favourites star + sidebar section + "Favourites" filter | `components/GlobalSearch.jsx`, `pages/Projects.jsx` |
| Success / warning / error messages | Toasts (react-hot-toast), SweetAlert2 confirm dialogs, inline alerts, empty and error states with retry | `utils/notify.js`, `components/EmptyState.jsx` |

## Experiment 3: Node.js, Express.js and MongoDB

| Requirement | Where | Files |
|---|---|---|
| Express backend | App, routers, middleware chain | `server/app.js`, `server/routes/` |
| MongoDB connection with Mongoose | Connection, events, graceful close, optional/required mode | `server/config/mongo.js` |
| Proper MongoDB model | `ActivityLog` schema: required fields, enum of action types, length limits, indexes, timestamps, JSON transform | `server/models/ActivityLog.js` |
| Working REST APIs | `GET/POST /api/activities`, `GET/PUT/DELETE /api/activities/:id` | `routes/activityRoutes.js`, `controllers/activityController.js` |
| CRUD on the activity module | Create note, read list/one, update own note, delete own note (admin: any). System entries are written automatically by every other controller | `services/activityService.js` |
| Validation and error handling | `express-validator` rules (Mongo id, text length), Mongoose validation, `CastError`/`ValidationError` mapped to 400/422, 503 when MongoDB is down | `validators/activityValidators.js`, `middleware/errorHandler.js` |
| API testing with Postman | Folder "6. Activity log (MongoDB)" in the collection | `docs/postman-collection.json` |

## Experiment 4: Secure backend with MySQL

| Requirement | Where | Files |
|---|---|---|
| Node.js + Express | As above | `server/` |
| MySQL with mysql2 | Promise connection pool, prepared statements (`execute` with `?` placeholders), transactions | `server/config/mysql.js` |
| Registration and login | `POST /api/auth/register`, `POST /api/auth/login` | `controllers/authController.js` |
| bcrypt hashing | `bcrypt.hash(password, rounds)`; only the hash is stored; login uses `bcrypt.compare` and a dummy hash so unknown emails take the same time | `authController.js`, `userController.js` |
| JWT authentication | `jsonwebtoken` sign (with issuer and expiry) and verify; the user is re-loaded from MySQL on every request | `middleware/auth.js` |
| Protected endpoints | `authenticate` middleware on every private router; per-project role checks | `routes/*.js`, `services/accessService.js` |
| Project and task APIs | Full CRUD plus members, favourites, comments, timer | `controllers/projectController.js`, `controllers/taskController.js` |
| Validation and error handling | `express-validator` on every input, central error handler, MySQL error codes mapped (duplicate, FK, check constraint, connection) | `validators/`, `middleware/errorHandler.js` |
| Other security | Helmet headers, CORS allow-list, rate limit on login/register, 100 kB body limit, no secrets in code | `app.js`, `middleware/rateLimit.js`, `.env.example` |

## Experiment 5: Full-stack integration with MySQL

| Requirement | Where | Files |
|---|---|---|
| Frontend-backend integration | Every screen reads and writes through the API; no hard-coded data | `client/src/api/services.js` |
| Database-driven listings | Projects, tasks, members, comments, dashboard numbers all come from MySQL queries | `projectController.js`, `taskController.js`, `dashboardController.js` |
| Axios requests | One Axios instance with base URL from `VITE_API_URL`, token interceptor, 401 handling | `client/src/api/client.js` |
| Search and filtering | Server-side `LIKE` search, status/priority/assignee/overdue filters, sorting, pagination | `listProjects`, `listTasks` |
| CRUD | Projects, tasks, comments, members, favourites, notes | as above |
| Status and progress calculations | Weighted progress % (independent of number of tasks), completion rate, overdue detection, days left | `server/utils/progress.js`, `dashboardController.js` |
| Async loading and error handling | `useAsync` hook (loading, error, retry), skeleton loaders, optimistic status changes rolled back on error | `hooks/useAsync.js`, `pages/Tasks.jsx` |
| No hard-coded database data | Demo data only comes from the seed script; dashboard counts verified by tests (`tasks.total === sum of statuses`) | `server/scripts/seed.js`, `tests/integration/api.test.js` |

## Experiment 6: React + Vite + Axios, authentication, Git and deployment

| Requirement | Where | Files |
|---|---|---|
| React app built with Vite | `npm run dev` / `npm run build` | `client/vite.config.js`, `client/package.json` |
| Express integration through Axios | Dev proxy `/api` > `localhost:5000`; production uses `VITE_API_URL` | `vite.config.js`, `api/client.js` |
| Register > login > dashboard workflow | After registering, the user is sent to `/login` with a success message and the email pre-filled; login redirects to `/dashboard` | `Register.jsx`, `Login.jsx` |
| JWT authentication | Token stored in `sessionStorage` (or `localStorage` with "Keep me signed in"), sent as `Authorization: Bearer`, validated with `/api/auth/me` on page load | `context/AuthContext.jsx`, `utils/storage.js` |
| Protected routes with React Router | `ProtectedRoute` and `PublicOnlyRoute` wrappers; expired token sends the user back to login | `routes/ProtectedRoute.jsx`, `App.jsx` |
| Project and task management | All of the above | |
| Git version control, GitHub | `.gitignore` (excludes `.env`, `node_modules`, `dist`), `.gitattributes`, commands in the deployment guide | `docs/deployment-guide.md` |
| Deployment preparation | `render.yaml` blueprint, health check, production env variables, CORS for the deployed URL, SPA rewrite | `render.yaml`, `client/public/_redirects` |

## Where to point during the demo

| Experiment | Show this screen | Show this code |
|---|---|---|
| 1 | Resize the browser to phone width; open the hamburger menu | `app.css` media queries |
| 2 | Register form validation; dashboard; star a project | `components/`, `hooks/useAsync.js` |
| 3 | Project > Activity tab: add, edit, delete a note; Postman folder 6 | `models/ActivityLog.js` |
| 4 | Postman: login, then call `/api/projects` without the token (401) | `middleware/auth.js`, bcrypt hash in MySQL Workbench |
| 5 | Change a task status on the board and watch progress % and dashboard change | `utils/progress.js`, `controllers/dashboardController.js` |
| 6 | Log out, open `/dashboard` directly (redirect to login); show `render.yaml` and the GitHub repo | `routes/ProtectedRoute.jsx` |
