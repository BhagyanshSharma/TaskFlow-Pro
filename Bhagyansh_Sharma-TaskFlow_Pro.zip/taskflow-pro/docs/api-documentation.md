# TaskFlow Pro REST API Documentation

Base URL

| Environment | Base URL |
|---|---|
| Local | `http://localhost:5000/api` |
| Production (example) | `https://taskflow-pro-api.onrender.com/api` |

All request and response bodies are JSON (`Content-Type: application/json`).

## Conventions

### Authentication

Protected endpoints need a JWT in the `Authorization` header:

```
Authorization: Bearer <token>
```

The token is returned by `POST /api/auth/login` (and `POST /api/auth/register`). It expires after `JWT_EXPIRES_IN` (default `1d`).

### Response envelope

Success:

```json
{ "success": true, "message": "Project created successfully.", "data": { } }
```

Lists that support paging also return:

```json
"pagination": { "page": 1, "limit": 12, "total": 4, "totalPages": 1 }
```

Error:

```json
{
  "success": false,
  "message": "Task title is required",
  "errors": [{ "field": "title", "message": "Task title is required" }]
}
```

`errors` is present only for validation failures.

### Status codes used

| Code | Meaning in this API |
|---|---|
| 200 | OK |
| 201 | Created |
| 400 | Bad request (business rule broken, invalid JSON, nothing to update) |
| 401 | Missing, invalid or expired token; wrong login credentials |
| 403 | Logged in but not allowed (not a member, not owner/manager, etc.) |
| 404 | Resource or route not found |
| 409 | Conflict (duplicate email, already a member, timer already running) |
| 422 | Validation failed (express-validator) |
| 429 | Too many login/register attempts |
| 503 | Database unavailable (MySQL down, or MongoDB not connected for activity endpoints) |
| 500 | Unexpected server error |

### Roles and permissions

Global role: `user` or `admin` (admins can see and manage everything).

Project role (table `project_members`):

| Action | owner | manager | member |
|---|---|---|---|
| View project, tasks, members, activity | yes | yes | yes |
| Edit project | yes | yes | no |
| Delete project | yes | no | no |
| Add / remove members | yes | yes | no |
| Change a member's role | yes | no | no |
| Create task | yes | yes | yes |
| Edit task | yes | yes | only if assignee or creator |
| Reassign task | yes | yes | only if creator |
| Delete task | yes | yes | only if creator |
| Delete any comment | yes | yes | own comments only |
| Leave project | no (owner) | yes | yes |

### Enumerations

- Task status: `To Do`, `In Progress`, `In Review`, `Completed`
- Priority (tasks and projects): `Low`, `Medium`, `High`, `Urgent`
- Project status: `Planning`, `Active`, `On Hold`, `Completed`, `Cancelled`
- Dates: `YYYY-MM-DD` strings. Send `""` or `null` to clear an optional date.

### Progress calculation

`progress` = weighted average of task statuses, as a percentage (0 to 100), so projects with different numbers of tasks can be compared:

| Status | Weight |
|---|---|
| To Do | 0 |
| In Progress | 0.5 |
| In Review | 0.75 |
| Completed | 1 |

`completion_rate` = completed tasks / total tasks x 100.

---

## System

### GET /api/health

Health check (used by Render). No auth.

Response `200` (or `503` if MySQL is unreachable):

```json
{
  "success": true,
  "message": "API is healthy",
  "data": {
    "status": "ok",
    "uptimeSeconds": 42,
    "databases": { "mysql": "connected", "mongodb": "connected" },
    "timestamp": "2026-10-10T08:00:00.000Z"
  }
}
```

### GET /api/meta

Enum values for dropdowns. No auth.

---

## Authentication

### POST /api/auth/register

Create an account. No auth. Rate limited.

Body:

```json
{ "name": "Test Student", "email": "student@example.com", "password": "Secret123" }
```

Rules: name 2 to 80 chars; valid email; password 8 to 72 chars with at least one letter and one number.

Response `201`:

```json
{
  "success": true,
  "message": "Registration successful. You can now log in.",
  "data": {
    "user": { "id": 101, "name": "Test Student", "email": "student@example.com", "role": "user", "job_title": null, "bio": null, "avatar_color": "#2563EB", "created_at": "2026-10-10 08:00:00" },
    "token": "eyJhbGciOi..."
  }
}
```

Errors: `422` validation, `409` email already registered.

### POST /api/auth/login

No auth. Rate limited.

Body: `{ "email": "riya@example.com", "password": "Demo@1234" }`

Response `200`: same shape as register (`data.user`, `data.token`).

Errors: `422` missing fields, `401` "Invalid email or password." (same message for unknown email and wrong password).

### GET /api/auth/me

Auth required. Returns `{ data: { user } }` for the token owner. `401` if the token is missing, invalid, expired, or the account was deleted.

---

## Users / Profile

### PUT /api/users/me

Auth. Update own profile. All fields optional.

```json
{ "name": "Riya Kapoor", "job_title": "Project Manager", "bio": "Short bio", "avatar_color": "#7C3AED" }
```

Response `200`: `{ data: { user } }`. Errors: `422`, `400` (nothing to update).

### PUT /api/users/me/password

Auth.

```json
{ "currentPassword": "Demo@1234", "newPassword": "NewPass123" }
```

Errors: `400` current password incorrect / same as old, `422` weak password.

### GET /api/users/search?q=ne

Auth. Find registered users by name or email (min 2 chars, max 10 results). Returns `id, name, email, avatar_color, job_title` only. Used by the "Add member" box.

---

## Dashboard

### GET /api/dashboard

Auth. All numbers are calculated from MySQL for the projects the user can access; `recent_activity` comes from MongoDB.

```json
{
  "data": {
    "projects": { "total": 4, "active": 2, "completed": 1, "not_started_or_paused": 1 },
    "tasks": { "total": 16, "todo": 6, "in_progress": 3, "in_review": 2, "completed": 5, "pending": 6, "overdue": 3, "assigned_to_me": 1, "completion_rate": 31, "overall_progress": 50 },
    "priority_breakdown": [{ "priority": "Low", "count": 2 }],
    "project_progress": [{ "id": 2, "name": "Library Management Revamp", "status": "Active", "priority": "Medium", "deadline": "2026-10-19", "total_tasks": 4, "completed_tasks": 1, "progress": 38 }],
    "upcoming_deadlines": [{ "id": 14, "title": "Choose mobile framework", "due_date": "2026-10-11", "days_left": 1, "project_name": "Mobile Attendance App" }],
    "overdue_tasks": [{ "id": 10, "title": "Overdue fine report", "days_overdue": 4 }],
    "my_tasks": [],
    "recent_activity": [],
    "activity_available": true
  }
}
```

`pending` = tasks in `To Do`. `overdue` = due date before today and not completed.

---

## Projects

### GET /api/projects

Auth. Projects the user is a member of (admins: all).

Query parameters (all optional):

| Param | Example | Notes |
|---|---|---|
| `q` | `library` | Searches name and description |
| `status` | `Active` | Project status |
| `priority` | `High` | |
| `favourites` | `true` | Only favourited projects |
| `sort` | `updated` | `updated`, `created`, `name`, `deadline`, `priority`, `progress` |
| `page`, `limit` | `1`, `12` | `limit` max 100 |

Each item:

```json
{
  "id": 1, "name": "Campus Event Portal", "description": "...", "status": "Active", "priority": "High",
  "start_date": "2026-09-19", "deadline": "2026-11-02",
  "owner": { "id": 2, "name": "Riya Kapoor" },
  "my_role": "owner", "is_favourite": true, "member_count": 4,
  "task_counts": { "total": 6, "todo": 3, "in_progress": 1, "in_review": 1, "completed": 1, "overdue": 2 },
  "progress": 38, "completion_rate": 17,
  "created_at": "...", "updated_at": "..."
}
```

### GET /api/projects/:id

Auth, member. Same shape plus `members` array. Errors: `403` not a member, `404`.

### POST /api/projects

Auth. The caller becomes `owner`.

```json
{
  "name": "Hostel Complaint System",
  "description": "Track hostel maintenance requests",
  "status": "Active",
  "priority": "High",
  "start_date": "2026-01-01",
  "deadline": "2026-03-01",
  "member_ids": [4]
}
```

Only `name` is required (3 to 120 chars). `deadline` must not be before `start_date`. Response `201` with the project (including `members`).

### PUT /api/projects/:id

Auth, owner/manager. Any subset of the create fields (except `member_ids`). Response `200`. Errors: `403`, `404`, `422`, `400` (deadline before stored start date).

### DELETE /api/projects/:id

Auth, owner. Deletes the project and (via `ON DELETE CASCADE`) its members, tasks, comments, favourites and time logs. Response `200`.

---

## Project members

### GET /api/projects/:id/members

Auth, member. Each member: `id, name, email, avatar_color, job_title, role, joined_at, open_tasks`.

### POST /api/projects/:id/members

Auth, owner/manager.

```json
{ "email": "neha@example.com", "role": "member" }
```

or `{ "user_id": 4, "role": "manager" }`. Returns `201` with the updated member list. Errors: `404` user not found, `409` already a member, `403`.

### PATCH /api/projects/:id/members/:userId

Auth, owner. Body `{ "role": "manager" }` or `{ "role": "member" }`. The owner's role cannot be changed.

### DELETE /api/projects/:id/members/:userId

Auth. Owners/managers can remove others; any member can remove themselves (leave). The owner cannot be removed. The removed user's tasks in that project become unassigned.

---

## Favourites

### GET /api/favourites

Auth. The caller's favourite projects (same shape as project list items).

### POST /api/favourites/:projectId

Auth, member. Adds to favourites (idempotent).

### DELETE /api/favourites/:projectId

Auth, member. Removes from favourites.

---

## Tasks

### GET /api/tasks

Auth. Tasks from every project the user can access.

| Param | Example | Notes |
|---|---|---|
| `project_id` | `1` | Only this project (must be a member) |
| `q` | `api` | Searches title and description |
| `status` | `In Progress` | |
| `priority` | `Urgent` | |
| `assignee` | `me`, `unassigned`, `4` | |
| `overdue` | `true` | Due date passed and not completed |
| `sort` | `due_date` | `due_date`, `priority`, `status`, `created`, `updated`, `title` |
| `order` | `asc` / `desc` | For `due_date`, open tasks are listed before completed ones |
| `page`, `limit` | `1`, `25` | `limit` max 200 |

Task item:

```json
{
  "id": 3,
  "project": { "id": 1, "name": "Campus Event Portal" },
  "title": "Event details page in React",
  "description": "Show agenda, venue map and register button.",
  "status": "In Progress",
  "priority": "Medium",
  "due_date": "2026-10-13",
  "is_overdue": false,
  "assignee": { "id": 3, "name": "Arjun Verma", "avatar_color": "#2563EB" },
  "created_by": { "id": 2, "name": "Riya Kapoor" },
  "comment_count": 1,
  "tracked_seconds": 8100,
  "timer_started_at": null,
  "completed_at": null,
  "created_at": "...", "updated_at": "..."
}
```

### GET /api/tasks/:id

Auth, member of the task's project. Adds `comments`, `time_logs` (latest 20) and `permissions` (`role`, `can_edit`, `can_delete`, `can_assign`).

### POST /api/tasks

Auth, member of the project.

```json
{
  "project_id": 1,
  "title": "Prepare demo script",
  "description": "Steps for the viva demo",
  "status": "To Do",
  "priority": "Urgent",
  "assignee_id": 4,
  "due_date": "2026-11-15"
}
```

Required: `project_id`, `title` (3 to 160 chars). The assignee must be a project member (`400` otherwise). Response `201`.

### PUT /api/tasks/:id

Auth. Owner/manager, the assignee or the creator. Any subset of `title, description, status, priority, assignee_id, due_date`. Changing `assignee_id` needs owner/manager or creator. Setting `status` to `Completed` stamps `completed_at` and stops a running timer.

### DELETE /api/tasks/:id

Auth. Owner/manager or the task creator.

### Task comments

| Method | Path | Who | Body |
|---|---|---|---|
| GET | `/api/tasks/:id/comments` | member | |
| POST | `/api/tasks/:id/comments` | member | `{ "body": "Looks good" }` (1 to 2000 chars) |
| DELETE | `/api/tasks/:id/comments/:commentId` | author or owner/manager | |

### Time tracking (from the original project)

| Method | Path | Notes |
|---|---|---|
| POST | `/api/tasks/:id/timer/start` | Starts a timer. `409` if already running, `400` if task completed. A `To Do` task moves to `In Progress`. |
| POST | `/api/tasks/:id/timer/stop` | Stops the running timer. `400` if not running. |

Both return the updated task (`tracked_seconds`, `timer_started_at`).

---

## Activity log (MongoDB)

These endpoints return `503` if MongoDB is not connected. Everything else in the API keeps working.

Activity document:

```json
{
  "id": "6727a1f0c2a4b5d6e7f80912",
  "actor": { "id": 2, "name": "Riya Kapoor" },
  "action": "task.status_changed",
  "entityType": "task",
  "projectId": 1,
  "taskId": 3,
  "description": "Riya Kapoor moved \"Event details page in React\" from To Do to In Progress",
  "metadata": { "from": "To Do", "to": "In Progress" },
  "editable": false,
  "createdAt": "2026-10-10T08:00:00.000Z",
  "updatedAt": "2026-10-10T08:00:00.000Z"
}
```

Actions written automatically: `user.registered`, `user.updated`, `project.created|updated|deleted|favourited|unfavourited`, `member.added|updated|removed`, `task.created|updated|status_changed|assigned|deleted|timer_started|timer_stopped`, `comment.added|deleted`. Manual notes use `note.created`.

### GET /api/activities

Auth. Entries for the user's projects (plus their own account events). Query: `project_id`, `task_id`, `entity_type` (`user|project|task|comment|member|note`), `page`, `limit` (max 100). Sorted newest first.

### GET /api/activities/:id

Auth. `422` for a malformed id, `404` if missing, `403` if it belongs to a project you are not in.

### POST /api/activities

Auth, member. Creates a manual note on a project timeline.

```json
{ "project_id": 1, "task_id": 3, "description": "Client call moved to 5 PM" }
```

`task_id` is optional. Response `201`.

### PUT /api/activities/:id

Auth. Edit your own note: `{ "description": "New text" }`. System entries cannot be edited (`403`).

### DELETE /api/activities/:id

Auth. Delete your own note; admins can delete any entry.
