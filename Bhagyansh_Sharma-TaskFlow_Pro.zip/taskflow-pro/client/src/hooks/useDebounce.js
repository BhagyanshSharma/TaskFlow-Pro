import { useEffect, useState } from 'react';

// Delays a fast-changing value (e.g. search input) to avoid an API call per keystroke
export default function useDebounce(value, delay = 350) {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const id = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(id);
  }, [value, delay]);
  return debounced;
}
