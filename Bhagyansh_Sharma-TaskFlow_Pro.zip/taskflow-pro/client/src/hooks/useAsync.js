import { useCallback, useEffect, useRef, useState } from 'react';
import { errorMessage } from '../api/client';

// Runs an async loader, tracking loading / error / data. `deps` re-trigger it.
export default function useAsync(loader, deps = []) {
  const [state, setState] = useState({ loading: true, error: null, data: null });
  const mounted = useRef(true);
  const latest = useRef(0);

  const run = useCallback(async ({ silent = false } = {}) => {
    const call = ++latest.current;
    if (!silent) setState((s) => ({ ...s, loading: true, error: null }));
    try {
      const data = await loader();
      if (mounted.current && call === latest.current) setState({ loading: false, error: null, data });
      return data;
    } catch (err) {
      if (mounted.current && call === latest.current) setState((s) => ({ ...s, loading: false, error: errorMessage(err), status: err?.response?.status }));
      return null;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);

  useEffect(() => {
    mounted.current = true;
    run();
    return () => {
      mounted.current = false;
    };
  }, [run]);

  return { ...state, reload: run, setData: (fn) => setState((s) => ({ ...s, data: typeof fn === 'function' ? fn(s.data) : fn })) };
}
