import { Link } from 'react-router-dom';
import ProgressBar from './ProgressBar';
import { PriorityBadge, StatusBadge } from './Badges';
import { dueLabel } from '../utils/format';
import { ROLE_LABEL } from '../utils/constants';

export default function ProjectCard({ project, onToggleFavourite, onEdit, onDelete }) {
  const due = dueLabel(project.deadline, project.status === 'Completed');
  const canManage = ['owner', 'manager', 'admin'].includes(project.my_role);
  const canDelete = ['owner', 'admin'].includes(project.my_role);
  const c = project.task_counts;

  return (
    <article className="tf-card project-card h-100">
      <div className="d-flex align-items-start justify-content-between gap-2">
        <div className="min-w-0">
          <div className="d-flex align-items-center gap-2 mb-1 flex-wrap">
            <StatusBadge status={project.status} />
            <PriorityBadge priority={project.priority} />
          </div>
          <h3 className="h6 mb-0 text-truncate">
            <Link to={`/projects/${project.id}`} className="stretched-link-inner text-reset text-decoration-none">{project.name}</Link>
          </h3>
        </div>
        <button
          type="button"
          className={`btn btn-icon fav-btn ${project.is_favourite ? 'active' : ''}`}
          onClick={() => onToggleFavourite(project)}
          aria-pressed={project.is_favourite}
          aria-label={project.is_favourite ? 'Remove from favourites' : 'Add to favourites'}
          title={project.is_favourite ? 'Remove from favourites' : 'Add to favourites'}
        >
          <i className={`bi ${project.is_favourite ? 'bi-star-fill' : 'bi-star'}`} />
        </button>
      </div>

      <p className="text-body-secondary small mt-2 mb-3 clamp-2">{project.description || 'No description yet.'}</p>

      <div className="d-flex justify-content-between small mb-1">
        <span className="text-body-secondary">Progress</span>
        <span className="fw-semibold tabular">{project.progress}%</span>
      </div>
      <ProgressBar value={project.progress} />

      <div className="project-meta mt-3">
        <span title="Tasks completed"><i className="bi bi-check2-square" /> {c.completed}/{c.total}</span>
        <span title="Members"><i className="bi bi-people" /> {project.member_count}</span>
        {c.overdue > 0 && <span className="text-danger" title="Overdue tasks"><i className="bi bi-alarm" /> {c.overdue}</span>}
        <span className={`ms-auto due due-${due.tone}`}><i className="bi bi-flag me-1" />{due.text}</span>
      </div>

      <div className="d-flex align-items-center justify-content-between mt-3 pt-3 border-top">
        <span className="small text-body-secondary">{ROLE_LABEL[project.my_role] || 'Viewer'} · {project.owner.name}</span>
        <div className="d-flex gap-1">
          <Link to={`/projects/${project.id}`} className="btn btn-sm btn-light" title="Open project"><i className="bi bi-box-arrow-up-right" /></Link>
          {canManage && <button type="button" className="btn btn-sm btn-light" onClick={() => onEdit(project)} title="Edit project" aria-label="Edit project"><i className="bi bi-pencil" /></button>}
          {canDelete && <button type="button" className="btn btn-sm btn-light text-danger" onClick={() => onDelete(project)} title="Delete project" aria-label="Delete project"><i className="bi bi-trash" /></button>}
        </div>
      </div>
    </article>
  );
}
