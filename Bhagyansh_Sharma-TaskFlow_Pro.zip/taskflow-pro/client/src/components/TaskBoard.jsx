import { useState } from 'react';
import Avatar from './Avatar';
import { DueBadge, PriorityBadge } from './Badges';
import { dueLabel } from '../utils/format';
import { STATUS_META, TASK_STATUSES } from '../utils/constants';

// Kanban board. Drag a card to another column (desktop) or use the move menu (any device).
export default function TaskBoard({ tasks, onOpen, onStatusChange, onAdd }) {
  const [dragOver, setDragOver] = useState(null);

  function drop(e, status) {
    e.preventDefault();
    setDragOver(null);
    const id = Number(e.dataTransfer.getData('text/task-id'));
    const task = tasks.find((t) => t.id === id);
    if (task && task.status !== status) onStatusChange(task, status);
  }

  return (
    <div className="board">
      {TASK_STATUSES.map((status) => {
        const column = tasks.filter((t) => t.status === status);
        return (
          <section
            key={status}
            className={`board-col ${dragOver === status ? 'drag-over' : ''}`}
            onDragOver={(e) => { e.preventDefault(); setDragOver(status); }}
            onDragLeave={() => setDragOver(null)}
            onDrop={(e) => drop(e, status)}
            aria-label={`${status} column`}
          >
            <header className="board-col-head">
              <span className={`dot ${STATUS_META[status].cls}`} />
              <h3 className="h6 mb-0">{status}</h3>
              <span className="count">{column.length}</span>
              {onAdd && (
                <button type="button" className="btn btn-icon btn-sm ms-auto" onClick={() => onAdd(status)} title={`Add task to ${status}`} aria-label={`Add task to ${status}`}>
                  <i className="bi bi-plus-lg" />
                </button>
              )}
            </header>
            <div className="board-col-body">
              {column.length === 0 && <div className="board-empty">Drop tasks here</div>}
              {column.map((t) => (
                <article
                  key={t.id}
                  className={`board-card ${t.is_overdue ? 'overdue' : ''}`}
                  draggable
                  onDragStart={(e) => e.dataTransfer.setData('text/task-id', String(t.id))}
                  onClick={() => onOpen(t)}
                  onKeyDown={(e) => e.key === 'Enter' && onOpen(t)}
                  tabIndex={0}
                >
                  <div className="d-flex justify-content-between align-items-start gap-2">
                    <span className="board-card-title">{t.title}</span>
                    <div className="dropdown-lite" onClick={(e) => e.stopPropagation()}>
                      <select
                        className="form-select form-select-sm move-select"
                        value={t.status}
                        onChange={(e) => onStatusChange(t, e.target.value)}
                        aria-label={`Move ${t.title}`}
                        title="Move to…"
                      >
                        {TASK_STATUSES.map((s) => <option key={s}>{s}</option>)}
                      </select>
                    </div>
                  </div>
                  <div className="d-flex align-items-center gap-2 flex-wrap mt-2">
                    <PriorityBadge priority={t.priority} />
                    <DueBadge label={dueLabel(t.due_date, t.status === 'Completed')} />
                  </div>
                  <div className="d-flex align-items-center justify-content-between mt-2 small text-body-secondary">
                    <span className="d-flex gap-2">
                      {t.comment_count > 0 && <span><i className="bi bi-chat-left-text me-1" />{t.comment_count}</span>}
                      {t.timer_started_at && <span className="text-success"><i className="bi bi-record-circle" /></span>}
                    </span>
                    {t.assignee ? <Avatar name={t.assignee.name} color={t.assignee.avatar_color} size={24} /> : <span className="small">Unassigned</span>}
                  </div>
                </article>
              ))}
            </div>
          </section>
        );
      })}
    </div>
  );
}
