export default function Loader({ text = 'Loading…', className = '' }) {
  return (
    <div className={`d-flex align-items-center justify-content-center gap-2 py-5 text-body-secondary ${className}`} role="status">
      <span className="spinner-border spinner-border-sm text-primary" aria-hidden="true" />
      <span>{text}</span>
    </div>
  );
}

export function SkeletonCards({ count = 3 }) {
  return (
    <div className="row g-3">
      {Array.from({ length: count }).map((_, i) => (
        <div className="col-12 col-md-6 col-xl-4" key={i}>
          <div className="tf-card p-4">
            <div className="skeleton mb-3" style={{ width: '60%', height: 18 }} />
            <div className="skeleton mb-2" style={{ width: '90%', height: 12 }} />
            <div className="skeleton mb-4" style={{ width: '75%', height: 12 }} />
            <div className="skeleton" style={{ width: '100%', height: 8 }} />
          </div>
        </div>
      ))}
    </div>
  );
}
