import Avatar from './Avatar';
import { DueBadge, PriorityBadge } from './Badges';
import { dueLabel } from '../utils/format';
import { TASK_STATUSES, STATUS_META } from '../utils/constants';

// Responsive list: table on desktop, stacked cards on phones (CSS handles the switch)
export default function TaskTable({ tasks, onOpen, onStatusChange, showProject = true }) {
  return (
    <div className="tf-card p-0 overflow-hidden">
      <div className="table-responsive">
        <table className="table tf-table align-middle mb-0">
          <thead>
            <tr>
              <th scope="col">Task</th>
              {showProject && <th scope="col">Project</th>}
              <th scope="col">Assignee</th>
              <th scope="col">Priority</th>
              <th scope="col">Due</th>
              <th scope="col" style={{ width: 170 }}>Status</th>
            </tr>
          </thead>
          <tbody>
            {tasks.map((t) => (
              <tr key={t.id} className={t.is_overdue ? 'row-overdue' : ''}>
                <td data-label="Task">
                  <button type="button" className="btn btn-link p-0 text-start task-title-link" onClick={() => onOpen(t)}>
                    {t.title}
                  </button>
                  <div className="small text-body-secondary d-flex gap-3 mt-1">
                    {t.comment_count > 0 && <span><i className="bi bi-chat-left-text me-1" />{t.comment_count}</span>}
                    {t.timer_started_at && <span className="text-success"><i className="bi bi-record-circle me-1" />Timer running</span>}
                  </div>
                </td>
                {showProject && <td data-label="Project" className="small">{t.project.name}</td>}
                <td data-label="Assignee">
                  {t.assignee ? (
                    <span className="d-inline-flex align-items-center gap-2 small"><Avatar name={t.assignee.name} color={t.assignee.avatar_color} size={26} />{t.assignee.name}</span>
                  ) : (
                    <span className="small text-body-secondary">Unassigned</span>
                  )}
                </td>
                <td data-label="Priority"><PriorityBadge priority={t.priority} /></td>
                <td data-label="Due"><DueBadge label={dueLabel(t.due_date, t.status === 'Completed')} /></td>
                <td data-label="Status">
                  <select
                    className={`form-select form-select-sm status-select ${STATUS_META[t.status]?.cls}`}
                    value={t.status}
                    onChange={(e) => onStatusChange(t, e.target.value)}
                    aria-label={`Change status of ${t.title}`}
                  >
                    {TASK_STATUSES.map((s) => <option key={s}>{s}</option>)}
                  </select>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
