import { useEffect, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { confirmAction, notify } from '../utils/notify';
import Avatar from './Avatar';
import GlobalSearch from './GlobalSearch';

export default function Topbar({ onMenu, onNewTask, onOpenTask }) {
  const { user, logout } = useAuth();
  const { theme, toggle } = useTheme();
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef(null);
  const navigate = useNavigate();

  useEffect(() => {
    const close = (e) => !menuRef.current?.contains(e.target) && setMenuOpen(false);
    document.addEventListener('mousedown', close);
    return () => document.removeEventListener('mousedown', close);
  }, []);

  async function handleLogout() {
    setMenuOpen(false);
    if (!(await confirmAction({ title: 'Log out?', text: 'You will need to sign in again.', confirmText: 'Log out', danger: false }))) return;
    logout();
    notify.success('Logged out successfully');
    navigate('/login');
  }

  return (
    <header className="topbar">
      <button type="button" className="btn btn-icon d-lg-none" onClick={onMenu} aria-label="Open menu">
        <i className="bi bi-list fs-4" />
      </button>

      <GlobalSearch onOpenTask={onOpenTask} />

      <div className="d-flex align-items-center gap-2 ms-auto">
        <button type="button" className="btn btn-primary btn-sm d-none d-sm-inline-flex align-items-center" onClick={onNewTask}>
          <i className="bi bi-plus-lg me-1" />New task
        </button>
        <button type="button" className="btn btn-primary btn-icon btn-sm d-sm-none" onClick={onNewTask} aria-label="New task">
          <i className="bi bi-plus-lg" />
        </button>
        <button type="button" className="btn btn-icon" onClick={toggle} aria-label={`Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`} title="Toggle theme">
          <i className={`bi ${theme === 'dark' ? 'bi-sun' : 'bi-moon-stars'}`} />
        </button>

        <div className="position-relative" ref={menuRef}>
          <button type="button" className="btn btn-icon p-0 user-btn" onClick={() => setMenuOpen((o) => !o)} aria-expanded={menuOpen} aria-label="Account menu">
            <Avatar name={user.name} color={user.avatar_color} size={34} />
          </button>
          {menuOpen && (
            <div className="user-menu shadow">
              <div className="px-3 py-2 border-bottom">
                <div className="fw-semibold small">{user.name}</div>
                <div className="small text-body-secondary text-truncate">{user.email}</div>
              </div>
              <Link to="/profile" className="dropdown-item" onClick={() => setMenuOpen(false)}><i className="bi bi-person me-2" />Profile</Link>
              <Link to="/settings" className="dropdown-item" onClick={() => setMenuOpen(false)}><i className="bi bi-gear me-2" />Settings</Link>
              <button type="button" className="dropdown-item text-danger" onClick={handleLogout}><i className="bi bi-box-arrow-right me-2" />Log out</button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
