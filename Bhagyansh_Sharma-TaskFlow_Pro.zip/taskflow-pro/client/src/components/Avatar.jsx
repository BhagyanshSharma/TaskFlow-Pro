import { initials } from '../utils/format';

export default function Avatar({ name, color = '#5B0888', size = 32, title }) {
  return (
    <span
      className="tf-avatar"
      style={{ width: size, height: size, fontSize: Math.max(10, size * 0.38), background: color }}
      title={title || name}
      aria-label={name}
    >
      {initials(name)}
    </span>
  );
}

export function AvatarStack({ people = [], max = 4, size = 28 }) {
  const shown = people.slice(0, max);
  const extra = people.length - shown.length;
  return (
    <span className="avatar-stack">
      {shown.map((p) => (
        <Avatar key={p.id} name={p.name} color={p.avatar_color} size={size} />
      ))}
      {extra > 0 && <span className="tf-avatar avatar-more" style={{ width: size, height: size, fontSize: size * 0.36 }}>+{extra}</span>}
    </span>
  );
}
