export default function ProgressBar({ value = 0, height = 8, showLabel = false }) {
  const v = Math.max(0, Math.min(100, Math.round(value)));
  const tone = v >= 100 ? 'done' : v >= 60 ? 'good' : v >= 25 ? 'mid' : 'low';
  return (
    <div className="d-flex align-items-center gap-2">
      <div className="tf-progress flex-grow-1" style={{ height }} role="progressbar" aria-valuenow={v} aria-valuemin="0" aria-valuemax="100" aria-label="Progress">
        <div className={`tf-progress-bar tone-${tone}`} style={{ width: `${v}%` }} />
      </div>
      {showLabel && <span className="small fw-semibold tabular" style={{ minWidth: 38 }}>{v}%</span>}
    </div>
  );
}
