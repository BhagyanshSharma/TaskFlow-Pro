import { PRIORITY_META, STATUS_META } from '../utils/constants';

export function StatusBadge({ status }) {
  const meta = STATUS_META[status] || { cls: 'status-todo', icon: 'bi-circle' };
  return (
    <span className={`tf-badge ${meta.cls}`}>
      <i className={`bi ${meta.icon}`} aria-hidden="true" />
      {status}
    </span>
  );
}

export function PriorityBadge({ priority }) {
  const meta = PRIORITY_META[priority] || PRIORITY_META.Medium;
  return (
    <span className={`tf-badge ${meta.cls}`}>
      <i className={`bi ${meta.icon}`} aria-hidden="true" />
      {priority}
    </span>
  );
}

export function DueBadge({ label }) {
  return <span className={`due due-${label.tone}`}><i className="bi bi-calendar-event me-1" />{label.text}</span>;
}
