import { useEffect, useState } from 'react';
import Modal from './Modal';
import { projectApi, taskApi } from '../api/services';
import { fieldErrors } from '../api/client';
import { notify } from '../utils/notify';
import { PRIORITIES, TASK_STATUSES } from '../utils/constants';

const EMPTY = { project_id: '', title: '', description: '', status: 'To Do', priority: 'Medium', assignee_id: '', due_date: '' };

function validate(form) {
  const errors = {};
  if (!form.project_id) errors.project_id = 'Choose a project';
  if (!form.title.trim()) errors.title = 'Task title is required';
  else if (form.title.trim().length < 3) errors.title = 'Task title must be at least 3 characters';
  if (form.due_date && !/^\d{4}-\d{2}-\d{2}$/.test(form.due_date)) errors.due_date = 'Enter a valid date';
  return errors;
}

// Create or edit a task. `projectId` locks the project (used inside a project page).
export default function TaskFormModal({ show, task, projectId, onClose, onSaved, defaultStatus, canAssign = true }) {
  const editing = Boolean(task);
  const [form, setForm] = useState(EMPTY);
  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);
  const [projects, setProjects] = useState([]);
  const [members, setMembers] = useState([]);

  useEffect(() => {
    if (!show) return;
    setErrors({});
    setForm(
      task
        ? {
            project_id: String(task.project.id),
            title: task.title,
            description: task.description || '',
            status: task.status,
            priority: task.priority,
            assignee_id: task.assignee ? String(task.assignee.id) : '',
            due_date: task.due_date || '',
          }
        : { ...EMPTY, project_id: projectId ? String(projectId) : '', status: defaultStatus || 'To Do' }
    );
    if (!projectId && !task) {
      projectApi
        .list({ limit: 100, sort: 'name' })
        .then(({ items }) => setProjects(items.filter((p) => !['Completed', 'Cancelled'].includes(p.status))))
        .catch((err) => notify.apiError(err, 'Could not load projects'));
    }
  }, [show, task, projectId, defaultStatus]);

  // Assignee dropdown = members of the selected project
  useEffect(() => {
    if (!show || !form.project_id) {
      setMembers([]);
      return;
    }
    projectApi.members(form.project_id).then(setMembers).catch(() => setMembers([]));
  }, [show, form.project_id]);

  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value, ...(key === 'project_id' ? { assignee_id: '' } : {}) }));

  async function submit(e) {
    e.preventDefault();
    const v = validate(form);
    setErrors(v);
    if (Object.keys(v).length) return;
    setSaving(true);
    try {
      const payload = {
        title: form.title.trim(),
        description: form.description.trim(),
        status: form.status,
        priority: form.priority,
        due_date: form.due_date || null,
        assignee_id: form.assignee_id ? Number(form.assignee_id) : null,
      };
      const res = editing
        ? await taskApi.update(task.id, payload)
        : await taskApi.create({ ...payload, project_id: Number(form.project_id) });
      notify.success(res.message);
      onSaved(res.data);
      onClose();
    } catch (err) {
      setErrors(fieldErrors(err));
      notify.apiError(err);
    } finally {
      setSaving(false);
    }
  }

  const lockedProject = Boolean(projectId || task);

  return (
    <Modal
      show={show}
      onClose={onClose}
      busy={saving}
      title={editing ? 'Edit task' : 'New task'}
      footer={
        <>
          <button type="button" className="btn btn-outline-secondary" onClick={onClose} disabled={saving}>Cancel</button>
          <button type="submit" form="task-form" className="btn btn-primary" disabled={saving}>
            {saving && <span className="spinner-border spinner-border-sm me-2" />}
            {editing ? 'Save task' : 'Create task'}
          </button>
        </>
      }
    >
      <form id="task-form" onSubmit={submit} noValidate>
        {!lockedProject && (
          <div className="mb-3">
            <label className="form-label" htmlFor="t-project">Project <span className="text-danger">*</span></label>
            <select id="t-project" className={`form-select ${errors.project_id ? 'is-invalid' : ''}`} value={form.project_id} onChange={set('project_id')}>
              <option value="">Select a project</option>
              {projects.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
            <div className="invalid-feedback">{errors.project_id}</div>
            {projects.length === 0 && <div className="form-text">No open projects yet. Create a project first.</div>}
          </div>
        )}
        <div className="mb-3">
          <label className="form-label" htmlFor="t-title">Task <span className="text-danger">*</span></label>
          <input id="t-title" className={`form-control ${errors.title ? 'is-invalid' : ''}`} value={form.title} onChange={set('title')} maxLength={160} placeholder="What are you going to do?" />
          <div className="invalid-feedback">{errors.title}</div>
        </div>
        <div className="mb-3">
          <label className="form-label" htmlFor="t-desc">Description</label>
          <textarea id="t-desc" className="form-control" rows={3} value={form.description} onChange={set('description')} placeholder="Add details, acceptance criteria or links" />
        </div>
        <div className="row g-3">
          <div className="col-sm-6">
            <label className="form-label" htmlFor="t-status">Status</label>
            <select id="t-status" className="form-select" value={form.status} onChange={set('status')}>
              {TASK_STATUSES.map((s) => <option key={s}>{s}</option>)}
            </select>
          </div>
          <div className="col-sm-6">
            <label className="form-label" htmlFor="t-priority">Priority</label>
            <select id="t-priority" className="form-select" value={form.priority} onChange={set('priority')}>
              {PRIORITIES.map((p) => <option key={p}>{p}</option>)}
            </select>
          </div>
          <div className="col-sm-6">
            <label className="form-label" htmlFor="t-assignee">Assignee</label>
            <select id="t-assignee" className={`form-select ${errors.assignee_id ? 'is-invalid' : ''}`} value={form.assignee_id} onChange={set('assignee_id')} disabled={!form.project_id || !canAssign}>
              <option value="">Unassigned</option>
              {members.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}
            </select>
            <div className="invalid-feedback">{errors.assignee_id}</div>
            {!canAssign && <div className="form-text">Only the task creator or a project manager can reassign.</div>}
          </div>
          <div className="col-sm-6">
            <label className="form-label" htmlFor="t-due">Due date</label>
            <input id="t-due" type="date" className={`form-control ${errors.due_date ? 'is-invalid' : ''}`} value={form.due_date} onChange={set('due_date')} />
            <div className="invalid-feedback">{errors.due_date}</div>
          </div>
        </div>
      </form>
    </Modal>
  );
}
