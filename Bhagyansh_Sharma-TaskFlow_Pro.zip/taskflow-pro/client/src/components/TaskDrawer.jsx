import { useCallback, useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { Link } from 'react-router-dom';
import { activityApi, taskApi } from '../api/services';
import { errorMessage } from '../api/client';
import { useAuth } from '../context/AuthContext';
import { confirmAction, notify } from '../utils/notify';
import { TASK_STATUSES } from '../utils/constants';
import { dueLabel, formatDate, formatDateTime, formatDuration, timeAgo } from '../utils/format';
import Avatar from './Avatar';
import { DueBadge, PriorityBadge, StatusBadge } from './Badges';
import Loader from './Loader';
import TaskTimer from './TaskTimer';
import TaskFormModal from './TaskFormModal';
import ActivityFeed from './ActivityFeed';
import { ErrorState } from './EmptyState';

// Slide-over panel with everything about one task: details, status, timer, comments, history
export default function TaskDrawer({ taskId, onClose, onChanged, onDeleted }) {
  const { user } = useAuth();
  const [task, setTask] = useState(null);
  const [error, setError] = useState(null);
  const [comment, setComment] = useState('');
  const [posting, setPosting] = useState(false);
  const [history, setHistory] = useState({ items: [], unavailable: false });
  const [tab, setTab] = useState('comments');
  const [editOpen, setEditOpen] = useState(false);

  const load = useCallback(async () => {
    setError(null);
    try {
      const t = await taskApi.get(taskId);
      setTask(t);
    } catch (err) {
      setError(errorMessage(err));
    }
  }, [taskId]);

  const loadHistory = useCallback(async () => {
    try {
      const { items } = await activityApi.list({ task_id: taskId, limit: 30 });
      setHistory({ items, unavailable: false });
    } catch (err) {
      setHistory({ items: [], unavailable: err?.response?.status === 503 });
    }
  }, [taskId]);

  useEffect(() => {
    setTask(null);
    setTab('comments');
    load();
    loadHistory();
  }, [load, loadHistory]);

  useEffect(() => {
    const onKey = (e) => e.key === 'Escape' && !editOpen && onClose();
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [onClose, editOpen]);

  function applyUpdate(updated) {
    setTask((t) => ({ ...t, ...updated }));
    onChanged?.(updated);
    loadHistory();
  }

  async function changeStatus(status) {
    try {
      const res = await taskApi.update(task.id, { status });
      notify.success(`Moved to ${status}`);
      applyUpdate(res.data);
      if (status === 'Completed' || task.timer_started_at) load();
    } catch (err) {
      notify.apiError(err);
    }
  }

  async function addComment(e) {
    e.preventDefault();
    if (!comment.trim()) {
      notify.error('Comment cannot be empty');
      return;
    }
    setPosting(true);
    try {
      const res = await taskApi.addComment(task.id, comment.trim());
      setTask((t) => ({ ...t, comments: [...t.comments, res.data], comment_count: t.comment_count + 1 }));
      onChanged?.({ id: task.id, comment_count: task.comment_count + 1 });
      setComment('');
      loadHistory();
    } catch (err) {
      notify.apiError(err);
    } finally {
      setPosting(false);
    }
  }

  async function deleteComment(c) {
    if (!(await confirmAction({ title: 'Delete comment?', text: 'This cannot be undone.', confirmText: 'Delete' }))) return;
    try {
      await taskApi.deleteComment(task.id, c.id);
      setTask((t) => ({ ...t, comments: t.comments.filter((x) => x.id !== c.id), comment_count: t.comment_count - 1 }));
      onChanged?.({ id: task.id, comment_count: task.comment_count - 1 });
      notify.success('Comment deleted');
    } catch (err) {
      notify.apiError(err);
    }
  }

  async function deleteTask() {
    if (!(await confirmAction({ title: 'Delete this task?', text: 'Its comments and tracked time will be deleted too.', confirmText: 'Delete task' }))) return;
    try {
      await taskApi.remove(task.id);
      notify.success('Task deleted');
      onDeleted?.(task.id);
      onClose();
    } catch (err) {
      notify.apiError(err);
    }
  }

  const perms = task?.permissions || {};
  const isManager = ['owner', 'manager', 'admin'].includes(perms.role);

  return createPortal(
    <>
      <div className="drawer-backdrop" onClick={onClose} />
      <aside className="drawer" role="dialog" aria-modal="true" aria-label="Task details">
        <header className="drawer-head">
          <span className="small text-body-secondary">
            {task ? <Link to={`/projects/${task.project.id}`} onClick={onClose}>{task.project.name}</Link> : 'Task'}
          </span>
          <div className="d-flex gap-1">
            {perms.can_edit && <button type="button" className="btn btn-sm btn-light" onClick={() => setEditOpen(true)}><i className="bi bi-pencil me-1" />Edit</button>}
            {perms.can_delete && <button type="button" className="btn btn-sm btn-light text-danger" onClick={deleteTask} aria-label="Delete task"><i className="bi bi-trash" /></button>}
            <button type="button" className="btn-close ms-2" onClick={onClose} aria-label="Close" />
          </div>
        </header>

        <div className="drawer-body">
          {error && <ErrorState message={error} onRetry={load} />}
          {!task && !error && <Loader text="Loading task…" />}
          {task && (
            <>
              <h2 className="h4 mb-2">{task.title}</h2>
              <div className="d-flex flex-wrap gap-2 mb-3">
                <StatusBadge status={task.status} />
                <PriorityBadge priority={task.priority} />
                <DueBadge label={dueLabel(task.due_date, task.status === 'Completed')} />
              </div>

              <dl className="detail-grid">
                <dt>Status</dt>
                <dd>
                  <select className="form-select form-select-sm" style={{ maxWidth: 200 }} value={task.status} disabled={!perms.can_edit} onChange={(e) => changeStatus(e.target.value)} aria-label="Task status">
                    {TASK_STATUSES.map((s) => <option key={s}>{s}</option>)}
                  </select>
                </dd>
                <dt>Assignee</dt>
                <dd>{task.assignee ? <span className="d-inline-flex align-items-center gap-2"><Avatar name={task.assignee.name} color={task.assignee.avatar_color} size={24} />{task.assignee.name}</span> : <span className="text-body-secondary">Unassigned</span>}</dd>
                <dt>Due date</dt>
                <dd>{formatDate(task.due_date)}</dd>
                <dt>Time tracked</dt>
                <dd><TaskTimer task={task} canEdit={perms.can_edit} onChange={(t) => { applyUpdate(t); load(); }} /></dd>
                <dt>Created by</dt>
                <dd>{task.created_by.name} · <span className="text-body-secondary">{timeAgo(task.created_at)}</span></dd>
                {task.completed_at && (<><dt>Completed</dt><dd>{formatDateTime(task.completed_at)}</dd></>)}
              </dl>

              <h3 className="h6 mt-4">Description</h3>
              <p className="text-body-secondary pre-wrap">{task.description || 'No description.'}</p>

              <ul className="nav nav-underline mt-4 mb-3" role="tablist">
                <li className="nav-item"><button type="button" className={`nav-link ${tab === 'comments' ? 'active' : ''}`} onClick={() => setTab('comments')}>Comments ({task.comments.length})</button></li>
                <li className="nav-item"><button type="button" className={`nav-link ${tab === 'history' ? 'active' : ''}`} onClick={() => setTab('history')}>History</button></li>
                <li className="nav-item"><button type="button" className={`nav-link ${tab === 'time' ? 'active' : ''}`} onClick={() => setTab('time')}>Time logs</button></li>
              </ul>

              {tab === 'comments' && (
                <section>
                  {task.comments.length === 0 && <p className="small text-body-secondary">No comments yet. Start the discussion.</p>}
                  <ul className="list-unstyled comment-list">
                    {task.comments.map((c) => (
                      <li key={c.id} className={`comment ${c.user_id === user.id ? 'mine' : ''}`}>
                        <Avatar name={c.user_name} color={c.avatar_color} size={30} />
                        <div className="comment-bubble">
                          <div className="d-flex justify-content-between gap-2 small">
                            <strong>{c.user_name}</strong>
                            <span className="text-body-secondary">{timeAgo(c.created_at)}</span>
                          </div>
                          <p className="mb-0 pre-wrap">{c.body}</p>
                          {(c.user_id === user.id || isManager) && (
                            <button type="button" className="btn btn-link btn-sm p-0 text-danger" onClick={() => deleteComment(c)}>Delete</button>
                          )}
                        </div>
                      </li>
                    ))}
                  </ul>
                  <form onSubmit={addComment} className="comment-form">
                    <label htmlFor="new-comment" className="visually-hidden">Write a comment</label>
                    <textarea id="new-comment" className="form-control" rows={2} maxLength={2000} placeholder="Type your message…" value={comment} onChange={(e) => setComment(e.target.value)}
                      onKeyDown={(e) => { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) addComment(e); }} />
                    <div className="d-flex justify-content-between align-items-center mt-2">
                      <span className="small text-body-secondary">Ctrl + Enter to send</span>
                      <button className="btn btn-primary btn-sm" type="submit" disabled={posting}>
                        {posting ? <span className="spinner-border spinner-border-sm" /> : <><i className="bi bi-send me-1" />Send</>}
                      </button>
                    </div>
                  </form>
                </section>
              )}

              {tab === 'history' && (
                history.unavailable ? (
                  <div className="alert alert-warning small mb-0"><i className="bi bi-database-exclamation me-2" />Activity history needs MongoDB, which is not connected right now.</div>
                ) : history.items.length === 0 ? (
                  <p className="small text-body-secondary">No history recorded yet.</p>
                ) : (
                  <ActivityFeed items={history.items} currentUser={user} compact />
                )
              )}

              {tab === 'time' && (
                task.time_logs.length === 0 ? (
                  <p className="small text-body-secondary">No time tracked yet. Use Start to begin tracking.</p>
                ) : (
                  <table className="table table-sm small">
                    <thead><tr><th>Who</th><th>Started</th><th>Ended</th><th className="text-end">Duration</th></tr></thead>
                    <tbody>
                      {task.time_logs.map((l) => (
                        <tr key={l.id}>
                          <td>{l.user_name}</td>
                          <td>{formatDateTime(l.started_at)}</td>
                          <td>{l.ended_at ? formatDateTime(l.ended_at) : <span className="text-success">Running</span>}</td>
                          <td className="text-end tabular">{formatDuration(l.seconds)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )
              )}
            </>
          )}
        </div>
      </aside>
      {task && (
        <TaskFormModal show={editOpen} task={task} canAssign={perms.can_assign} onClose={() => setEditOpen(false)} onSaved={(t) => { applyUpdate(t); load(); }} />
      )}
    </>,
    document.body
  );
}
