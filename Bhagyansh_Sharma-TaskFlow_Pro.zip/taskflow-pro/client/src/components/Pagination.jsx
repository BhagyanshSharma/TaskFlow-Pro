export default function Pagination({ pagination, onChange }) {
  if (!pagination || pagination.totalPages <= 1) return null;
  const { page, totalPages, total, limit } = pagination;
  const from = (page - 1) * limit + 1;
  const to = Math.min(page * limit, total);
  return (
    <nav className="d-flex align-items-center justify-content-between flex-wrap gap-2 mt-3" aria-label="Pagination">
      <span className="small text-body-secondary">Showing {from}–{to} of {total}</span>
      <div className="btn-group">
        <button type="button" className="btn btn-sm btn-outline-secondary" disabled={page <= 1} onClick={() => onChange(page - 1)}>
          <i className="bi bi-chevron-left" /> Prev
        </button>
        <span className="btn btn-sm btn-outline-secondary disabled tabular">{page} / {totalPages}</span>
        <button type="button" className="btn btn-sm btn-outline-secondary" disabled={page >= totalPages} onClick={() => onChange(page + 1)}>
          Next <i className="bi bi-chevron-right" />
        </button>
      </div>
    </nav>
  );
}
