import { useEffect, useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import { favouriteApi } from '../api/services';
import { useAuth } from '../context/AuthContext';
import Avatar from './Avatar';

const NAV = [
  { to: '/dashboard', icon: 'bi-grid-1x2', label: 'Dashboard' },
  { to: '/projects', icon: 'bi-kanban', label: 'Projects' },
  { to: '/tasks', icon: 'bi-check2-square', label: 'Tasks' },
  { to: '/activity', icon: 'bi-clock-history', label: 'Activity' },
];

export default function Sidebar({ open, onClose, version }) {
  const { user } = useAuth();
  const [favourites, setFavourites] = useState([]);

  useEffect(() => {
    favouriteApi.list().then(setFavourites).catch(() => setFavourites([]));
  }, [version]);

  return (
    <>
      <aside className={`sidebar ${open ? 'open' : ''}`} aria-label="Main navigation">
        <Link to="/dashboard" className="brand" onClick={onClose}>
          <span className="brand-mark"><i className="bi bi-check2" /></span>
          <span className="brand-name">TaskFlow <em>Pro</em></span>
        </Link>

        <nav className="side-nav">
          <div className="side-label">Workspace</div>
          {NAV.map((n) => (
            <NavLink key={n.to} to={n.to} className="side-link" onClick={onClose}>
              <i className={`bi ${n.icon}`} />
              <span>{n.label}</span>
            </NavLink>
          ))}

          <div className="side-label mt-4 d-flex align-items-center justify-content-between">
            <span>Favourites</span>
            <i className="bi bi-star-fill text-warning" />
          </div>
          {favourites.length === 0 && <p className="side-empty">Star a project to pin it here.</p>}
          {favourites.map((p) => (
            <NavLink key={p.id} to={`/projects/${p.id}`} className="side-link side-fav" onClick={onClose}>
              <span className="fav-dot" style={{ '--p': `${p.progress}%` }} />
              <span className="text-truncate">{p.name}</span>
            </NavLink>
          ))}

          <div className="side-label mt-4">Account</div>
          <NavLink to="/profile" className="side-link" onClick={onClose}><i className="bi bi-person" /><span>Profile</span></NavLink>
          <NavLink to="/settings" className="side-link" onClick={onClose}><i className="bi bi-gear" /><span>Settings</span></NavLink>
        </nav>

        <div className="side-user">
          <Avatar name={user.name} color={user.avatar_color} size={34} />
          <div className="min-w-0">
            <div className="small fw-semibold text-truncate">{user.name}</div>
            <div className="small side-muted text-truncate">{user.role === 'admin' ? 'Administrator' : user.job_title || user.email}</div>
          </div>
        </div>
      </aside>
      {open && <div className="sidebar-backdrop" onClick={onClose} aria-hidden="true" />}
    </>
  );
}
