import { useState } from 'react';
import { timeAgo } from '../utils/format';
import Avatar from './Avatar';

const ICONS = {
  project: 'bi-kanban',
  task: 'bi-check2-square',
  comment: 'bi-chat-left-text',
  member: 'bi-person-plus',
  user: 'bi-person',
  note: 'bi-sticky',
};

// Timeline of MongoDB activity entries. Notes written by the current user can be edited/deleted.
export default function ActivityFeed({ items, currentUser, onUpdate, onDelete, compact = false }) {
  const [editing, setEditing] = useState(null);
  const [text, setText] = useState('');

  return (
    <ol className={`activity-feed ${compact ? 'compact' : ''}`}>
      {items.map((a) => {
        const mine = currentUser && a.actor.id === currentUser.id;
        const canEdit = a.editable && mine && onUpdate;
        const canDelete = onDelete && ((a.editable && mine) || currentUser?.role === 'admin');
        return (
          <li key={a.id} className={`activity-item ${a.entityType === 'note' ? 'is-note' : ''}`}>
            <span className="activity-icon"><i className={`bi ${ICONS[a.entityType] || 'bi-dot'}`} /></span>
            <div className="activity-body">
              {editing === a.id ? (
                <form
                  className="d-flex gap-2"
                  onSubmit={async (e) => {
                    e.preventDefault();
                    if (await onUpdate(a, text)) setEditing(null);
                  }}
                >
                  <input className="form-control form-control-sm" value={text} onChange={(e) => setText(e.target.value)} maxLength={500} autoFocus aria-label="Edit note" />
                  <button className="btn btn-sm btn-primary" type="submit">Save</button>
                  <button className="btn btn-sm btn-outline-secondary" type="button" onClick={() => setEditing(null)}>Cancel</button>
                </form>
              ) : (
                <p className="mb-0">{a.entityType === 'note' && <strong className="me-1">{a.actor.name}:</strong>}{a.description}</p>
              )}
              <div className="activity-meta">
                {!compact && <Avatar name={a.actor.name} size={18} />}
                <span>{a.actor.name}</span>
                <span aria-hidden="true">·</span>
                <time dateTime={a.createdAt} title={new Date(a.createdAt).toLocaleString()}>{timeAgo(a.createdAt)}</time>
                {a.metadata?.editedAt && <span className="fst-italic">(edited)</span>}
                {(canEdit || canDelete) && editing !== a.id && (
                  <span className="ms-auto d-flex gap-1">
                    {canEdit && (
                      <button type="button" className="btn btn-link btn-sm p-0" onClick={() => { setEditing(a.id); setText(a.description); }}>Edit</button>
                    )}
                    {canDelete && <button type="button" className="btn btn-link btn-sm p-0 text-danger" onClick={() => onDelete(a)}>Delete</button>}
                  </span>
                )}
              </div>
            </div>
          </li>
        );
      })}
    </ol>
  );
}
