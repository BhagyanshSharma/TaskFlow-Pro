import { useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';

// Lightweight React-controlled modal using Bootstrap 5 classes (no jQuery needed)
export default function Modal({ show, title, onClose, children, footer, size = '', busy = false }) {
  const dialogRef = useRef(null);

  useEffect(() => {
    if (!show) return undefined;
    const onKey = (e) => e.key === 'Escape' && !busy && onClose();
    document.addEventListener('keydown', onKey);
    document.body.classList.add('modal-open');
    const first = dialogRef.current?.querySelector('input, select, textarea, button:not(.btn-close)');
    first?.focus();
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.classList.remove('modal-open');
    };
  }, [show, onClose, busy]);

  if (!show) return null;
  return createPortal(
    <>
      <div className="modal fade show d-block" role="dialog" aria-modal="true" aria-label={title} onMouseDown={(e) => e.target === e.currentTarget && !busy && onClose()}>
        <div className={`modal-dialog modal-dialog-centered modal-dialog-scrollable ${size ? `modal-${size}` : ''}`} ref={dialogRef}>
          <div className="modal-content tf-modal">
            <div className="modal-header">
              <h2 className="modal-title h5">{title}</h2>
              <button type="button" className="btn-close" aria-label="Close" onClick={onClose} disabled={busy} />
            </div>
            <div className="modal-body">{children}</div>
            {footer && <div className="modal-footer">{footer}</div>}
          </div>
        </div>
      </div>
      <div className="modal-backdrop fade show" />
    </>,
    document.body
  );
}
