import { useEffect, useState } from 'react';
import Modal from './Modal';
import { projectApi } from '../api/services';
import { fieldErrors } from '../api/client';
import { notify } from '../utils/notify';
import { PRIORITIES, PROJECT_STATUSES } from '../utils/constants';

const EMPTY = { name: '', description: '', status: 'Planning', priority: 'Medium', start_date: '', deadline: '' };

function validate(form) {
  const errors = {};
  if (!form.name.trim()) errors.name = 'Project name is required';
  else if (form.name.trim().length < 3) errors.name = 'Project name must be at least 3 characters';
  if (form.start_date && form.deadline && form.deadline < form.start_date) errors.deadline = 'Deadline cannot be before the start date';
  return errors;
}

export default function ProjectFormModal({ show, project, onClose, onSaved }) {
  const editing = Boolean(project);
  const [form, setForm] = useState(EMPTY);
  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!show) return;
    setErrors({});
    setForm(
      project
        ? {
            name: project.name,
            description: project.description || '',
            status: project.status,
            priority: project.priority,
            start_date: project.start_date || '',
            deadline: project.deadline || '',
          }
        : EMPTY
    );
  }, [show, project]);

  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));

  async function submit(e) {
    e.preventDefault();
    const v = validate(form);
    setErrors(v);
    if (Object.keys(v).length) return;
    setSaving(true);
    try {
      const payload = { ...form, name: form.name.trim(), description: form.description.trim() };
      const res = editing ? await projectApi.update(project.id, payload) : await projectApi.create(payload);
      notify.success(res.message);
      onSaved(res.data);
      onClose();
    } catch (err) {
      setErrors(fieldErrors(err));
      notify.apiError(err);
    } finally {
      setSaving(false);
    }
  }

  return (
    <Modal
      show={show}
      onClose={onClose}
      busy={saving}
      title={editing ? 'Edit project' : 'New project'}
      footer={
        <>
          <button type="button" className="btn btn-outline-secondary" onClick={onClose} disabled={saving}>Cancel</button>
          <button type="submit" form="project-form" className="btn btn-primary" disabled={saving}>
            {saving && <span className="spinner-border spinner-border-sm me-2" />}
            {editing ? 'Save changes' : 'Create project'}
          </button>
        </>
      }
    >
      <form id="project-form" onSubmit={submit} noValidate>
        <div className="mb-3">
          <label className="form-label" htmlFor="p-name">Project name <span className="text-danger">*</span></label>
          <input id="p-name" className={`form-control ${errors.name ? 'is-invalid' : ''}`} value={form.name} onChange={set('name')} maxLength={120} placeholder="e.g. Campus Event Portal" />
          <div className="invalid-feedback">{errors.name}</div>
        </div>
        <div className="mb-3">
          <label className="form-label" htmlFor="p-desc">Description</label>
          <textarea id="p-desc" className={`form-control ${errors.description ? 'is-invalid' : ''}`} rows={3} value={form.description} onChange={set('description')} placeholder="What is this project about?" />
          <div className="invalid-feedback">{errors.description}</div>
        </div>
        <div className="row g-3">
          <div className="col-sm-6">
            <label className="form-label" htmlFor="p-status">Status</label>
            <select id="p-status" className="form-select" value={form.status} onChange={set('status')}>
              {PROJECT_STATUSES.map((s) => <option key={s}>{s}</option>)}
            </select>
          </div>
          <div className="col-sm-6">
            <label className="form-label" htmlFor="p-priority">Priority</label>
            <select id="p-priority" className="form-select" value={form.priority} onChange={set('priority')}>
              {PRIORITIES.map((p) => <option key={p}>{p}</option>)}
            </select>
          </div>
          <div className="col-sm-6">
            <label className="form-label" htmlFor="p-start">Start date</label>
            <input id="p-start" type="date" className={`form-control ${errors.start_date ? 'is-invalid' : ''}`} value={form.start_date} onChange={set('start_date')} />
            <div className="invalid-feedback">{errors.start_date}</div>
          </div>
          <div className="col-sm-6">
            <label className="form-label" htmlFor="p-deadline">Deadline</label>
            <input id="p-deadline" type="date" className={`form-control ${errors.deadline ? 'is-invalid' : ''}`} value={form.deadline} min={form.start_date || undefined} onChange={set('deadline')} />
            <div className="invalid-feedback">{errors.deadline}</div>
          </div>
        </div>
        {!editing && <p className="small text-body-secondary mt-3 mb-0"><i className="bi bi-info-circle me-1" />You will be the owner. Add team members from the project page.</p>}
      </form>
    </Modal>
  );
}
