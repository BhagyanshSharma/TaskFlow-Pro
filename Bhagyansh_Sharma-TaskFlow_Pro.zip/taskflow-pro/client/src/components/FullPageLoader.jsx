export default function FullPageLoader({ text = 'Loading TaskFlow Pro…' }) {
  return (
    <div className="full-loader" role="status" aria-live="polite">
      <div className="brand-mark brand-mark-lg pulse"><i className="bi bi-check2" /></div>
      <p className="text-body-secondary mt-3 mb-0">{text}</p>
    </div>
  );
}
