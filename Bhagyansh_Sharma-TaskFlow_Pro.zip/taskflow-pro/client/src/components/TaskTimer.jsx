import { useMemo, useState } from 'react';
import useNow from '../hooks/useNow';
import { formatDuration } from '../utils/format';
import { taskApi } from '../api/services';
import { confirmAction, notify } from '../utils/notify';

// Start/stop time tracker carried over from the original LocalStorage project,
// now stored in MongoDB (time logs collection) so it survives refreshes and devices.
export default function TaskTimer({ task, canEdit, onChange, compact = false }) {
  const running = Boolean(task.timer_started_at);
  const now = useNow(running);
  const [busy, setBusy] = useState(false);

  // tracked_seconds already includes the running segment up to the moment the task was loaded;
  // remember when we received it and add the time passed since then so the clock ticks live.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const loadedAt = useMemo(() => Date.now(), [task.tracked_seconds, task.timer_started_at]);
  const seconds = task.tracked_seconds + (running ? Math.max(0, Math.floor((now - loadedAt) / 1000)) : 0);

  async function toggle(e) {
    e.stopPropagation();
    const ok = await confirmAction({
      title: running ? 'Stop the timer?' : 'Start the timer?',
      text: running ? 'The time spent will be saved to this task.' : 'Time will be tracked until you stop it.',
      confirmText: running ? 'Stop timer' : 'Start timer',
      danger: false,
    });
    if (!ok) return;
    setBusy(true);
    try {
      const res = running ? await taskApi.stopTimer(task.id) : await taskApi.startTimer(task.id);
      notify.success(res.message);
      onChange?.(res.data);
    } catch (err) {
      notify.apiError(err);
    } finally {
      setBusy(false);
    }
  }

  return (
    <span className={`timer ${running ? 'running' : ''} ${compact ? 'compact' : ''}`}>
      <span className="tabular" aria-label="Time tracked">{formatDuration(seconds)}</span>
      {canEdit && task.status !== 'Completed' && (
        <button type="button" className={`btn btn-sm ${running ? 'btn-danger' : 'btn-outline-primary'} timer-btn`} onClick={toggle} disabled={busy} title={running ? 'Stop timer' : 'Start timer'} aria-label={running ? 'Stop timer' : 'Start timer'}>
          <i className={`bi ${running ? 'bi-stop-fill' : 'bi-play-fill'}`} />
          {!compact && <span className="ms-1">{running ? 'Stop' : 'Start'}</span>}
        </button>
      )}
    </span>
  );
}
