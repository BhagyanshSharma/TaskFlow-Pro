import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { projectApi, taskApi } from '../api/services';
import useDebounce from '../hooks/useDebounce';
import { StatusBadge } from './Badges';

// Topbar search across projects and tasks (both come from MongoDB through the API)
export default function GlobalSearch({ onOpenTask }) {
  const [q, setQ] = useState('');
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState({ projects: [], tasks: [] });
  const debounced = useDebounce(q, 300);
  const navigate = useNavigate();
  const boxRef = useRef(null);

  useEffect(() => {
    const term = debounced.trim();
    if (term.length < 2) {
      setResults({ projects: [], tasks: [] });
      return;
    }
    setLoading(true);
    Promise.all([projectApi.list({ q: term, limit: 5 }), taskApi.list({ q: term, limit: 6 })])
      .then(([p, t]) => setResults({ projects: p.items, tasks: t.items }))
      .catch(() => setResults({ projects: [], tasks: [] }))
      .finally(() => setLoading(false));
  }, [debounced]);

  useEffect(() => {
    const close = (e) => !boxRef.current?.contains(e.target) && setOpen(false);
    document.addEventListener('mousedown', close);
    return () => document.removeEventListener('mousedown', close);
  }, []);

  function go(path) {
    setOpen(false);
    setQ('');
    navigate(path);
  }

  const empty = !loading && debounced.trim().length >= 2 && !results.projects.length && !results.tasks.length;

  return (
    <div className="global-search" ref={boxRef}>
      <form
        role="search"
        onSubmit={(e) => {
          e.preventDefault();
          if (q.trim()) go(`/tasks?q=${encodeURIComponent(q.trim())}`);
        }}
      >
        <i className="bi bi-search search-icon" aria-hidden="true" />
        <input
          type="search"
          className="form-control"
          placeholder="Search projects and tasks…"
          value={q}
          onChange={(e) => { setQ(e.target.value); setOpen(true); }}
          onFocus={() => setOpen(true)}
          onKeyDown={(e) => e.key === 'Escape' && setOpen(false)}
          aria-label="Search projects and tasks"
        />
      </form>
      {open && debounced.trim().length >= 2 && (
        <div className="search-pop shadow">
          {loading && <div className="p-3 small text-body-secondary"><span className="spinner-border spinner-border-sm me-2" />Searching…</div>}
          {empty && <div className="p-3 small text-body-secondary">No projects or tasks match “{debounced}”.</div>}
          {results.projects.length > 0 && (
            <>
              <div className="search-group">Projects</div>
              {results.projects.map((p) => (
                <button type="button" key={`p${p.id}`} className="search-item" onClick={() => go(`/projects/${p.id}`)}>
                  <i className="bi bi-kanban text-primary" />
                  <span className="text-truncate">{p.name}</span>
                  <span className="ms-auto small text-body-secondary">{p.progress}%</span>
                </button>
              ))}
            </>
          )}
          {results.tasks.length > 0 && (
            <>
              <div className="search-group">Tasks</div>
              {results.tasks.map((t) => (
                <button type="button" key={`t${t.id}`} className="search-item" onClick={() => { setOpen(false); setQ(''); onOpenTask(t.id); }}>
                  <i className="bi bi-check2-square text-primary" />
                  <span className="text-truncate">{t.title}<span className="d-block small text-body-secondary text-truncate">{t.project.name}</span></span>
                  <span className="ms-auto"><StatusBadge status={t.status} /></span>
                </button>
              ))}
              <button type="button" className="search-item justify-content-center small fw-semibold text-primary" onClick={() => go(`/tasks?q=${encodeURIComponent(debounced.trim())}`)}>
                See all matching tasks
              </button>
            </>
          )}
        </div>
      )}
    </div>
  );
}
