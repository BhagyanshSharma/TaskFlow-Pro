import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { projectApi, userApi } from '../api/services';
import { useAuth } from '../context/AuthContext';
import useDebounce from '../hooks/useDebounce';
import { confirmAction, notify } from '../utils/notify';
import { ROLE_LABEL } from '../utils/constants';
import Avatar from './Avatar';

// Team tab on the project page: list, add (search registered users), change role, remove, leave
export default function MemberManager({ project, onMembersChange }) {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [members, setMembers] = useState(project.members || []);
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [role, setRole] = useState('member');
  const [busy, setBusy] = useState(false);
  const debounced = useDebounce(query, 300);
  const canManage = ['owner', 'manager', 'admin'].includes(project.my_role);
  const isOwner = ['owner', 'admin'].includes(project.my_role);

  useEffect(() => setMembers(project.members || []), [project.members]);

  useEffect(() => {
    if (debounced.trim().length < 2) {
      setResults([]);
      return;
    }
    userApi.search(debounced.trim()).then((list) => setResults(list.filter((u) => !members.some((m) => m.id === u.id)))).catch(() => setResults([]));
  }, [debounced, members]);

  function update(list, message) {
    setMembers(list);
    onMembersChange?.(list);
    if (message) notify.success(message);
  }

  async function add(target) {
    setBusy(true);
    try {
      const res = await projectApi.addMember(project.id, { user_id: target.id, role });
      update(res.data, res.message);
      setQuery('');
      setResults([]);
    } catch (err) {
      notify.apiError(err);
    } finally {
      setBusy(false);
    }
  }

  async function addByEmail(e) {
    e.preventDefault();
    if (!/^\S+@\S+\.\S+$/.test(query.trim())) {
      notify.error('Pick a user from the list or type their full email address');
      return;
    }
    setBusy(true);
    try {
      const res = await projectApi.addMember(project.id, { email: query.trim(), role });
      update(res.data, res.message);
      setQuery('');
    } catch (err) {
      notify.apiError(err);
    } finally {
      setBusy(false);
    }
  }

  async function changeRole(m, newRole) {
    try {
      const res = await projectApi.updateMember(project.id, m.id, newRole);
      update(res.data, res.message);
    } catch (err) {
      notify.apiError(err);
    }
  }

  async function remove(m) {
    const self = m.id === user.id;
    const ok = await confirmAction({
      title: self ? 'Leave this project?' : `Remove ${m.name}?`,
      text: self ? 'You will lose access to its tasks.' : 'Their open tasks in this project will become unassigned.',
      confirmText: self ? 'Leave project' : 'Remove member',
    });
    if (!ok) return;
    try {
      const res = await projectApi.removeMember(project.id, m.id);
      if (self) {
        notify.success(res.message);
        navigate('/projects');
        return;
      }
      update(res.data, res.message);
    } catch (err) {
      notify.apiError(err);
    }
  }

  return (
    <div className="row g-4">
      <div className={canManage ? 'col-lg-7' : 'col-12'}>
        <div className="tf-card p-0">
          <ul className="list-group list-group-flush member-list">
            {members.map((m) => (
              <li key={m.id} className="list-group-item d-flex align-items-center gap-3 flex-wrap">
                <Avatar name={m.name} color={m.avatar_color} size={38} />
                <div className="flex-grow-1 min-w-0">
                  <div className="fw-semibold text-truncate">{m.name}{m.id === user.id && <span className="text-body-secondary fw-normal"> (you)</span>}</div>
                  <div className="small text-body-secondary text-truncate">{m.job_title || m.email} · {m.open_tasks} open task{Number(m.open_tasks) === 1 ? '' : 's'}</div>
                </div>
                {isOwner && m.role !== 'owner' ? (
                  <select className="form-select form-select-sm w-auto" value={m.role} onChange={(e) => changeRole(m, e.target.value)} aria-label={`Role of ${m.name}`}>
                    <option value="manager">Manager</option>
                    <option value="member">Member</option>
                  </select>
                ) : (
                  <span className={`role-chip role-${m.role}`}>{ROLE_LABEL[m.role]}</span>
                )}
                {m.role !== 'owner' && (canManage || m.id === user.id) && (
                  <button type="button" className="btn btn-sm btn-light text-danger" onClick={() => remove(m)} title={m.id === user.id ? 'Leave project' : 'Remove member'} aria-label={m.id === user.id ? 'Leave project' : `Remove ${m.name}`}>
                    <i className={`bi ${m.id === user.id ? 'bi-box-arrow-right' : 'bi-person-dash'}`} />
                  </button>
                )}
              </li>
            ))}
          </ul>
        </div>
      </div>

      {canManage && (
        <div className="col-lg-5">
          <div className="tf-card">
            <h3 className="h6 mb-1">Add a team member</h3>
            <p className="small text-body-secondary">Search registered users by name or email.</p>
            <form onSubmit={addByEmail} className="position-relative">
              <div className="input-group mb-2">
                <span className="input-group-text"><i className="bi bi-search" /></span>
                <input className="form-control" placeholder="Name or email" value={query} onChange={(e) => setQuery(e.target.value)} aria-label="Search users" />
              </div>
              <div className="d-flex gap-2">
                <select className="form-select" value={role} onChange={(e) => setRole(e.target.value)} aria-label="Role for new member">
                  <option value="member">as Member</option>
                  <option value="manager">as Manager</option>
                </select>
                <button className="btn btn-primary text-nowrap" type="submit" disabled={busy}><i className="bi bi-person-plus me-1" />Add</button>
              </div>
              {results.length > 0 && (
                <ul className="list-group mt-2 search-results">
                  {results.map((u) => (
                    <li key={u.id} className="list-group-item list-group-item-action d-flex align-items-center gap-2" role="button" onClick={() => add(u)}>
                      <Avatar name={u.name} color={u.avatar_color} size={28} />
                      <div className="min-w-0"><div className="small fw-semibold">{u.name}</div><div className="small text-body-secondary text-truncate">{u.email}</div></div>
                      <i className="bi bi-plus-circle ms-auto text-primary" />
                    </li>
                  ))}
                </ul>
              )}
              {debounced.trim().length >= 2 && results.length === 0 && <p className="small text-body-secondary mt-2 mb-0">No matching users who are not already members.</p>}
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
