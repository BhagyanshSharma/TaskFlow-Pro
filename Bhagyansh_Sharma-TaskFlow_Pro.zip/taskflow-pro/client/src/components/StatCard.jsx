import { Link } from 'react-router-dom';

export default function StatCard({ icon, label, value, tone = 'brand', hint, to }) {
  const body = (
    <div className={`stat-card tone-${tone} h-100`}>
      <div className="d-flex align-items-start justify-content-between">
        <div>
          <div className="stat-label">{label}</div>
          <div className="stat-value tabular">{value}</div>
        </div>
        <span className="stat-icon"><i className={`bi ${icon}`} /></span>
      </div>
      {hint && <div className="stat-hint">{hint}</div>}
    </div>
  );
  return to ? <Link to={to} className="text-reset text-decoration-none d-block h-100 stat-link">{body}</Link> : body;
}
