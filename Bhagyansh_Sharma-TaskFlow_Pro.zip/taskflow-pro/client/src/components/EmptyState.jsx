export default function EmptyState({ icon = 'bi-inbox', title, text, action, compact = false }) {
  return (
    <div className={`empty-state text-center ${compact ? 'py-4' : 'py-5'}`}>
      <div className="empty-icon"><i className={`bi ${icon}`} /></div>
      <h3 className="h6 mt-3 mb-1">{title}</h3>
      {text && <p className="text-body-secondary small mb-3 mx-auto" style={{ maxWidth: 360 }}>{text}</p>}
      {action}
    </div>
  );
}

export function ErrorState({ message, onRetry }) {
  return (
    <div className="alert alert-danger d-flex align-items-center justify-content-between gap-3 flex-wrap" role="alert">
      <span><i className="bi bi-exclamation-octagon me-2" />{message}</span>
      {onRetry && (
        <button type="button" className="btn btn-sm btn-outline-danger" onClick={() => onRetry()}>
          <i className="bi bi-arrow-clockwise me-1" />Try again
        </button>
      )}
    </div>
  );
}
