import { Link, useOutletContext } from 'react-router-dom';
import { Chart as ChartJS, ArcElement, BarElement, CategoryScale, LinearScale, Tooltip, Legend } from 'chart.js';
import { Bar, Doughnut } from 'react-chartjs-2';
import { dashboardApi } from '../api/services';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import useAsync from '../hooks/useAsync';
import useDocumentTitle from '../hooks/useDocumentTitle';
import StatCard from '../components/StatCard';
import ProgressBar from '../components/ProgressBar';
import EmptyState, { ErrorState } from '../components/EmptyState';
import ActivityFeed from '../components/ActivityFeed';
import Loader from '../components/Loader';
import { PriorityBadge, StatusBadge } from '../components/Badges';
import { formatDate } from '../utils/format';

ChartJS.register(ArcElement, BarElement, CategoryScale, LinearScale, Tooltip, Legend);

const STATUS_COLORS = ['#94a3b8', '#7c3aed', '#f59e0b', '#10b981'];
const PRIORITY_COLORS = ['#94a3b8', '#3b82f6', '#f97316', '#e11d48'];

function greeting() {
  const h = new Date().getHours();
  return h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening';
}

export default function Dashboard() {
  useDocumentTitle('Dashboard');
  const { user } = useAuth();
  const { theme } = useTheme();
  const { openTask, openNewTask, version } = useOutletContext();
  const { data, loading, error, reload } = useAsync(() => dashboardApi.get(), [version]);

  const textColor = theme === 'dark' ? '#b9b0c9' : '#5b5470';
  const gridColor = theme === 'dark' ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.06)';

  if (loading && !data) return <Loader text="Loading your dashboard…" />;
  if (error && !data) return <ErrorState message={error} onRetry={reload} />;

  const { tasks, projects } = data;
  const hasTasks = tasks.total > 0;

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <h1 className="page-title">{greeting()}, {user.name.split(' ')[0]}</h1>
          <p className="page-sub">
            {hasTasks
              ? <>You have <strong>{tasks.assigned_to_me}</strong> open task{tasks.assigned_to_me === 1 ? '' : 's'} assigned to you{tasks.overdue > 0 && <> and <strong className="text-danger">{tasks.overdue}</strong> overdue across your projects</>}.</>
              : 'Create a project and add tasks to see your statistics here.'}
          </p>
        </div>
        <div className="d-flex gap-2">
          <Link to="/projects?new=1" className="btn btn-outline-primary"><i className="bi bi-kanban me-1" />New project</Link>
          <button type="button" className="btn btn-primary" onClick={() => openNewTask()}><i className="bi bi-plus-lg me-1" />New task</button>
        </div>
      </div>

      <div className="row g-3 mb-4">
        <div className="col-6 col-md-4 col-xl-2"><StatCard icon="bi-kanban" label="Projects" value={projects.total} hint={`${projects.active} active`} to="/projects" /></div>
        <div className="col-6 col-md-4 col-xl-2"><StatCard icon="bi-list-task" label="Total tasks" value={tasks.total} hint={`${tasks.completion_rate}% completed`} to="/tasks" tone="slate" /></div>
        <div className="col-6 col-md-4 col-xl-2"><StatCard icon="bi-hourglass" label="Pending" value={tasks.pending} hint="To Do" to="/tasks?status=To%20Do" tone="slate" /></div>
        <div className="col-6 col-md-4 col-xl-2"><StatCard icon="bi-arrow-repeat" label="In progress" value={tasks.in_progress} hint={`${tasks.in_review} in review`} to="/tasks?status=In%20Progress" tone="violet" /></div>
        <div className="col-6 col-md-4 col-xl-2"><StatCard icon="bi-check2-circle" label="Completed" value={tasks.completed} hint={`Overall progress ${tasks.overall_progress}%`} to="/tasks?status=Completed" tone="green" /></div>
        <div className="col-6 col-md-4 col-xl-2"><StatCard icon="bi-alarm" label="Overdue" value={tasks.overdue} hint={tasks.overdue ? 'Needs attention' : 'All on track'} to="/tasks?overdue=true" tone="red" /></div>
      </div>

      <div className="row g-4">
        <div className="col-lg-8">
          <div className="row g-4">
            <div className="col-md-6">
              <section className="tf-card h-100">
                <h2 className="card-title-sm">Tasks by status</h2>
                {hasTasks ? (
                  <div className="chart-box">
                    <Doughnut
                      data={{
                        labels: ['To Do', 'In Progress', 'In Review', 'Completed'],
                        datasets: [{ data: [tasks.todo, tasks.in_progress, tasks.in_review, tasks.completed], backgroundColor: STATUS_COLORS, borderWidth: 0 }],
                      }}
                      options={{ maintainAspectRatio: false, cutout: '68%', plugins: { legend: { position: 'bottom', labels: { color: textColor, boxWidth: 10, usePointStyle: true } } } }}
                    />
                  </div>
                ) : <EmptyState compact icon="bi-pie-chart" title="No tasks yet" />}
              </section>
            </div>
            <div className="col-md-6">
              <section className="tf-card h-100">
                <h2 className="card-title-sm">Open tasks by priority</h2>
                {hasTasks ? (
                  <div className="chart-box">
                    <Bar
                      data={{
                        labels: data.priority_breakdown.map((p) => p.priority),
                        datasets: [{ data: data.priority_breakdown.map((p) => p.count), backgroundColor: PRIORITY_COLORS, borderRadius: 6, maxBarThickness: 38 }],
                      }}
                      options={{
                        maintainAspectRatio: false,
                        plugins: { legend: { display: false } },
                        scales: {
                          x: { ticks: { color: textColor }, grid: { display: false } },
                          y: { beginAtZero: true, ticks: { color: textColor, precision: 0 }, grid: { color: gridColor } },
                        },
                      }}
                    />
                  </div>
                ) : <EmptyState compact icon="bi-bar-chart" title="No tasks yet" />}
              </section>
            </div>

            <div className="col-12">
              <section className="tf-card">
                <div className="d-flex justify-content-between align-items-center mb-3">
                  <h2 className="card-title-sm mb-0">Project progress</h2>
                  <Link to="/projects" className="small">All projects</Link>
                </div>
                {data.project_progress.length === 0 ? (
                  <EmptyState compact icon="bi-kanban" title="No active projects" text="Create a project to start tracking progress." action={<Link to="/projects?new=1" className="btn btn-sm btn-primary">Create project</Link>} />
                ) : (
                  <ul className="list-unstyled mb-0 progress-list">
                    {data.project_progress.map((p) => (
                      <li key={p.id}>
                        <div className="d-flex justify-content-between align-items-center gap-2 mb-1 flex-wrap">
                          <Link to={`/projects/${p.id}`} className="fw-semibold text-reset text-decoration-none">{p.name}</Link>
                          <span className="small text-body-secondary">{p.completed_tasks}/{p.total_tasks} tasks · due {formatDate(p.deadline, { day: 'numeric', month: 'short' })}</span>
                        </div>
                        <ProgressBar value={p.progress} showLabel />
                      </li>
                    ))}
                  </ul>
                )}
              </section>
            </div>

            <div className="col-md-6">
              <section className="tf-card h-100">
                <h2 className="card-title-sm">Upcoming deadlines <span className="text-body-secondary fw-normal">(14 days)</span></h2>
                {data.upcoming_deadlines.length === 0 ? <p className="small text-body-secondary mb-0">Nothing due in the next two weeks.</p> : (
                  <ul className="list-unstyled mb-0 mini-list">
                    {data.upcoming_deadlines.map((t) => (
                      <li key={t.id}>
                        <button type="button" className="mini-item" onClick={() => openTask(t.id)}>
                          <span className={`days-pill ${t.days_left <= 1 ? 'hot' : ''}`}>{t.days_left === 0 ? 'Today' : `${t.days_left}d`}</span>
                          <span className="min-w-0"><span className="d-block text-truncate">{t.title}</span><span className="small text-body-secondary text-truncate d-block">{t.project_name}</span></span>
                          <PriorityBadge priority={t.priority} />
                        </button>
                      </li>
                    ))}
                  </ul>
                )}
              </section>
            </div>
            <div className="col-md-6">
              <section className="tf-card h-100">
                <h2 className="card-title-sm text-danger">Overdue</h2>
                {data.overdue_tasks.length === 0 ? <p className="small text-body-secondary mb-0"><i className="bi bi-emoji-smile me-1" />No overdue tasks.</p> : (
                  <ul className="list-unstyled mb-0 mini-list">
                    {data.overdue_tasks.map((t) => (
                      <li key={t.id}>
                        <button type="button" className="mini-item" onClick={() => openTask(t.id)}>
                          <span className="days-pill late">{t.days_overdue}d late</span>
                          <span className="min-w-0"><span className="d-block text-truncate">{t.title}</span><span className="small text-body-secondary text-truncate d-block">{t.project_name}</span></span>
                          <PriorityBadge priority={t.priority} />
                        </button>
                      </li>
                    ))}
                  </ul>
                )}
              </section>
            </div>
          </div>
        </div>

        <div className="col-lg-4">
          <section className="tf-card mb-4">
            <div className="d-flex justify-content-between align-items-center mb-2">
              <h2 className="card-title-sm mb-0">My open tasks</h2>
              <Link to="/tasks?assignee=me" className="small">View all</Link>
            </div>
            {data.my_tasks.length === 0 ? <p className="small text-body-secondary mb-0">Nothing assigned to you right now.</p> : (
              <ul className="list-unstyled mb-0 mini-list">
                {data.my_tasks.map((t) => (
                  <li key={t.id}>
                    <button type="button" className="mini-item" onClick={() => openTask(t.id)}>
                      <span className="min-w-0 flex-grow-1"><span className="d-block text-truncate">{t.title}</span><span className="small text-body-secondary">{t.project_name}</span></span>
                      <StatusBadge status={t.status} />
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </section>

          <section className="tf-card">
            <div className="d-flex justify-content-between align-items-center mb-2">
              <h2 className="card-title-sm mb-0">Recent activity</h2>
              <Link to="/activity" className="small">Open log</Link>
            </div>
            {!data.activity_available ? (
              <div className="alert alert-warning small mb-0"><i className="bi bi-database-exclamation me-2" />Activity log needs MongoDB. Set <code>MONGODB_URI</code> on the server.</div>
            ) : data.recent_activity.length === 0 ? (
              <p className="small text-body-secondary mb-0">No activity yet.</p>
            ) : (
              <ActivityFeed items={data.recent_activity} currentUser={user} compact />
            )}
          </section>
        </div>
      </div>
    </div>
  );
}
