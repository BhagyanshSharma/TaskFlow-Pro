import { useCallback, useEffect, useState } from 'react';
import { Link, useNavigate, useOutletContext, useParams } from 'react-router-dom';
import { activityApi, favouriteApi, projectApi, taskApi } from '../api/services';
import { errorMessage } from '../api/client';
import { useAuth } from '../context/AuthContext';
import useAsync from '../hooks/useAsync';
import useDebounce from '../hooks/useDebounce';
import useDocumentTitle from '../hooks/useDocumentTitle';
import { getPref, setPref } from '../utils/storage';
import { confirmAction, notify } from '../utils/notify';
import { PRIORITIES, ROLE_LABEL } from '../utils/constants';
import { dueLabel, formatDate } from '../utils/format';
import { DueBadge, PriorityBadge, StatusBadge } from '../components/Badges';
import ProgressBar from '../components/ProgressBar';
import TaskBoard from '../components/TaskBoard';
import TaskTable from '../components/TaskTable';
import MemberManager from '../components/MemberManager';
import ActivityFeed from '../components/ActivityFeed';
import ProjectFormModal from '../components/ProjectFormModal';
import Loader from '../components/Loader';
import Pagination from '../components/Pagination';
import EmptyState, { ErrorState } from '../components/EmptyState';
import { AvatarStack } from '../components/Avatar';

const TABS = [
  { key: 'tasks', label: 'Tasks', icon: 'bi-check2-square' },
  { key: 'team', label: 'Team', icon: 'bi-people' },
  { key: 'activity', label: 'Activity', icon: 'bi-clock-history' },
  { key: 'overview', label: 'Overview', icon: 'bi-info-circle' },
];

export default function ProjectDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { openTask, openNewTask, version, bump } = useOutletContext();
  const [tab, setTab] = useState('tasks');
  const [editOpen, setEditOpen] = useState(false);

  const projectState = useAsync(() => projectApi.get(id), [id, version]);
  const project = projectState.data;
  useDocumentTitle(project?.name || 'Project');

  if (projectState.loading && !project) return <Loader text="Loading project…" />;
  if (projectState.error && !project) {
    return (
      <div className="page">
        <Link to="/projects" className="back-link"><i className="bi bi-arrow-left me-1" />Projects</Link>
        {projectState.status === 403 || projectState.status === 404 ? (
          <EmptyState icon={projectState.status === 403 ? 'bi-shield-lock' : 'bi-question-circle'} title={projectState.status === 403 ? 'You do not have access to this project' : 'Project not found'} text={projectState.error} action={<Link to="/projects" className="btn btn-primary">Back to projects</Link>} />
        ) : (
          <ErrorState message={projectState.error} onRetry={projectState.reload} />
        )}
      </div>
    );
  }

  const canManage = ['owner', 'manager', 'admin'].includes(project.my_role);
  const canDelete = ['owner', 'admin'].includes(project.my_role);
  const c = project.task_counts;

  async function toggleFavourite() {
    try {
      const res = project.is_favourite ? await favouriteApi.remove(project.id) : await favouriteApi.add(project.id);
      notify.success(res.message);
      bump();
    } catch (err) {
      notify.apiError(err);
    }
  }

  async function removeProject() {
    const ok = await confirmAction({ title: `Delete "${project.name}"?`, text: `All ${c.total} task(s), comments and time logs will be permanently deleted.`, confirmText: 'Delete project' });
    if (!ok) return;
    try {
      const res = await projectApi.remove(project.id);
      notify.success(res.message);
      navigate('/projects');
    } catch (err) {
      notify.apiError(err);
    }
  }

  return (
    <div className="page">
      <Link to="/projects" className="back-link"><i className="bi bi-arrow-left me-1" />Projects</Link>

      <section className="tf-card project-hero mb-4">
        <div className="d-flex flex-wrap gap-3 justify-content-between align-items-start">
          <div className="min-w-0">
            <div className="d-flex gap-2 flex-wrap mb-2">
              <StatusBadge status={project.status} />
              <PriorityBadge priority={project.priority} />
              <DueBadge label={dueLabel(project.deadline, project.status === 'Completed')} />
            </div>
            <h1 className="page-title mb-1">{project.name}</h1>
            <p className="text-body-secondary mb-0 small">
              Owned by {project.owner.name} · You are <strong>{ROLE_LABEL[project.my_role]}</strong>
            </p>
          </div>
          <div className="d-flex gap-2 flex-wrap">
            <button type="button" className={`btn ${project.is_favourite ? 'btn-warning' : 'btn-outline-secondary'}`} onClick={toggleFavourite} aria-pressed={project.is_favourite}>
              <i className={`bi ${project.is_favourite ? 'bi-star-fill' : 'bi-star'} me-1`} />{project.is_favourite ? 'Favourited' : 'Favourite'}
            </button>
            {canManage && <button type="button" className="btn btn-outline-primary" onClick={() => setEditOpen(true)}><i className="bi bi-pencil me-1" />Edit</button>}
            {canDelete && <button type="button" className="btn btn-outline-danger" onClick={removeProject}><i className="bi bi-trash me-1" />Delete</button>}
            <button type="button" className="btn btn-primary" onClick={() => openNewTask({ projectId: project.id })}><i className="bi bi-plus-lg me-1" />Add task</button>
          </div>
        </div>

        <div className="hero-stats mt-4">
          <div className="hero-progress">
            <div className="d-flex justify-content-between small mb-1"><span>Progress</span><strong className="tabular">{project.progress}%</strong></div>
            <ProgressBar value={project.progress} height={10} />
            <div className="small text-body-secondary mt-1">{c.completed} of {c.total} tasks completed ({project.completion_rate}%)</div>
          </div>
          <div className="hero-stat"><span>To Do</span><strong>{c.todo}</strong></div>
          <div className="hero-stat"><span>In Progress</span><strong>{c.in_progress}</strong></div>
          <div className="hero-stat"><span>In Review</span><strong>{c.in_review}</strong></div>
          <div className="hero-stat"><span>Overdue</span><strong className={c.overdue ? 'text-danger' : ''}>{c.overdue}</strong></div>
          <div className="hero-stat"><span>Team</span><AvatarStack people={project.members} /></div>
        </div>
      </section>

      <ul className="nav nav-underline mb-3 tabs-scroll" role="tablist">
        {TABS.map((t) => (
          <li className="nav-item" key={t.key}>
            <button type="button" role="tab" aria-selected={tab === t.key} className={`nav-link ${tab === t.key ? 'active' : ''}`} onClick={() => setTab(t.key)}>
              <i className={`bi ${t.icon} me-1`} />{t.label}
              {t.key === 'team' && <span className="tab-count">{project.member_count}</span>}
              {t.key === 'tasks' && <span className="tab-count">{c.total}</span>}
            </button>
          </li>
        ))}
      </ul>

      {tab === 'tasks' && <ProjectTasks project={project} openTask={openTask} openNewTask={openNewTask} version={version} bump={bump} />}
      {tab === 'team' && <MemberManager project={project} onMembersChange={bump} />}
      {tab === 'activity' && <ProjectActivity project={project} user={user} version={version} />}
      {tab === 'overview' && (
        <div className="row g-4">
          <div className="col-lg-8">
            <section className="tf-card h-100">
              <h2 className="card-title-sm">Description</h2>
              <p className="pre-wrap mb-0">{project.description || <span className="text-body-secondary">No description yet.</span>}</p>
            </section>
          </div>
          <div className="col-lg-4">
            <section className="tf-card">
              <dl className="detail-grid mb-0">
                <dt>Status</dt><dd><StatusBadge status={project.status} /></dd>
                <dt>Priority</dt><dd><PriorityBadge priority={project.priority} /></dd>
                <dt>Start date</dt><dd>{formatDate(project.start_date)}</dd>
                <dt>Deadline</dt><dd>{formatDate(project.deadline)}</dd>
                <dt>Owner</dt><dd>{project.owner.name}</dd>
                <dt>Members</dt><dd>{project.member_count}</dd>
              </dl>
            </section>
          </div>
        </div>
      )}

      <ProjectFormModal show={editOpen} project={project} onClose={() => setEditOpen(false)} onSaved={() => bump()} />
    </div>
  );
}

function ProjectTasks({ project, openTask, openNewTask, version, bump }) {
  const [view, setView] = useState(() => getPref('taskView', 'board'));
  const [search, setSearch] = useState('');
  const [priority, setPriority] = useState('');
  const [assignee, setAssignee] = useState('');
  const [sort, setSort] = useState('due_date');
  const q = useDebounce(search);

  const params = { project_id: project.id, q: q || undefined, priority: priority || undefined, assignee: assignee || undefined, sort, order: sort === 'priority' ? 'desc' : 'asc', limit: 200 };
  const { data, loading, error, reload, setData } = useAsync(() => taskApi.list(params), [JSON.stringify(params), version]);

  useEffect(() => setPref('taskView', view), [view]);

  const changeStatus = useCallback(async (task, status) => {
    setData((d) => ({ ...d, items: d.items.map((t) => (t.id === task.id ? { ...t, status } : t)) }));
    try {
      await taskApi.update(task.id, { status });
      notify.success(`"${task.title}" moved to ${status}`);
      bump();
    } catch (err) {
      setData((d) => ({ ...d, items: d.items.map((t) => (t.id === task.id ? { ...t, status: task.status } : t)) }));
      notify.apiError(err);
    }
  }, [bump, setData]);

  const filtered = Boolean(q || priority || assignee);

  return (
    <>
      <div className="filter-bar tf-card">
        <div className="input-group search-input">
          <span className="input-group-text"><i className="bi bi-search" /></span>
          <input className="form-control" placeholder="Search tasks…" value={search} onChange={(e) => setSearch(e.target.value)} aria-label="Search tasks" />
        </div>
        <select className="form-select" value={priority} onChange={(e) => setPriority(e.target.value)} aria-label="Filter by priority">
          <option value="">All priorities</option>
          {PRIORITIES.map((p) => <option key={p}>{p}</option>)}
        </select>
        <select className="form-select" value={assignee} onChange={(e) => setAssignee(e.target.value)} aria-label="Filter by assignee">
          <option value="">Everyone</option>
          <option value="me">Assigned to me</option>
          <option value="unassigned">Unassigned</option>
          {project.members.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}
        </select>
        <select className="form-select" value={sort} onChange={(e) => setSort(e.target.value)} aria-label="Sort tasks">
          <option value="due_date">Deadline</option>
          <option value="priority">Priority</option>
          <option value="status">Status</option>
          <option value="title">Title</option>
        </select>
        <div className="btn-group" role="group" aria-label="View">
          <button type="button" className={`btn ${view === 'board' ? 'btn-primary' : 'btn-outline-secondary'}`} onClick={() => setView('board')} title="Board view" aria-label="Board view"><i className="bi bi-kanban" /></button>
          <button type="button" className={`btn ${view === 'list' ? 'btn-primary' : 'btn-outline-secondary'}`} onClick={() => setView('list')} title="List view" aria-label="List view"><i className="bi bi-list-ul" /></button>
        </div>
      </div>

      {error && <ErrorState message={error} onRetry={reload} />}
      {loading && !data && <Loader text="Loading tasks…" />}
      {data && data.items.length === 0 && !filtered && (
        <EmptyState icon="bi-check2-square" title="No tasks in this project" text="Break the project into tasks and assign them to your team."
          action={<button type="button" className="btn btn-primary" onClick={() => openNewTask({ projectId: project.id })}><i className="bi bi-plus-lg me-1" />Add the first task</button>} />
      )}
      {data && data.items.length === 0 && filtered && <EmptyState icon="bi-funnel" title="No tasks match these filters" />}
      {data && data.items.length > 0 && (
        view === 'board' ? (
          <TaskBoard tasks={data.items} onOpen={(t) => openTask(t.id)} onStatusChange={changeStatus} onAdd={(status) => openNewTask({ projectId: project.id, status })} />
        ) : (
          <TaskTable tasks={data.items} onOpen={(t) => openTask(t.id)} onStatusChange={changeStatus} showProject={false} />
        )
      )}
    </>
  );
}

function ProjectActivity({ project, user, version }) {
  const [page, setPage] = useState(1);
  const [note, setNote] = useState('');
  const [saving, setSaving] = useState(false);
  const { data, loading, error, status, reload } = useAsync(() => activityApi.list({ project_id: project.id, page, limit: 15 }), [project.id, page, version]);

  async function addNote(e) {
    e.preventDefault();
    if (note.trim().length < 2) {
      notify.error('Note must be at least 2 characters');
      return;
    }
    setSaving(true);
    try {
      const res = await activityApi.createNote({ project_id: project.id, description: note.trim() });
      notify.success(res.message);
      setNote('');
      setPage(1);
      reload({ silent: true });
    } catch (err) {
      notify.apiError(err);
    } finally {
      setSaving(false);
    }
  }

  async function updateNote(a, text) {
    try {
      const res = await activityApi.updateNote(a.id, text);
      notify.success(res.message);
      reload({ silent: true });
      return true;
    } catch (err) {
      notify.error(errorMessage(err));
      return false;
    }
  }

  async function deleteEntry(a) {
    if (!(await confirmAction({ title: 'Delete this entry?', text: 'It will be removed from the activity log.', confirmText: 'Delete' }))) return;
    try {
      const res = await activityApi.remove(a.id);
      notify.success(res.message);
      reload({ silent: true });
    } catch (err) {
      notify.apiError(err);
    }
  }

  if (status === 503) {
    return <div className="alert alert-warning"><i className="bi bi-database-exclamation me-2" />The activity log is stored in MongoDB, which is not connected. Set <code>MONGODB_URI</code> in <code>server/.env</code> and restart the API.</div>;
  }

  return (
    <div className="row g-4">
      <div className="col-lg-8">
        <section className="tf-card">
          {error && <ErrorState message={error} onRetry={reload} />}
          {loading && !data && <Loader text="Loading activity…" />}
          {data && data.items.length === 0 && <EmptyState compact icon="bi-clock-history" title="No activity yet" />}
          {data && data.items.length > 0 && <ActivityFeed items={data.items} currentUser={user} onUpdate={updateNote} onDelete={deleteEntry} />}
          <Pagination pagination={data?.pagination} onChange={setPage} />
        </section>
      </div>
      <div className="col-lg-4">
        <section className="tf-card">
          <h2 className="card-title-sm">Post a note</h2>
          <p className="small text-body-secondary">Notes appear in the project timeline for the whole team. You can edit or delete your own notes.</p>
          <form onSubmit={addNote}>
            <textarea className="form-control mb-2" rows={3} maxLength={500} value={note} onChange={(e) => setNote(e.target.value)} placeholder="e.g. Sprint review moved to Friday" aria-label="Note text" />
            <div className="d-flex justify-content-between align-items-center">
              <span className="small text-body-secondary tabular">{note.length}/500</span>
              <button type="submit" className="btn btn-primary btn-sm" disabled={saving}><i className="bi bi-sticky me-1" />Add note</button>
            </div>
          </form>
        </section>
      </div>
    </div>
  );
}
