import { useState } from 'react';
import { userApi } from '../api/services';
import { fieldErrors } from '../api/client';
import { useAuth } from '../context/AuthContext';
import useDocumentTitle from '../hooks/useDocumentTitle';
import { notify } from '../utils/notify';
import { formatDateTime } from '../utils/format';
import Avatar from '../components/Avatar';

const COLOURS = ['#5B0888', '#7C3AED', '#2563EB', '#0F766E', '#B45309', '#BE185D', '#4338CA', '#334155'];

export default function Profile() {
  useDocumentTitle('Profile');
  const { user, setUser } = useAuth();
  const [form, setForm] = useState({ name: user.name, job_title: user.job_title || '', bio: user.bio || '', avatar_color: user.avatar_color });
  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);

  const dirty = form.name !== user.name || form.job_title !== (user.job_title || '') || form.bio !== (user.bio || '') || form.avatar_color !== user.avatar_color;

  async function submit(e) {
    e.preventDefault();
    const v = {};
    if (form.name.trim().length < 2) v.name = 'Name must be at least 2 characters';
    if (form.bio.length > 500) v.bio = 'Bio must be at most 500 characters';
    setErrors(v);
    if (Object.keys(v).length) return;
    setSaving(true);
    try {
      const res = await userApi.updateProfile({ ...form, name: form.name.trim(), job_title: form.job_title.trim(), bio: form.bio.trim() });
      setUser(res.data.user);
      notify.success(res.message);
    } catch (err) {
      setErrors(fieldErrors(err));
      notify.apiError(err);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="page narrow">
      <div className="page-head">
        <div>
          <h1 className="page-title">Profile</h1>
          <p className="page-sub">How you appear to your teammates.</p>
        </div>
      </div>

      <div className="row g-4">
        <div className="col-lg-4">
          <section className="tf-card text-center profile-card">
            <Avatar name={form.name || user.name} color={form.avatar_color} size={88} />
            <h2 className="h5 mt-3 mb-0">{form.name || user.name}</h2>
            <p className="text-body-secondary small mb-2">{form.job_title || 'No job title'}</p>
            <span className={`role-chip role-${user.role === 'admin' ? 'owner' : 'member'}`}>{user.role === 'admin' ? 'Administrator' : 'User'}</span>
            <hr />
            <dl className="detail-grid text-start small mb-0">
              <dt>Email</dt><dd className="text-break">{user.email}</dd>
              <dt>Member since</dt><dd>{formatDateTime(user.created_at)}</dd>
            </dl>
          </section>
        </div>
        <div className="col-lg-8">
          <form className="tf-card" onSubmit={submit} noValidate>
            <h2 className="card-title-sm">Edit details</h2>
            <div className="row g-3">
              <div className="col-md-6">
                <label className="form-label" htmlFor="pf-name">Full name</label>
                <input id="pf-name" className={`form-control ${errors.name ? 'is-invalid' : ''}`} value={form.name} maxLength={80} onChange={(e) => setForm({ ...form, name: e.target.value })} />
                <div className="invalid-feedback">{errors.name}</div>
              </div>
              <div className="col-md-6">
                <label className="form-label" htmlFor="pf-title">Job title</label>
                <input id="pf-title" className={`form-control ${errors.job_title ? 'is-invalid' : ''}`} value={form.job_title} maxLength={80} placeholder="e.g. Frontend Developer" onChange={(e) => setForm({ ...form, job_title: e.target.value })} />
                <div className="invalid-feedback">{errors.job_title}</div>
              </div>
              <div className="col-12">
                <label className="form-label" htmlFor="pf-email">Email</label>
                <input id="pf-email" className="form-control" value={user.email} disabled readOnly />
                <div className="form-text">Email is used for login and cannot be changed here.</div>
              </div>
              <div className="col-12">
                <label className="form-label" htmlFor="pf-bio">Bio</label>
                <textarea id="pf-bio" rows={3} className={`form-control ${errors.bio ? 'is-invalid' : ''}`} value={form.bio} maxLength={500} placeholder="A line about you and what you work on" onChange={(e) => setForm({ ...form, bio: e.target.value })} />
                <div className="d-flex justify-content-between"><div className="invalid-feedback d-block">{errors.bio}</div><span className="form-text tabular">{form.bio.length}/500</span></div>
              </div>
              <div className="col-12">
                <span className="form-label d-block">Avatar colour</span>
                <div className="d-flex gap-2 flex-wrap" role="radiogroup" aria-label="Avatar colour">
                  {COLOURS.map((c) => (
                    <button key={c} type="button" role="radio" aria-checked={form.avatar_color === c} aria-label={c} className={`swatch ${form.avatar_color === c ? 'active' : ''}`} style={{ background: c }} onClick={() => setForm({ ...form, avatar_color: c })} />
                  ))}
                </div>
              </div>
            </div>
            <div className="d-flex justify-content-end gap-2 mt-4">
              <button type="button" className="btn btn-outline-secondary" disabled={!dirty || saving} onClick={() => setForm({ name: user.name, job_title: user.job_title || '', bio: user.bio || '', avatar_color: user.avatar_color })}>Reset</button>
              <button type="submit" className="btn btn-primary" disabled={!dirty || saving}>{saving && <span className="spinner-border spinner-border-sm me-2" />}Save profile</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
