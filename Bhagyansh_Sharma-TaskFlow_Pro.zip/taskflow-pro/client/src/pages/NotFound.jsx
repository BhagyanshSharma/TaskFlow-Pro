import { Link } from 'react-router-dom';
import useDocumentTitle from '../hooks/useDocumentTitle';

export default function NotFound() {
  useDocumentTitle('Page not found');
  return (
    <div className="full-loader text-center px-3">
      <div className="brand-mark brand-mark-lg"><i className="bi bi-signpost-split" /></div>
      <h1 className="h3 mt-4">Page not found</h1>
      <p className="text-body-secondary">The page you are looking for does not exist or was moved.</p>
      <Link to="/dashboard" className="btn btn-primary">Go to dashboard</Link>
    </div>
  );
}
