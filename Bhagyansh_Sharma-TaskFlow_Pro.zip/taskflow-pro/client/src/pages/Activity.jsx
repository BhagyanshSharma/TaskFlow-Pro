import { useState } from 'react';
import { useOutletContext } from 'react-router-dom';
import { activityApi, projectApi } from '../api/services';
import { errorMessage } from '../api/client';
import { useAuth } from '../context/AuthContext';
import useAsync from '../hooks/useAsync';
import useDocumentTitle from '../hooks/useDocumentTitle';
import { confirmAction, notify } from '../utils/notify';
import ActivityFeed from '../components/ActivityFeed';
import Pagination from '../components/Pagination';
import Loader from '../components/Loader';
import EmptyState, { ErrorState } from '../components/EmptyState';

const TYPES = [
  { value: '', label: 'All activity' },
  { value: 'project', label: 'Projects' },
  { value: 'task', label: 'Tasks' },
  { value: 'comment', label: 'Comments' },
  { value: 'member', label: 'Team changes' },
  { value: 'note', label: 'Notes' },
];

// Global activity / audit log (MongoDB) with filters and note management
export default function Activity() {
  useDocumentTitle('Activity');
  const { user } = useAuth();
  const { version } = useOutletContext();
  const [projectId, setProjectId] = useState('');
  const [type, setType] = useState('');
  const [page, setPage] = useState(1);
  const [note, setNote] = useState({ project_id: '', description: '' });

  const projects = useAsync(() => projectApi.list({ limit: 100, sort: 'name' }).then((r) => r.items), [version]);
  const feed = useAsync(
    () => activityApi.list({ project_id: projectId || undefined, entity_type: type || undefined, page, limit: 20 }),
    [projectId, type, page, version]
  );

  async function addNote(e) {
    e.preventDefault();
    if (!note.project_id) return notify.error('Choose a project for the note');
    if (note.description.trim().length < 2) return notify.error('Note must be at least 2 characters');
    try {
      const res = await activityApi.createNote({ project_id: Number(note.project_id), description: note.description.trim() });
      notify.success(res.message);
      setNote({ ...note, description: '' });
      setPage(1);
      feed.reload({ silent: true });
    } catch (err) {
      notify.apiError(err);
    }
    return undefined;
  }

  async function updateNote(a, text) {
    try {
      const res = await activityApi.updateNote(a.id, text);
      notify.success(res.message);
      feed.reload({ silent: true });
      return true;
    } catch (err) {
      notify.error(errorMessage(err));
      return false;
    }
  }

  async function remove(a) {
    if (!(await confirmAction({ title: 'Delete this entry?', text: 'It will be removed from the activity log permanently.', confirmText: 'Delete' }))) return;
    try {
      const res = await activityApi.remove(a.id);
      notify.success(res.message);
      feed.reload({ silent: true });
    } catch (err) {
      notify.apiError(err);
    }
  }

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <h1 className="page-title">Activity</h1>
          <p className="page-sub">Who did what, and when, across your projects. Stored in MongoDB.</p>
        </div>
      </div>

      {feed.status === 503 ? (
        <div className="alert alert-warning">
          <h2 className="h6"><i className="bi bi-database-exclamation me-2" />MongoDB is not connected</h2>
          <p className="mb-0 small">The API cannot reach MongoDB. Check that MongoDB is running and <code>MONGODB_URI</code> in <code>server/.env</code> is correct, then restart the API.</p>
        </div>
      ) : (
        <div className="row g-4">
          <div className="col-lg-8">
            <div className="filter-bar tf-card">
              <select className="form-select" value={projectId} onChange={(e) => { setProjectId(e.target.value); setPage(1); }} aria-label="Filter by project">
                <option value="">All projects</option>
                {(projects.data || []).map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
              <select className="form-select" value={type} onChange={(e) => { setType(e.target.value); setPage(1); }} aria-label="Filter by type">
                {TYPES.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
              </select>
            </div>
            <section className="tf-card">
              {feed.error && <ErrorState message={feed.error} onRetry={feed.reload} />}
              {feed.loading && !feed.data && <Loader text="Loading activity…" />}
              {feed.data && feed.data.items.length === 0 && <EmptyState compact icon="bi-clock-history" title="Nothing here yet" text="Actions on projects and tasks will appear here." />}
              {feed.data && feed.data.items.length > 0 && <ActivityFeed items={feed.data.items} currentUser={user} onUpdate={updateNote} onDelete={remove} />}
              <Pagination pagination={feed.data?.pagination} onChange={setPage} />
            </section>
          </div>
          <div className="col-lg-4">
            <section className="tf-card">
              <h2 className="card-title-sm">Add a note to a project timeline</h2>
              <form onSubmit={addNote}>
                <select className="form-select mb-2" value={note.project_id} onChange={(e) => setNote({ ...note, project_id: e.target.value })} aria-label="Project for note">
                  <option value="">Choose project</option>
                  {(projects.data || []).map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
                </select>
                <textarea className="form-control mb-2" rows={3} maxLength={500} placeholder="Write a short update…" value={note.description} onChange={(e) => setNote({ ...note, description: e.target.value })} aria-label="Note text" />
                <button type="submit" className="btn btn-primary w-100"><i className="bi bi-sticky me-1" />Post note</button>
              </form>
              <hr />
              <p className="small text-body-secondary mb-0">
                System entries (task created, status changed, member added…) are written automatically and cannot be edited. Your own notes can be edited or deleted.
              </p>
            </section>
          </div>
        </div>
      )}
    </div>
  );
}
