import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { errorMessage, fieldErrors } from '../api/client';
import { notify } from '../utils/notify';
import useDocumentTitle from '../hooks/useDocumentTitle';

export default function Login() {
  useDocumentTitle('Log in');
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [form, setForm] = useState({ email: location.state?.email || '', password: '', remember: true });
  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);

  function validate() {
    const e = {};
    if (!form.email.trim()) e.email = 'Email is required';
    else if (!/^\S+@\S+\.\S+$/.test(form.email)) e.email = 'Enter a valid email address';
    if (!form.password) e.password = 'Password is required';
    return e;
  }

  async function submit(e) {
    e.preventDefault();
    setServerError('');
    const v = validate();
    setErrors(v);
    if (Object.keys(v).length) return;
    setLoading(true);
    try {
      const res = await login(form.email.trim(), form.password, form.remember);
      notify.success(res.message);
      navigate(location.state?.from?.pathname || '/dashboard', { replace: true });
    } catch (err) {
      setErrors(fieldErrors(err));
      setServerError(errorMessage(err));
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <h2 className="auth-title">Welcome back</h2>
      <p className="text-body-secondary mb-4">Log in to continue to your projects.</p>

      {location.state?.registered && (
        <div className="alert alert-success small py-2"><i className="bi bi-check-circle me-2" />Account created. Please log in.</div>
      )}
      {serverError && <div className="alert alert-danger small py-2" role="alert"><i className="bi bi-exclamation-circle me-2" />{serverError}</div>}

      <form onSubmit={submit} noValidate>
        <div className="mb-3">
          <label htmlFor="email" className="form-label">Email</label>
          <input id="email" type="email" autoComplete="email" className={`form-control form-control-lg ${errors.email ? 'is-invalid' : ''}`} value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="you@example.com" />
          <div className="invalid-feedback">{errors.email}</div>
        </div>
        <div className="mb-3">
          <label htmlFor="password" className="form-label">Password</label>
          <div className="input-group input-group-lg has-validation">
            <input id="password" type={showPw ? 'text' : 'password'} autoComplete="current-password" className={`form-control ${errors.password ? 'is-invalid' : ''}`} value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} placeholder="Your password" />
            <button type="button" className="btn btn-outline-secondary" onClick={() => setShowPw((s) => !s)} aria-label={showPw ? 'Hide password' : 'Show password'}>
              <i className={`bi ${showPw ? 'bi-eye-slash' : 'bi-eye'}`} />
            </button>
            <div className="invalid-feedback">{errors.password}</div>
          </div>
        </div>
        <div className="form-check mb-4">
          <input id="remember" type="checkbox" className="form-check-input" checked={form.remember} onChange={(e) => setForm({ ...form, remember: e.target.checked })} />
          <label htmlFor="remember" className="form-check-label">Keep me signed in on this device</label>
        </div>
        <button type="submit" className="btn btn-primary btn-lg w-100" disabled={loading}>
          {loading ? <><span className="spinner-border spinner-border-sm me-2" />Signing in…</> : 'Log in'}
        </button>
      </form>

      <p className="text-center mt-4 mb-0">New to TaskFlow Pro? <Link to="/register">Create an account</Link></p>

      <div className="demo-hint mt-4">
        <i className="bi bi-info-circle me-2" />
        Demo data (after running the seed script): <code>riya@example.com</code> / <code>Demo@1234</code>
      </div>
    </>
  );
}
