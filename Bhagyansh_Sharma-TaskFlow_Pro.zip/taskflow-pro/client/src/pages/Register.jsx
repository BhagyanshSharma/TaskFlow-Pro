import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { errorMessage, fieldErrors } from '../api/client';
import { notify } from '../utils/notify';
import useDocumentTitle from '../hooks/useDocumentTitle';

const RULES = [
  { test: (p) => p.length >= 8, label: 'At least 8 characters' },
  { test: (p) => /[A-Za-z]/.test(p), label: 'Contains a letter' },
  { test: (p) => /\d/.test(p), label: 'Contains a number' },
];

export default function Register() {
  useDocumentTitle('Create account');
  const { register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', password: '', confirm: '' });
  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState('');
  const [loading, setLoading] = useState(false);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  function validate() {
    const e = {};
    if (form.name.trim().length < 2) e.name = 'Please enter your full name (at least 2 characters)';
    if (!/^\S+@\S+\.\S+$/.test(form.email)) e.email = 'Enter a valid email address';
    if (!RULES.every((r) => r.test(form.password))) e.password = 'Password does not meet the requirements';
    if (form.confirm !== form.password) e.confirm = 'Passwords do not match';
    return e;
  }

  async function submit(e) {
    e.preventDefault();
    setServerError('');
    const v = validate();
    setErrors(v);
    if (Object.keys(v).length) return;
    setLoading(true);
    try {
      const res = await register({ name: form.name.trim(), email: form.email.trim(), password: form.password });
      notify.success(res.message);
      // Registration -> Login -> Dashboard workflow
      navigate('/login', { state: { registered: true, email: form.email.trim() } });
    } catch (err) {
      setErrors(fieldErrors(err));
      setServerError(errorMessage(err));
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <h2 className="auth-title">Create your account</h2>
      <p className="text-body-secondary mb-4">Start organising projects with your team.</p>
      {serverError && <div className="alert alert-danger small py-2" role="alert"><i className="bi bi-exclamation-circle me-2" />{serverError}</div>}

      <form onSubmit={submit} noValidate>
        <div className="mb-3">
          <label htmlFor="name" className="form-label">Full name</label>
          <input id="name" autoComplete="name" className={`form-control ${errors.name ? 'is-invalid' : ''}`} value={form.name} onChange={set('name')} placeholder="Your name" />
          <div className="invalid-feedback">{errors.name}</div>
        </div>
        <div className="mb-3">
          <label htmlFor="r-email" className="form-label">Email</label>
          <input id="r-email" type="email" autoComplete="email" className={`form-control ${errors.email ? 'is-invalid' : ''}`} value={form.email} onChange={set('email')} placeholder="you@example.com" />
          <div className="invalid-feedback">{errors.email}</div>
        </div>
        <div className="mb-2">
          <label htmlFor="r-password" className="form-label">Password</label>
          <input id="r-password" type="password" autoComplete="new-password" className={`form-control ${errors.password ? 'is-invalid' : ''}`} value={form.password} onChange={set('password')} placeholder="Create a password" />
          <div className="invalid-feedback">{errors.password}</div>
        </div>
        <ul className="pw-rules list-unstyled small mb-3">
          {RULES.map((r) => {
            const ok = r.test(form.password);
            return <li key={r.label} className={ok ? 'ok' : ''}><i className={`bi ${ok ? 'bi-check-circle-fill' : 'bi-circle'} me-2`} />{r.label}</li>;
          })}
        </ul>
        <div className="mb-4">
          <label htmlFor="r-confirm" className="form-label">Confirm password</label>
          <input id="r-confirm" type="password" autoComplete="new-password" className={`form-control ${errors.confirm ? 'is-invalid' : ''}`} value={form.confirm} onChange={set('confirm')} placeholder="Repeat password" />
          <div className="invalid-feedback">{errors.confirm}</div>
        </div>
        <button type="submit" className="btn btn-primary btn-lg w-100" disabled={loading}>
          {loading ? <><span className="spinner-border spinner-border-sm me-2" />Creating account…</> : 'Create account'}
        </button>
      </form>
      <p className="text-center mt-4 mb-0">Already have an account? <Link to="/login">Log in</Link></p>
    </>
  );
}
