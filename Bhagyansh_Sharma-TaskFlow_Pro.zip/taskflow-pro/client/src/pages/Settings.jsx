import { useEffect, useState } from 'react';
import { systemApi, userApi } from '../api/services';
import { API_BASE_URL, fieldErrors } from '../api/client';
import { useTheme } from '../context/ThemeContext';
import useDocumentTitle from '../hooks/useDocumentTitle';
import { notify } from '../utils/notify';

export default function Settings() {
  useDocumentTitle('Settings');
  const { theme, setTheme } = useTheme();
  const [pw, setPw] = useState({ currentPassword: '', newPassword: '', confirm: '' });
  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);
  const [health, setHealth] = useState(null);

  useEffect(() => {
    systemApi.health().then((h) => setHealth(h.data)).catch((err) => setHealth(err?.response?.data?.data || { status: 'unreachable' }));
  }, []);

  async function changePassword(e) {
    e.preventDefault();
    const v = {};
    if (!pw.currentPassword) v.currentPassword = 'Enter your current password';
    if (pw.newPassword.length < 8 || !/[A-Za-z]/.test(pw.newPassword) || !/\d/.test(pw.newPassword)) v.newPassword = 'Use 8+ characters with at least one letter and one number';
    if (pw.confirm !== pw.newPassword) v.confirm = 'Passwords do not match';
    setErrors(v);
    if (Object.keys(v).length) return;
    setSaving(true);
    try {
      const res = await userApi.changePassword({ currentPassword: pw.currentPassword, newPassword: pw.newPassword });
      notify.success(res.message);
      setPw({ currentPassword: '', newPassword: '', confirm: '' });
    } catch (err) {
      setErrors(fieldErrors(err));
      notify.apiError(err);
    } finally {
      setSaving(false);
    }
  }

  const field = (key, label, autoComplete) => (
    <div className="mb-3">
      <label className="form-label" htmlFor={`s-${key}`}>{label}</label>
      <input id={`s-${key}`} type="password" autoComplete={autoComplete} className={`form-control ${errors[key] ? 'is-invalid' : ''}`} value={pw[key]} onChange={(e) => setPw({ ...pw, [key]: e.target.value })} />
      <div className="invalid-feedback">{errors[key]}</div>
    </div>
  );

  return (
    <div className="page narrow">
      <div className="page-head">
        <div>
          <h1 className="page-title">Settings</h1>
          <p className="page-sub">Appearance, security and system status.</p>
        </div>
      </div>

      <div className="row g-4">
        <div className="col-lg-6">
          <section className="tf-card mb-4">
            <h2 className="card-title-sm">Appearance</h2>
            <p className="small text-body-secondary">Saved on this device only.</p>
            <div className="btn-group" role="group" aria-label="Theme">
              <button type="button" className={`btn ${theme === 'light' ? 'btn-primary' : 'btn-outline-secondary'}`} onClick={() => setTheme('light')}><i className="bi bi-sun me-1" />Light</button>
              <button type="button" className={`btn ${theme === 'dark' ? 'btn-primary' : 'btn-outline-secondary'}`} onClick={() => setTheme('dark')}><i className="bi bi-moon-stars me-1" />Dark</button>
            </div>
          </section>

          <section className="tf-card">
            <h2 className="card-title-sm">System status</h2>
            {!health ? <p className="small text-body-secondary mb-0">Checking…</p> : (
              <dl className="detail-grid small mb-0">
                <dt>API</dt><dd><span className={`status-dot ${health.status === 'ok' ? 'ok' : 'bad'}`} />{health.status === 'ok' ? 'Online' : health.status}</dd>
                <dt>MongoDB</dt><dd><span className={`status-dot ${health.databases?.mongodb === 'connected' ? 'ok' : 'bad'}`} />{health.databases?.mongodb || 'unknown'}</dd>
                <dt>API URL</dt><dd className="text-break"><code>{API_BASE_URL}</code></dd>
              </dl>
            )}
          </section>
        </div>
        <div className="col-lg-6">
          <form className="tf-card" onSubmit={changePassword} noValidate>
            <h2 className="card-title-sm">Change password</h2>
            {field('currentPassword', 'Current password', 'current-password')}
            {field('newPassword', 'New password', 'new-password')}
            {field('confirm', 'Confirm new password', 'new-password')}
            <button type="submit" className="btn btn-primary" disabled={saving}>{saving && <span className="spinner-border spinner-border-sm me-2" />}Update password</button>
          </form>
        </div>
      </div>
    </div>
  );
}
