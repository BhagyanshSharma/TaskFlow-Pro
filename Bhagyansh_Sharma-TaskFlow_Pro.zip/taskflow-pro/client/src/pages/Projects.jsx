import { useEffect, useState } from 'react';
import { useOutletContext, useSearchParams } from 'react-router-dom';
import { favouriteApi, projectApi } from '../api/services';
import useAsync from '../hooks/useAsync';
import useDebounce from '../hooks/useDebounce';
import useDocumentTitle from '../hooks/useDocumentTitle';
import ProjectCard from '../components/ProjectCard';
import ProjectFormModal from '../components/ProjectFormModal';
import Pagination from '../components/Pagination';
import EmptyState, { ErrorState } from '../components/EmptyState';
import { SkeletonCards } from '../components/Loader';
import { confirmAction, notify } from '../utils/notify';
import { PRIORITIES, PROJECT_STATUSES } from '../utils/constants';

export default function Projects() {
  useDocumentTitle('Projects');
  const { version, bump } = useOutletContext();
  const [params, setParams] = useSearchParams();
  const [search, setSearch] = useState(params.get('q') || '');
  const debounced = useDebounce(search);
  const [modal, setModal] = useState({ open: params.get('new') === '1', project: null });

  const filters = {
    q: debounced || undefined,
    status: params.get('status') || undefined,
    priority: params.get('priority') || undefined,
    favourites: params.get('favourites') === 'true' ? 'true' : undefined,
    sort: params.get('sort') || 'updated',
    page: Number(params.get('page')) || 1,
    limit: 9,
  };

  const { data, loading, error, reload, setData } = useAsync(() => projectApi.list(filters), [JSON.stringify(filters), version]);

  // Keep ?q= in sync with the debounced search box
  useEffect(() => {
    if ((params.get('q') || '') !== debounced) setParam('q', debounced);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debounced]);

  function setParam(key, value) {
    setParams((prev) => {
      const next = new URLSearchParams(prev);
      if (value) next.set(key, value);
      else next.delete(key);
      if (key !== 'page') next.delete('page');
      next.delete('new');
      return next;
    }, { replace: true });
  }

  async function toggleFavourite(project) {
    const fav = !project.is_favourite;
    setData((d) => ({ ...d, items: d.items.map((p) => (p.id === project.id ? { ...p, is_favourite: fav } : p)) }));
    try {
      const res = fav ? await favouriteApi.add(project.id) : await favouriteApi.remove(project.id);
      notify.success(res.message);
      bump();
    } catch (err) {
      setData((d) => ({ ...d, items: d.items.map((p) => (p.id === project.id ? { ...p, is_favourite: !fav } : p)) }));
      notify.apiError(err);
    }
  }

  async function remove(project) {
    const ok = await confirmAction({
      title: `Delete "${project.name}"?`,
      text: `This permanently deletes the project and its ${project.task_counts.total} task(s).`,
      confirmText: 'Delete project',
    });
    if (!ok) return;
    try {
      const res = await projectApi.remove(project.id);
      notify.success(res.message);
      bump();
    } catch (err) {
      notify.apiError(err);
    }
  }

  const activeFilters = ['status', 'priority', 'favourites'].filter((k) => params.get(k)).length + (debounced ? 1 : 0);

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <h1 className="page-title">Projects</h1>
          <p className="page-sub">All projects you own or are a member of.</p>
        </div>
        <button type="button" className="btn btn-primary" onClick={() => setModal({ open: true, project: null })}>
          <i className="bi bi-plus-lg me-1" />New project
        </button>
      </div>

      <div className="filter-bar tf-card">
        <div className="input-group search-input">
          <span className="input-group-text"><i className="bi bi-search" /></span>
          <input className="form-control" placeholder="Search projects…" value={search} onChange={(e) => setSearch(e.target.value)} aria-label="Search projects" />
        </div>
        <select className="form-select" value={params.get('status') || ''} onChange={(e) => setParam('status', e.target.value)} aria-label="Filter by status">
          <option value="">All statuses</option>
          {PROJECT_STATUSES.map((s) => <option key={s}>{s}</option>)}
        </select>
        <select className="form-select" value={params.get('priority') || ''} onChange={(e) => setParam('priority', e.target.value)} aria-label="Filter by priority">
          <option value="">All priorities</option>
          {PRIORITIES.map((p) => <option key={p}>{p}</option>)}
        </select>
        <select className="form-select" value={filters.sort} onChange={(e) => setParam('sort', e.target.value)} aria-label="Sort projects">
          <option value="updated">Recently updated</option>
          <option value="deadline">Deadline (soonest)</option>
          <option value="priority">Priority (highest)</option>
          <option value="progress">Progress (highest)</option>
          <option value="name">Name (A–Z)</option>
        </select>
        <button
          type="button"
          className={`btn ${filters.favourites ? 'btn-warning' : 'btn-outline-secondary'} text-nowrap`}
          onClick={() => setParam('favourites', filters.favourites ? '' : 'true')}
          aria-pressed={Boolean(filters.favourites)}
        >
          <i className={`bi ${filters.favourites ? 'bi-star-fill' : 'bi-star'} me-1`} />Favourites
        </button>
        {activeFilters > 0 && (
          <button type="button" className="btn btn-link text-nowrap" onClick={() => { setSearch(''); setParams({}, { replace: true }); }}>Clear filters</button>
        )}
      </div>

      {error && <ErrorState message={error} onRetry={reload} />}
      {loading && !data && <SkeletonCards count={6} />}
      {data && data.items.length === 0 && (
        activeFilters > 0 ? (
          <EmptyState icon="bi-funnel" title="No projects match your filters" text="Try a different search term or clear the filters." />
        ) : (
          <EmptyState
            icon="bi-kanban"
            title="No projects yet"
            text="Projects group your tasks, deadlines and team. Create your first one to get started."
            action={<button type="button" className="btn btn-primary" onClick={() => setModal({ open: true, project: null })}><i className="bi bi-plus-lg me-1" />Create project</button>}
          />
        )
      )}
      {data && data.items.length > 0 && (
        <div className={`row g-3 ${loading ? 'is-refreshing' : ''}`}>
          {data.items.map((p) => (
            <div className="col-12 col-md-6 col-xl-4" key={p.id}>
              <ProjectCard project={p} onToggleFavourite={toggleFavourite} onEdit={(proj) => setModal({ open: true, project: proj })} onDelete={remove} />
            </div>
          ))}
        </div>
      )}
      <Pagination pagination={data?.pagination} onChange={(page) => setParam('page', String(page))} />

      <ProjectFormModal show={modal.open} project={modal.project} onClose={() => setModal({ open: false, project: null })} onSaved={() => bump()} />
    </div>
  );
}
