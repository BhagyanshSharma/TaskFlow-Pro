import { useCallback, useEffect, useState } from 'react';
import { useOutletContext, useSearchParams } from 'react-router-dom';
import { projectApi, taskApi } from '../api/services';
import useAsync from '../hooks/useAsync';
import useDebounce from '../hooks/useDebounce';
import useDocumentTitle from '../hooks/useDocumentTitle';
import { getPref, setPref } from '../utils/storage';
import { notify } from '../utils/notify';
import { PRIORITIES, TASK_STATUSES } from '../utils/constants';
import TaskTable from '../components/TaskTable';
import TaskBoard from '../components/TaskBoard';
import Pagination from '../components/Pagination';
import Loader from '../components/Loader';
import EmptyState, { ErrorState } from '../components/EmptyState';

export default function Tasks() {
  useDocumentTitle('Tasks');
  const { openTask, openNewTask, version, bump } = useOutletContext();
  const [params, setParams] = useSearchParams();
  const [search, setSearch] = useState(params.get('q') || '');
  const debounced = useDebounce(search);
  const [projects, setProjects] = useState([]);
  const [view, setView] = useState(() => getPref('allTasksView', 'list'));

  useEffect(() => {
    projectApi.list({ limit: 100, sort: 'name' }).then(({ items }) => setProjects(items)).catch(() => setProjects([]));
  }, [version]);
  useEffect(() => setPref('allTasksView', view), [view]);
  // Sync the box when ?q= changes from outside (e.g. "See all matching tasks" in the top search)
  const urlQ = params.get('q') || '';
  useEffect(() => {
    if (urlQ !== debounced) setSearch(urlQ);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [urlQ]);

  const sort = params.get('sort') || 'due_date';
  const filters = {
    q: debounced || undefined,
    project_id: params.get('project') || undefined,
    status: params.get('status') || undefined,
    priority: params.get('priority') || undefined,
    assignee: params.get('assignee') || undefined,
    overdue: params.get('overdue') === 'true' ? 'true' : undefined,
    sort,
    order: params.get('order') || (sort === 'priority' || sort === 'updated' ? 'desc' : 'asc'),
    page: Number(params.get('page')) || 1,
    limit: view === 'board' ? 200 : 15,
  };

  const { data, loading, error, reload, setData } = useAsync(() => taskApi.list(filters), [JSON.stringify(filters), version]);

  useEffect(() => {
    if ((params.get('q') || '') !== debounced) setParam('q', debounced);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debounced]);

  function setParam(key, value) {
    setParams((prev) => {
      const next = new URLSearchParams(prev);
      if (value) next.set(key, value);
      else next.delete(key);
      if (key !== 'page') next.delete('page');
      return next;
    }, { replace: true });
  }

  const changeStatus = useCallback(async (task, status) => {
    setData((d) => ({ ...d, items: d.items.map((t) => (t.id === task.id ? { ...t, status } : t)) }));
    try {
      await taskApi.update(task.id, { status });
      notify.success(`"${task.title}" moved to ${status}`);
      bump();
    } catch (err) {
      setData((d) => ({ ...d, items: d.items.map((t) => (t.id === task.id ? { ...t, status: task.status } : t)) }));
      notify.apiError(err);
    }
  }, [bump, setData]);

  const activeFilters = ['project', 'status', 'priority', 'assignee', 'overdue'].filter((k) => params.get(k)).length + (debounced ? 1 : 0);

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <h1 className="page-title">Tasks</h1>
          <p className="page-sub">Every task across your projects. Search, filter and sort to find what matters.</p>
        </div>
        <div className="d-flex gap-2">
          <div className="btn-group" role="group" aria-label="View">
            <button type="button" className={`btn ${view === 'list' ? 'btn-primary' : 'btn-outline-secondary'}`} onClick={() => setView('list')} aria-label="List view" title="List view"><i className="bi bi-list-ul" /></button>
            <button type="button" className={`btn ${view === 'board' ? 'btn-primary' : 'btn-outline-secondary'}`} onClick={() => setView('board')} aria-label="Board view" title="Board view"><i className="bi bi-kanban" /></button>
          </div>
          <button type="button" className="btn btn-primary" onClick={() => openNewTask()}><i className="bi bi-plus-lg me-1" />New task</button>
        </div>
      </div>

      <div className="quick-filters mb-3">
        {[
          { label: 'All', apply: () => setParams({}, { replace: true }), active: activeFilters === 0 },
          { label: 'Assigned to me', apply: () => setParam('assignee', params.get('assignee') === 'me' ? '' : 'me'), active: params.get('assignee') === 'me' },
          { label: 'Overdue', apply: () => setParam('overdue', params.get('overdue') ? '' : 'true'), active: Boolean(params.get('overdue')) },
          { label: 'Unassigned', apply: () => setParam('assignee', params.get('assignee') === 'unassigned' ? '' : 'unassigned'), active: params.get('assignee') === 'unassigned' },
        ].map((f) => (
          <button key={f.label} type="button" className={`chip ${f.active ? 'active' : ''}`} onClick={f.apply} aria-pressed={f.active}>{f.label}</button>
        ))}
      </div>

      <div className="filter-bar tf-card">
        <div className="input-group search-input">
          <span className="input-group-text"><i className="bi bi-search" /></span>
          <input className="form-control" placeholder="Search tasks…" value={search} onChange={(e) => setSearch(e.target.value)} aria-label="Search tasks" />
        </div>
        <select className="form-select" value={params.get('project') || ''} onChange={(e) => setParam('project', e.target.value)} aria-label="Filter by project">
          <option value="">All projects</option>
          {projects.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
        </select>
        {view === 'list' && (
          <select className="form-select" value={params.get('status') || ''} onChange={(e) => setParam('status', e.target.value)} aria-label="Filter by status">
            <option value="">All statuses</option>
            {TASK_STATUSES.map((s) => <option key={s}>{s}</option>)}
          </select>
        )}
        <select className="form-select" value={params.get('priority') || ''} onChange={(e) => setParam('priority', e.target.value)} aria-label="Filter by priority">
          <option value="">All priorities</option>
          {PRIORITIES.map((p) => <option key={p}>{p}</option>)}
        </select>
        <select className="form-select" value={`${sort}:${filters.order}`} onChange={(e) => { const [s, o] = e.target.value.split(':'); setParams((prev) => { const n = new URLSearchParams(prev); n.set('sort', s); n.set('order', o); n.delete('page'); return n; }, { replace: true }); }} aria-label="Sort tasks">
          <option value="due_date:asc">Deadline (soonest first)</option>
          <option value="due_date:desc">Deadline (latest first)</option>
          <option value="priority:desc">Priority (urgent first)</option>
          <option value="priority:asc">Priority (low first)</option>
          <option value="status:asc">Status</option>
          <option value="updated:desc">Recently updated</option>
          <option value="title:asc">Title (A–Z)</option>
        </select>
        {activeFilters > 0 && <button type="button" className="btn btn-link text-nowrap" onClick={() => { setSearch(''); setParams({}, { replace: true }); }}>Clear filters</button>}
      </div>

      {error && <ErrorState message={error} onRetry={reload} />}
      {loading && !data && <Loader text="Loading tasks…" />}
      {data && data.items.length === 0 && (
        activeFilters > 0
          ? <EmptyState icon="bi-funnel" title="No tasks match these filters" text="Try another search or clear the filters." />
          : <EmptyState icon="bi-check2-square" title="No tasks yet" text="Create a task inside one of your projects." action={<button type="button" className="btn btn-primary" onClick={() => openNewTask()}>New task</button>} />
      )}
      {data && data.items.length > 0 && (
        <div className={loading ? 'is-refreshing' : ''}>
          {view === 'list'
            ? <TaskTable tasks={data.items} onOpen={(t) => openTask(t.id)} onStatusChange={changeStatus} />
            : <TaskBoard tasks={data.items} onOpen={(t) => openTask(t.id)} onStatusChange={changeStatus} />}
        </div>
      )}
      {view === 'list' && <Pagination pagination={data?.pagination} onChange={(p) => setParam('page', String(p))} />}
    </div>
  );
}
