import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { authApi } from '../api/services';
import { clearToken, getToken, saveToken } from '../utils/storage';
import { notify } from '../utils/notify';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [checking, setChecking] = useState(true); // true while validating a stored token on page load

  // On first load, validate any stored token with GET /api/auth/me
  useEffect(() => {
    let cancelled = false;
    async function restore() {
      if (!getToken()) {
        setChecking(false);
        return;
      }
      try {
        const { user: me } = await authApi.me();
        if (!cancelled) setUser(me);
      } catch {
        clearToken();
      } finally {
        if (!cancelled) setChecking(false);
      }
    }
    restore();
    return () => {
      cancelled = true;
    };
  }, []);

  // The Axios interceptor fires this when the API answers 401 (expired / invalid token)
  useEffect(() => {
    function onUnauthorized(e) {
      setUser((current) => {
        if (current) notify.error(e.detail || 'Your session has ended. Please log in again.');
        return null;
      });
    }
    window.addEventListener('taskflow:unauthorized', onUnauthorized);
    return () => window.removeEventListener('taskflow:unauthorized', onUnauthorized);
  }, []);

  const login = useCallback(async (email, password, remember) => {
    const res = await authApi.login({ email, password });
    saveToken(res.data.token, remember);
    setUser(res.data.user);
    return res;
  }, []);

  const register = useCallback((payload) => authApi.register(payload), []);

  const logout = useCallback(() => {
    clearToken();
    setUser(null);
  }, []);

  const value = useMemo(
    () => ({ user, checking, isAuthenticated: Boolean(user), login, register, logout, setUser }),
    [user, checking, login, register, logout]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside <AuthProvider>');
  return ctx;
}
