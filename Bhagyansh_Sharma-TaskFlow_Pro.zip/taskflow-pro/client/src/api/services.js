// One function per REST endpoint. Components never build URLs themselves.
import api from './client';

const data = (res) => res.data.data;
const withMeta = (res) => ({ items: res.data.data, pagination: res.data.pagination });

export const authApi = {
  register: (body) => api.post('/auth/register', body).then((r) => r.data),
  login: (body) => api.post('/auth/login', body).then((r) => r.data),
  me: () => api.get('/auth/me').then(data),
};

export const userApi = {
  updateProfile: (body) => api.put('/users/me', body).then((r) => r.data),
  changePassword: (body) => api.put('/users/me/password', body).then((r) => r.data),
  search: (q) => api.get('/users/search', { params: { q } }).then(data),
};

export const dashboardApi = {
  get: () => api.get('/dashboard').then(data),
};

export const projectApi = {
  list: (params) => api.get('/projects', { params }).then(withMeta),
  get: (id) => api.get(`/projects/${id}`).then(data),
  create: (body) => api.post('/projects', body).then((r) => r.data),
  update: (id, body) => api.put(`/projects/${id}`, body).then((r) => r.data),
  remove: (id) => api.delete(`/projects/${id}`).then((r) => r.data),
  members: (id) => api.get(`/projects/${id}/members`).then(data),
  addMember: (id, body) => api.post(`/projects/${id}/members`, body).then((r) => r.data),
  updateMember: (id, userId, role) => api.patch(`/projects/${id}/members/${userId}`, { role }).then((r) => r.data),
  removeMember: (id, userId) => api.delete(`/projects/${id}/members/${userId}`).then((r) => r.data),
};

export const favouriteApi = {
  list: () => api.get('/favourites').then(data),
  add: (projectId) => api.post(`/favourites/${projectId}`).then((r) => r.data),
  remove: (projectId) => api.delete(`/favourites/${projectId}`).then((r) => r.data),
};

export const taskApi = {
  list: (params) => api.get('/tasks', { params }).then(withMeta),
  get: (id) => api.get(`/tasks/${id}`).then(data),
  create: (body) => api.post('/tasks', body).then((r) => r.data),
  update: (id, body) => api.put(`/tasks/${id}`, body).then((r) => r.data),
  remove: (id) => api.delete(`/tasks/${id}`).then((r) => r.data),
  comments: (id) => api.get(`/tasks/${id}/comments`).then(data),
  addComment: (id, body) => api.post(`/tasks/${id}/comments`, { body }).then((r) => r.data),
  deleteComment: (id, commentId) => api.delete(`/tasks/${id}/comments/${commentId}`).then((r) => r.data),
  startTimer: (id) => api.post(`/tasks/${id}/timer/start`).then((r) => r.data),
  stopTimer: (id) => api.post(`/tasks/${id}/timer/stop`).then((r) => r.data),
};

export const activityApi = {
  list: (params) => api.get('/activities', { params }).then(withMeta),
  get: (id) => api.get(`/activities/${id}`).then(data),
  createNote: (body) => api.post('/activities', body).then((r) => r.data),
  updateNote: (id, description) => api.put(`/activities/${id}`, { description }).then((r) => r.data),
  remove: (id) => api.delete(`/activities/${id}`).then((r) => r.data),
};

export const systemApi = {
  health: () => api.get('/health').then((r) => r.data),
};
