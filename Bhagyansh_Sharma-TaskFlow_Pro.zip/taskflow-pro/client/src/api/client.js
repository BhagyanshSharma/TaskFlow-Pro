// Axios instance shared by the whole app.
import axios from 'axios';
import { getToken, clearToken } from '../utils/storage';

// VITE_API_URL comes from client/.env (or the Render dashboard at build time)
export const API_BASE_URL = (import.meta.env.VITE_API_URL || '/api').replace(/\/$/, '');

const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 20000,
  headers: { 'Content-Type': 'application/json' },
});

// Attach the JWT to every request
api.interceptors.request.use((config) => {
  const token = getToken();
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Normalise errors and react to expired sessions
api.interceptors.response.use(
  (response) => response,
  (error) => {
    const status = error.response?.status;
    const isAuthCall = error.config?.url?.startsWith('/auth/login') || error.config?.url?.startsWith('/auth/register');
    if (status === 401 && !isAuthCall) {
      clearToken();
      window.dispatchEvent(new CustomEvent('taskflow:unauthorized', { detail: error.response?.data?.message }));
    }
    return Promise.reject(error);
  }
);

// Human readable message from any API error
export function errorMessage(error, fallback = 'Something went wrong. Please try again.') {
  if (error?.response?.data?.message) return error.response.data.message;
  if (error?.code === 'ECONNABORTED') return 'The server took too long to respond.';
  if (error?.message === 'Network Error') return 'Cannot reach the server. Check that the API is running.';
  return fallback;
}

// Field errors from express-validator: { field: message }
export function fieldErrors(error) {
  const list = error?.response?.data?.errors;
  if (!Array.isArray(list)) return {};
  return Object.fromEntries(list.map((e) => [e.field, e.message]));
}

export default api;
