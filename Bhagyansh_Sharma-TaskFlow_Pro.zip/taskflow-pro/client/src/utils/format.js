// Date and duration helpers. DATE values arrive as 'YYYY-MM-DD' strings.
const DAY = 86400000;

function parseDateOnly(value) {
  if (!value) return null;
  const [y, m, d] = String(value).slice(0, 10).split('-').map(Number);
  return new Date(y, m - 1, d);
}

function parseServerDateTime(value) {
  if (!value) return null;
  if (value.includes('T')) return new Date(value);
  return new Date(value.replace(' ', 'T') + 'Z'); // 'YYYY-MM-DD HH:MM:SS' strings are treated as UTC
}

export function formatDate(value, opts = { day: 'numeric', month: 'short', year: 'numeric' }) {
  const d = parseDateOnly(value);
  return d ? d.toLocaleDateString('en-IN', opts) : '—';
}

export function formatDateTime(value) {
  const d = parseServerDateTime(value);
  return d ? d.toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : '—';
}

export function daysUntil(value) {
  const d = parseDateOnly(value);
  if (!d) return null;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return Math.round((d - today) / DAY);
}

export function dueLabel(value, completed = false) {
  const days = daysUntil(value);
  if (days === null) return { text: 'No due date', tone: 'muted' };
  if (completed) return { text: formatDate(value), tone: 'muted' };
  if (days < 0) return { text: `${Math.abs(days)}d overdue`, tone: 'danger' };
  if (days === 0) return { text: 'Due today', tone: 'warning' };
  if (days === 1) return { text: 'Due tomorrow', tone: 'warning' };
  if (days <= 7) return { text: `Due in ${days}d`, tone: 'info' };
  return { text: formatDate(value), tone: 'muted' };
}

export function timeAgo(value) {
  const d = parseServerDateTime(value);
  if (!d) return '';
  const s = Math.round((Date.now() - d.getTime()) / 1000);
  if (s < 45) return 'just now';
  const m = Math.round(s / 60);
  if (m < 60) return `${m} min ago`;
  const h = Math.round(m / 60);
  if (h < 24) return `${h} h ago`;
  const days = Math.round(h / 24);
  if (days < 30) return `${days} d ago`;
  return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}

// Same HH:MM:SS format the original LocalStorage timer used
export function formatDuration(totalSeconds) {
  const s = Math.max(0, Math.floor(totalSeconds || 0));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return [h, m, sec].map((n) => String(n).padStart(2, '0')).join(':');
}

export function initials(name = '') {
  return name.split(' ').filter(Boolean).slice(0, 2).map((p) => p[0].toUpperCase()).join('') || '?';
}

export function todayISO() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}
