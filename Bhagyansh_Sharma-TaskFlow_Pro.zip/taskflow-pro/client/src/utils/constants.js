export const TASK_STATUSES = ['To Do', 'In Progress', 'In Review', 'Completed'];
export const PRIORITIES = ['Low', 'Medium', 'High', 'Urgent'];
export const PROJECT_STATUSES = ['Planning', 'Active', 'On Hold', 'Completed', 'Cancelled'];

export const STATUS_META = {
  'To Do': { cls: 'status-todo', icon: 'bi-circle' },
  'In Progress': { cls: 'status-progress', icon: 'bi-arrow-repeat' },
  'In Review': { cls: 'status-review', icon: 'bi-eye' },
  Completed: { cls: 'status-done', icon: 'bi-check-circle-fill' },
  Planning: { cls: 'status-todo', icon: 'bi-pencil-square' },
  Active: { cls: 'status-progress', icon: 'bi-lightning-charge' },
  'On Hold': { cls: 'status-hold', icon: 'bi-pause-circle' },
  Cancelled: { cls: 'status-cancel', icon: 'bi-x-circle' },
};

export const PRIORITY_META = {
  Low: { cls: 'prio-low', icon: 'bi-chevron-double-down' },
  Medium: { cls: 'prio-medium', icon: 'bi-dash-lg' },
  High: { cls: 'prio-high', icon: 'bi-chevron-up' },
  Urgent: { cls: 'prio-urgent', icon: 'bi-exclamation-triangle-fill' },
};

export const ROLE_LABEL = { owner: 'Owner', manager: 'Manager', member: 'Member', admin: 'Admin' };
