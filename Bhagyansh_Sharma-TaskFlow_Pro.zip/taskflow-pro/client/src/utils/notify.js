// Toasts (react-hot-toast) for quick feedback, SweetAlert2 for confirmations -
// SweetAlert was already used in the original project for "Are you sure?" dialogs.
import toast from 'react-hot-toast';
import Swal from 'sweetalert2';
import { errorMessage } from '../api/client';

export const notify = {
  success: (msg) => toast.success(msg),
  error: (msg) => toast.error(msg),
  info: (msg) => toast(msg, { icon: 'ℹ️' }),
  apiError: (err, fallback) => toast.error(errorMessage(err, fallback)),
};

export async function confirmAction({ title = 'Are you sure?', text, confirmText = 'Yes, continue', danger = true } = {}) {
  const dark = document.documentElement.getAttribute('data-bs-theme') === 'dark';
  const result = await Swal.fire({
    title,
    text,
    icon: danger ? 'warning' : 'question',
    showCancelButton: true,
    confirmButtonText: confirmText,
    cancelButtonText: 'Cancel',
    reverseButtons: true,
    focusCancel: danger,
    buttonsStyling: false,
    customClass: {
      popup: 'swal-taskflow',
      confirmButton: `btn ${danger ? 'btn-danger' : 'btn-primary'} mx-1`,
      cancelButton: 'btn btn-outline-secondary mx-1',
    },
    background: dark ? '#1c1726' : '#fff',
    color: dark ? '#ece8f3' : '#1f1530',
  });
  return result.isConfirmed;
}
