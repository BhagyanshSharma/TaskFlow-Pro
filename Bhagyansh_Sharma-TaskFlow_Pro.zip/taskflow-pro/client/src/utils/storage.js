// JWT storage.
// - "Remember me" ON  -> localStorage (survives browser restarts)
// - "Remember me" OFF -> sessionStorage (cleared when the tab/browser closes)
// The token is only ever sent in the Authorization header, never in URLs.
const TOKEN_KEY = 'taskflow_token';

export function saveToken(token, remember) {
  clearToken();
  (remember ? localStorage : sessionStorage).setItem(TOKEN_KEY, token);
}

export function getToken() {
  try {
    return sessionStorage.getItem(TOKEN_KEY) || localStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
}

export function clearToken() {
  try {
    sessionStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(TOKEN_KEY);
  } catch {
    /* storage unavailable */
  }
}

// Harmless UI preferences (theme, view mode) are allowed in localStorage
export function getPref(key, fallback) {
  try {
    const v = localStorage.getItem(`taskflow_pref_${key}`);
    return v === null ? fallback : JSON.parse(v);
  } catch {
    return fallback;
  }
}

export function setPref(key, value) {
  try {
    localStorage.setItem(`taskflow_pref_${key}`, JSON.stringify(value));
  } catch {
    /* ignore */
  }
}
