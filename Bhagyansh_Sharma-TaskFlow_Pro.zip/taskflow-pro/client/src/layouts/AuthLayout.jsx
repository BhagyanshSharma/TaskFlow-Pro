import { Outlet } from 'react-router-dom';
import { useTheme } from '../context/ThemeContext';

export default function AuthLayout() {
  const { theme, toggle } = useTheme();
  return (
    <div className="auth-shell">
      <section className="auth-aside" aria-hidden="true">
        <div className="brand brand-light">
          <span className="brand-mark"><i className="bi bi-check2" /></span>
          <span className="brand-name">TaskFlow <em>Pro</em></span>
        </div>
        <div className="auth-pitch">
          <h1>Plan the work. Track the hours. Ship together.</h1>
          <p>Projects, tasks, deadlines and team discussion in one place, stored in MongoDB with a full activity trail.</p>
          <ul className="auth-points">
            <li><i className="bi bi-kanban" />Kanban board and list views</li>
            <li><i className="bi bi-stopwatch" />Start/stop time tracking per task</li>
            <li><i className="bi bi-people" />Roles for owners, managers and members</li>
            <li><i className="bi bi-clock-history" />Full activity history</li>
          </ul>
        </div>
        <div className="auth-preview">
          <div className="ap-row"><span className="ap-dot s-done" />Design event listing page<span className="ap-chip">Completed</span></div>
          <div className="ap-row"><span className="ap-dot s-review" />Build registration API<span className="ap-chip">In Review</span></div>
          <div className="ap-row"><span className="ap-dot s-progress" />Event details page<span className="ap-chip">In Progress</span></div>
        </div>
      </section>
      <section className="auth-main">
        <button type="button" className="btn btn-icon auth-theme" onClick={toggle} aria-label="Toggle theme">
          <i className={`bi ${theme === 'dark' ? 'bi-sun' : 'bi-moon-stars'}`} />
        </button>
        <div className="auth-card">
          <div className="brand d-lg-none mb-4">
            <span className="brand-mark"><i className="bi bi-check2" /></span>
            <span className="brand-name">TaskFlow <em>Pro</em></span>
          </div>
          <Outlet />
        </div>
      </section>
    </div>
  );
}
