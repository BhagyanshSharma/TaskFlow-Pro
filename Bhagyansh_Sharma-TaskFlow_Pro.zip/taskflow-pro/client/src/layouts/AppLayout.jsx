import { useCallback, useState } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import Sidebar from '../components/Sidebar';
import Topbar from '../components/Topbar';
import TaskDrawer from '../components/TaskDrawer';
import TaskFormModal from '../components/TaskFormModal';

// Shell for every logged-in page: sidebar + topbar + page outlet.
// Also hosts the shared task drawer and "New task" modal; pages use them through
// the outlet context and re-fetch when `version` changes.
export default function AppLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [drawerTaskId, setDrawerTaskId] = useState(null);
  const [newTask, setNewTask] = useState(null); // null | { projectId?, status? }
  const [version, setVersion] = useState(0);
  const location = useLocation();

  const bump = useCallback(() => setVersion((v) => v + 1), []);
  const openTask = useCallback((id) => setDrawerTaskId(id), []);
  const openNewTask = useCallback((opts = {}) => setNewTask(opts), []);

  return (
    <div className="app-shell">
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} version={version} />
      <div className="app-main">
        <Topbar onMenu={() => setSidebarOpen(true)} onNewTask={() => openNewTask()} onOpenTask={openTask} />
        <main className="app-content" key={location.pathname}>
          <Outlet context={{ openTask, openNewTask, version, bump }} />
        </main>
      </div>

      {drawerTaskId && (
        <TaskDrawer taskId={drawerTaskId} onClose={() => setDrawerTaskId(null)} onChanged={bump} onDeleted={bump} />
      )}
      <TaskFormModal
        show={Boolean(newTask)}
        projectId={newTask?.projectId}
        defaultStatus={newTask?.status}
        onClose={() => setNewTask(null)}
        onSaved={bump}
      />
    </div>
  );
}
