# TaskFlow Pro: Full-Stack Project Management System

TaskFlow Pro is a project management web application where registered users create projects, add team members, assign tasks with priorities and deadlines, track time, discuss tasks in comments and follow every change in an activity log.

It is the full-stack upgrade of my earlier **Project Management Tool** (HTML, CSS, JavaScript, Bootstrap and LocalStorage). The original files are kept in [`legacy-frontend/`](legacy-frontend/), and [`docs/phase1-analysis.md`](docs/phase1-analysis.md) explains what was reused and what was fixed.

| | |
|---|---|
| Student | Bhagyansh Sharma (UID 25MCI10119) |
| Programme | MCA (AIML), 3rd semester, section 25MAM5-A |
| Subject | Technical Training-II (25CAP-707), Chandigarh University |

## Features

- **Accounts:** registration, login, JWT sessions, bcrypt password hashing, profile and password change, protected routes.
- **Dashboard:** project and task totals, pending / in progress / completed / overdue counts, status and priority charts, project progress bars, upcoming deadlines, overdue list, my open tasks, recent activity. Every number comes from the database.
- **Projects:** create, view, edit, delete (with confirmation), status, priority, start date, deadline, progress %, favourites, search, filters, sorting, pagination.
- **Team:** owner / manager / member roles, add members by name or email, change roles, remove members, leave a project.
- **Tasks:** create, edit, delete, four statuses (To Do, In Progress, In Review, Completed), four priorities, assignee, due date, Kanban board with drag-and-drop, list view, search, filters (project, status, priority, assignee, overdue), sorting.
- **Time tracking:** start/stop timer per task with HH:MM:SS display and a log of sessions (carried over from the original project).
- **Comments:** discussion thread on each task (replaces the old chatbox).
- **Activity log:** every important action is recorded; members can post, edit and delete their own notes.
- **UI:** responsive (phone, tablet, desktop), dark mode, toasts, confirmation dialogs, loading skeletons, empty and error states.

## Technology

| Layer | Technology |
|---|---|
| Frontend | React 18, Vite 5, React Router 6, Axios, Bootstrap 5.3, Bootstrap Icons, Chart.js, react-hot-toast, SweetAlert2 |
| Backend | Node.js, Express 4, express-validator, jsonwebtoken, bcrypt, helmet, cors, express-rate-limit, morgan |
| Database | MongoDB via Mongoose (users, projects, members, tasks, comments, favourites, time logs, activity log) |
| Testing | Jest, Supertest, Postman / Newman |
| Deployment | Git, GitHub, Render (API + static site), MongoDB Atlas |

## Folder structure

```
taskflow-pro/
├── client/                    React + Vite frontend
│   ├── public/                favicon, _redirects (SPA fallback)
│   └── src/
│       ├── api/               Axios instance + one function per endpoint
│       ├── components/        Reusable UI (cards, badges, modals, board, drawer...)
│       ├── context/           AuthContext, ThemeContext
│       ├── hooks/             useAsync, useDebounce, useNow, useDocumentTitle
│       ├── layouts/           AppLayout (sidebar + topbar), AuthLayout
│       ├── pages/             Login, Register, Dashboard, Projects, ProjectDetail, Tasks, Activity, Profile, Settings
│       ├── routes/            ProtectedRoute, PublicOnlyRoute
│       ├── styles/app.css
│       └── utils/             constants, formatting, notifications, token storage
├── server/                    Express REST API
│   ├── config/                env, MongoDB connection
│   ├── controllers/           auth, users, projects, tasks, activity, dashboard
│   ├── middleware/            JWT auth, validation, errors, rate limit
│   ├── models/                Mongoose models (User, Project, Task, Comment, ...)
│   ├── routes/
│   ├── services/              access control, activity logging
│   ├── validators/            express-validator rules
│   ├── scripts/               seed.js (demo data)
│   ├── tests/                 Jest unit + integration tests
│   ├── app.js, server.js
├── docs/                      API docs, Postman, report, viva guide, testing, deployment
├── legacy-frontend/           original LocalStorage project (unchanged)
└── render.yaml                Render blueprint
```

## Run it on Windows (VS Code)

### 1. Install the tools

| Tool | Version | Download |
|---|---|---|
| Node.js | 20 LTS or newer | https://nodejs.org |
| MongoDB Community Server + Compass | 7 or newer | https://www.mongodb.com/try/download/community |
| VS Code | latest | https://code.visualstudio.com |

Install MongoDB "as a Service" (the default option) so it starts automatically with Windows. MySQL is **not** needed any more.

(Instead of a local MongoDB you can use a free MongoDB Atlas cluster: put its connection string in `MONGODB_URI`.)

### 2. Install dependencies

Open the `taskflow-pro` folder in VS Code, then in the terminal:

```bash
cd server
npm install
cd ../client
npm install
cd ..
```

### 3. Environment variables

`server/.env` and `client/.env` are already included and work with a local MongoDB:

```
MONGODB_URI=mongodb://127.0.0.1:27017/taskflow_pro
CORS_ORIGIN=http://localhost:5173
```

Only change `MONGODB_URI` if you use MongoDB Atlas. If the `.env` files are missing, copy them from the `.env.example` files next to them.

### 4. Start the app (two terminals)

Terminal 1, API:

```bash
cd server
npm run dev
```

Expected:

```
[mongo] connected to "taskflow_pro"
[seed] Empty database - inserted demo data (5 users, 5 projects, 18 tasks).
[server] TaskFlow Pro API listening on port 5000 (development)
```

The demo data is inserted automatically the first time only (when the database is empty). Accounts you register are saved in the `users` collection; you can see them in MongoDB Compass under `taskflow_pro`.

Terminal 2, frontend (use the **+** in the VS Code terminal panel):

```bash
cd client
npm run dev
```

Open http://localhost:5173

### 5. Reset the demo data (optional)

```bash
cd server
npm run db:seed
```

This deletes everything in the `taskflow_pro` database (including accounts you registered) and inserts the demo data again.

### 6. Demo accounts (fictional, created by the seed)

Password for all: `Demo@1234`

| Email | Role | Notes |
|---|---|---|
| riya@example.com | Project Manager | Owns 2 projects, best account for the demo |
| arjun@example.com | Frontend Developer | Owner of "Mobile Attendance App" |
| neha@example.com | Backend Developer | Member |
| kabir@example.com | UI/UX Designer | Owner of "Placement Cell Dashboard" |
| admin@example.com | Administrator | Global admin, sees every project |

Dates in the demo data are relative to the day you run the seed, so there are always upcoming and overdue tasks.

## Testing

```bash
cd server
npm test
```

Runs unit tests and API integration tests against a separate `taskflow_test` MongoDB database (MongoDB must be running; your real data is not touched). To use another server: `$env:TEST_MONGODB_URI="mongodb://..."; npm test`.

Postman: import `docs/postman-collection.json` and `docs/postman-environment.json`, choose the "TaskFlow Pro - Local" environment, and run the collection.

## Health check

`GET http://localhost:5000/api/health` returns the status of the API and MongoDB.

## Deployment

Step-by-step GitHub, MongoDB Atlas and Render instructions (the guide was written for the old MySQL version: skip every MySQL step, the API now only needs `MONGODB_URI`): [`docs/deployment-guide.md`](docs/deployment-guide.md).

## Documentation

| File | Contents |
|---|---|
| [`docs/api-documentation.md`](docs/api-documentation.md) | Every endpoint: method, auth, body, response, errors |
| [`docs/postman-collection.json`](docs/postman-collection.json) | 51 requests with tests |
| [`docs/experiment-mapping.md`](docs/experiment-mapping.md) | Experiments 1 to 6 mapped to features and files |
| [`docs/Project-Report.md`](docs/Project-Report.md) / `.docx` | Formal project report |
| [`docs/viva-and-presentation-guide.md`](docs/viva-and-presentation-guide.md) | Explanations, viva Q&A, demo script |
| [`docs/testing-report.md`](docs/testing-report.md) | Executed tests and pending tests |
| [`docs/phase1-analysis.md`](docs/phase1-analysis.md) | Analysis of the original project |

## Common local problems

| Problem | Fix |
|---|---|
| `[mongo] Cannot connect` | MongoDB is not running (Windows: Services > MongoDB > Start) or `MONGODB_URI` in `server/.env` is wrong. |
| Atlas: `bad auth` / timeout | Check the user/password in the URI and allow your IP in Atlas > Network Access. |
| Register says "already exists" | That email is already in the `users` collection. Log in instead, or use another email. |
| Port 5000 already in use | Change `PORT` in `server/.env` and set `VITE_DEV_API_PROXY=http://localhost:<port>` in `client/.env`. |
| `'vite' is not recognized` | Run `npm install` inside `client`. |
| Login says "Cannot reach the server" | The API terminal is not running. |
